-- to insert, use the first query (all the way up to the ;)
-- it creates the document if it doesn't exist and then
-- creates the context, question, and answer entries
-- and finally the training row.  in python, replace the literals in
-- the 'data' table with %(path)s %(context)s, ... and use 
-- variable substitution


with data (path, context, domain, question, answer, attuid, finetune_ver) as (
    values
        ('/home/mydoc/test1.pdf', 'this is the context from test1.pdf for test1',
         3, 'this is test1 question', 'this is test1 answer', 'motest', 1)
),
idoc as (
    insert into document (path) 
        select path from data
        on conflict (path) do 
            update set path=(select path from data) 
        returning id
),
icon as (
    insert into context (document,text) 
        select idoc.id, data.context from idoc, data
        returning id
),
iq as (
    insert into question (question, domain, attuid)
        select d.question, d.domain, d.attuid from data d
        returning id
),
ia as (
    insert into answer (question, answer, source)
        select iq.id, d.answer, d.attuid from data d, iq
        returning id
),
it as (
    insert into training (answer, context, finetune_ver)
        select ia.id, icon.id, d.finetune_ver from ia, icon, data d
        returning id
)
select id from it;

select d.name, q.question, a.answer, a.source attuid, dd.path, c.text, t.finetune_ver
    from training t
    join answer a on t.answer = a.id
    join question q on a.question = q.id
    join domain d on q.domain = d.id
    join context c on t.context = c.id
    join document dd on dd.id = c.document;