var myTemplate=`*Project One PI14 CMT – EP 1 US-100: CMT/Infrastructure: CMT Modeling of P-Leaf to CRS Routing Design.* 

   Description:
   
   As a client of Operations, I want to enhance the CMT routing design to accurately model the network implementation for routing of connections between CRS aggregation (8(1-9)crs, 8(1-9)cr8) and PLeaf routers.
   
   CMT shall implement the following design rules for Local agg routes:
    * [{color:#DE350B}How should the Pleaf be connected to local CRS?{color}].
    * [{color:#DE350B}what device handles the PE loopback addresses from OSPF to BGP?{color}].
    * [{color:#DE350B}List any other routes that shoudl be distributed to OSPF{color}]
    * The edges behind Pleaf network will be received in OSPF from the ABRs. When the PE sends the traffic to Pleaf PEs, the agg router will prefer the eBGP route that it received from local Pleaf and hence, send the traffic from agg to Pleaf links. Routers that are in CRS network or Hybrid edges would use the existing 81/82 to 21/22 links.
   
   [{color:#DE350B}list any other design rules listed in the NDR for the CMT{color}]
   
   There is existing routing code that requires that traffic routed from a router connected to a PLeaf and going to a router not in an office with a PLeaf to immediately use the PLeaf-CRS link. This current implementation shall be modified to only apply to CRS in Area 0.`

var answers = ['The Pleaf will be connected to the local crs aggregation routers (8(1-9)crs, 8(1-9)cr8) via link bundle',
             'The aggregation routers will redistribute the local PE loopback addresses from OSPF to BGP.',
             'The routes received from Pleaf will NOT be redistributed to OSPF, in order to not create Type 5 LSA.',
            `CMT shall implement the following design rules for Remote agg routes:
            * The configuration on the remote agg is modified so that aggregation routers will redistribute the local OSPF routes (PE Lo0, Lo10) into BGP.
            * The BGP routes received from the Pleaf will be redistributed to OSPF type 3 LSA. A dummy area 0 link or loopback is configured to ensure the redistribution is Type 3.`]

class Template {
    constructor (text, tags) {
        this.text = text.replace(/\{[^\}]*\}/g, '')
        this.tags = [tags[0], tags[1]]
    }
    questions() {
        return Array.from(this.text.matchAll(/\[([^\]]*)\]/g)).map(x => x[1])
    }
    answers(answers) {
        var rv=this.text
        if (!Array.isArray(answers)) {
            answers = [answers]
        }
        var q = this.questions()    // remember questions so you can put in place if answer not found
        answers.forEach((a) => {
            a=a.replace(/\[\{/g, '(').replace(/\]\}/g,')')  //get rid of additional brackets so it won't mess things up
            rv = rv.replace(/\[[^\]]*\]/, this.tags[0]+a+this.tags[1])
        })
        return rv
    }
} 

// create a Template object with teh template (in this case mydata.t1)
// the second parameter is a delimiter to put around the answers (mainly to change their color)

var us = new Template(myTemplate, ['{color:#009050}', '{color}'])

//once you created it, just call the answers() method and it will incorporate the answers (surrounded by the delimiters)
//  and returns the resulting string that can be put in the user story.

console.log(us.answers(answers))
