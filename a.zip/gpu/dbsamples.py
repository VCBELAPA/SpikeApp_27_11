import psycopg2
from psycopg2 import Error
from psycopg2.extras import RealDictCursor
import re
import time
from flask import Flask, jsonify, request
import debugpy
import sys
from werkzeug.exceptions import HTTPException, NotFound, UnsupportedMediaType
#debugpy.listen(('0.0.0.0', 4302))

app = Flask(__name__)



@app.after_request
def cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = '*'
    return response

@app.route('/domains', defaults={"domain": False}, methods=['GET'])
@app.route('/domains/<domain>', methods=['GET'])
def getDomain(domain):
    '''returns the list of domains or info on a specific domain
    '''
    global db
    rv={"status": 0}
    try:
        cursor = db.cursor('names' in request.args)
        cursor.execute("select * from domain %s" % ("where name = %(domain)s" if domain else "" ),
                       {"domain" : domain })
        rv['response'] = cursor.fetchall()
        db.commit()
    except(Exception, Error) as error:
        print(error)
        rv['error'], rv['status'] = str(error), -1
    return jsonify(rv)

@app.route('/questions/<domain>', defaults={"attuid": False}, methods=['GET'])
@app.route('/questions/<domain>/<attuid>', methods=['GET'])
def getQuestion(domain, attuid):
    '''returns the list of questions in a domain or for a specific attuid (in a domain)
        later, we need to eliminate the domain and derive it from the attuid
        pass on ?names as query string (e.g. /qestions/test/mn0307?names) to get the field names
           else will just get an array
    '''
    global db
    rv={"status": 0}
    try:
        cursor = db.cursor('names' in request.args)
        if domain.isnumeric():  # if a number use it, else need to look it up
            where = "where domain = %(domain)s"
        else:
            where = "join domain d on q.domain = d.id where d.name = %(domain)s"
        
        where +=  'and q.attuid = %(attuid)s' if attuid else ''

        cursor.execute("select q.* from question q " + where, 
                       {"domain" : domain, "attuid" : attuid })
        rv['response'] = cursor.fetchall()
    except(Exception, Error) as error:
        print(error)
        rv['error'], rv['status'] = str(error), -1
    return jsonify(rv)

@app.route('/answers/<questionId>', methods=['GET'])
def getAnswer(questionId):
    '''returns the answers for a particular question id
         can pass the ?names to get the field names 
    '''
    global db
    rv={"status": 0}
    try:
        cursor = db.cursor('names' in request.args)
        cursor.execute("select * from answer where question = %(qid)s ", 
                       {"qid" : questionId})
        rv['response'] = cursor.fetchall()
    except(Exception, Error) as error:
        print(error)
        rv['error'], rv['status'] = str(error), -1
    return jsonify(rv)

@app.route('/feedback/<answerId>', defaults={"questionId": False}, methods=['GET'])
@app.route('/feedback/all/<questionId>', defaults={"answerId": False}, methods=['GET'])
def getFeedbacks(answerId,  questionId):
    '''returns the feedbacks for a particular answer or for all answers for a question
         can pass the ?names to get the field names 
         when using 'all' the feedbacks will be consolidated by answerid
    '''
    global db
    rv={"status": 0}
    try:
        cursor = db.cursor('names' in request.args)
        if (answerId):
            cursor.execute("select * from feedback where answer = %(aid)s ", {"aid" : answerId})
            rv['response'] = cursor.fetchall()
        else:
            cursor.execute("""select f.id fid, f.comment, f.rating, a.* from feedback f 
                                    join answer a on f.answer = a.id 
                                    where a.question = %(qid)s order by a.id""", {"qid": questionId})
            currentAnswer = -1
            rv['response']=[]
            for record in cursor:
                print(record)
                if record['id'] != currentAnswer:  #new answer 
                    feedback = []
                    rv['response'].append({"answerId": record['id'], "answer": record['answer'], 
                                            "feedback": feedback})
                    print(rv['response'])
                feedback.append({"id":record['fid'], "comment": record['comment'], "rating": record['rating']})
    except(Exception, Error) as error:
        print(error)
        rv['error'], rv['status'] = str(error), -1
    return jsonify(rv)


@app.route('/questions/<domain>/<attuid>', methods=['POST'])
def createQuestion(domain, attuid):
    '''creates a question in the domain tagged with the user's attuid
        domain can be domain id or name
        post variables:
            question (the question text)
        returns:
            {status: 0|-errcode, response: id}  'id' is the id field of the question
        make sure you uuencode <domain> in case it has /,space, or any disallowed URL char
    '''
    global db
    rv={"status": 0}
    if request.values.get('question'):
        try:
            cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
            if domain.isnumeric():  # if a number use it, else need to look it up
                values = "values (%(domain)s, %(attuid)s, %(question)s)"
            else:
                values = "select d.id, %(attuid)s, %(question)s from domain d where d.name = %(domain)s"

            cursor.execute("insert into question (domain, attuid, question) %s" % (values), 
                           {"domain": domain, "attuid": attuid, "question": request.values['question']}
            )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            db.commit()
            rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
        except(Exception, Error) as error:
            print(error)
            rv['error'], rv['status'] = str(error), -1
    else:
        rv['error'], rv['status'] = 'Missing required "question" parameter', -2
    return jsonify(rv)

@app.route('/domains/<domain>', methods=['POST'])
def createDomain(domain):
    '''creates a domain if it doesn't exist or errors out if it does
        post variables:
            description (a description for the domain)
        returns:
            {status: 0|-errcode, response: id}  'id' is the id field of the domain
        make sure you uuencode <domain> in case it has /,space, or any disallowed URL char
    '''
    global db
    rv={"status": 0}
    if request.values.get('description'):
        try:
            cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
            cursor.execute("insert into domain (name, description) values (%(name)s, %(desc)s)",
                           {"name": domain, "desc": request.values['description']}
            )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            db.commit()
            rv['response'] = {"id" : cursor.fetchone()[0]}   #this cursor returns arrays and not dicts
        except(Exception, Error) as error:
            print(error)
            rv['error'], rv['status'] = str(error), -1
    else:
        rv['error'], rv['status'] = 'Missing required "description" parameter', -2
    return jsonify(rv)

@app.route('/answers/<questionId>', methods=['POST'])
def createAnswer(questionId):
    '''creates a an answer in the database for the question; must pass question id
        post variables:
            answer (the answer text)
        returns:
            {status: 0|-errcode, response: id}  'id' is the id field of the answer
    '''
    global db
    rv={"status": 0}
    if request.values.get('answer'):  #note using get doesn't error out if missing
        try:
            cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
            cursor.execute("insert into answer (question, answer) values (%(qid)s, %(answer)s)",
                           {"qid": questionId, "answer": request.values['answer']}
            )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            db.commit()
            rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
        except(Exception, Error) as error:
            print(error)
            rv['error'], rv['status'] = str(error), -1
    else:
        rv['error'], rv['status'] = 'Missing required "answer" parameter', -2
    return jsonify(rv)


@app.route('/training/<domain>/<version>', methods=['POST']) 
def createTraining(domain, version):
    '''creates a feedback record, assumes question, answer, and context
        do NOT exist (later need to fix) but checks for the document
        and creates that one if no there.
        All variables are required in a json body
            path: document path
            context: context for the training (out of the document)
            question:
            answer:
            attuid:

        returns:
            {status: 0|-errcode, response: id}  'id' is the is the id of this particular training record
    '''
    global db
    rv={"status": 0}
    try:
        params = request.get_json()
        params['domain'], params['version'] = int(domain), int(version)
        cursor = db.cursor() 
        cursor.execute("""
            with data (path, context, domain, question, answer, attuid, finetune_ver) as (
                values (%(path)s, %(context)s, %(domain)s, 
                       %(question)s, %(answer)s, %(attuid)s, %(version)s)
            ),
            idoc as (
                insert into document (path) 
                    select path from data
                    on conflict (path) do 
                        update set path=(select path from data) 
                    returning id
            ),
            icon as (
                insert into context (document,text) 
                    select idoc.id, data.context from idoc, data
                    returning id
            ),
            iq as (
                insert into question (question, domain, attuid)
                    select d.question, d.domain, d.attuid from data d
                    returning id
            ),
            ia as (
                insert into answer (question, answer, source)
                    select iq.id, d.answer, d.attuid from data d, iq
                    returning id
            ),
            it as (
                insert into training (answer, context, finetune_ver)
                    select ia.id, icon.id, d.finetune_ver from ia, icon, data d
                    returning id
            )
            select id from it""", params)
        #not need to execute lastval() since this one explicitly returns the id
        db.commit()
        rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts

    except UnsupportedMediaType as e:
        rv['error'], rv['status'] = "data must in in JSON: %s" % e, -1
    except KeyError as e:
        rv['error'], rv['status'] = "missing input: %s" % e, -1
    except Error as e:
        #e = sys.exc_info()[0]
        rv['error'], rv['status'] = "other: %s" % e, -1
    return jsonify(rv)

@app.route('/training/<domain>/<version>', methods=['GET']) 
@app.route('/training', defaults={"domain": -1, "version": -1}, methods=['GET'])
@app.route('/training/<domain>', defaults={"version": -1}, methods=['GET'])
def getTraining(domain, version):
    #gets details of a training, or list of all avaialble training domains and version 
    # combinations
    rv = {"status" : 0}
    try:
        cursor = db.cursor('names' in request.args) #get the column names
        if version == -1:   #must be a query to get the list
                #note in the db, if rating is not provided, it will be set to -1
            cursor.execute("select * from training %s" % 
                        ('' if domain == -1 else "where domain = %s", domain))
        else:
            cursor.execute("""
                    select d.name, q.question, a.answer, a.source attuid, dd.path, c.text, t.finetune_ver
                            from training t
                            join answer a on t.answer = a.id
                            join question q on a.question = q.id
                            join domain d on q.domain = d.id
                            join context c on t.context = c.id
                            join document dd on dd.id = c.document
                    where d.id = %s and t.finetune_ver = %s""", [int(domain), int(version)])
            rv['response'] = cursor.fetchall()  
    except Error as e:
        #e = sys.exc_info()[0]
        rv['error'], rv['status'] = "other: %s" % e, -1
    return jsonify(rv)

@app.route('/feedback/<answerId>', methods=['POST'])  #now READS JSON also
def createFeedback(answerId):
    '''creates a an answer in the database for the question; must pass question id
        post variables: (at least one is required)
            rating 0-10; but can be any number
            comment: text with a comment
        returns:
            {status: 0|-errcode, response: id}  'id' is the is the id of this particular feedback
    '''
    global db
    rv={"status": 0}
    contentType=request.headers.get('Content-Type')
    if (contentType == 'application/json'):
        json = request.get_json()
        param = [json['rating'] if 'rating' in json else '', 
                json['comment'] if 'comment' in json else '', 
                json['myanswer'] if 'myanswer' in json else '']
    else:
        #set any unprovided value to blank '' (distinguish between 0 and '' for rating)
        param=list(map(lambda x: request.values[x] if x in request.values else '',
                    ['rating', 'comment', 'myanwer']))
    print(param)
    if len(list(filter(lambda x: x, param))) > 0: # have at least one of them
        try:
            cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
            #note in the db, if rating is not provided, it will be set to -1
            cursor.execute("""insert into feedback (answer, rating, comment, myanswer) values (%s, %s, %s, %s)""",
                    [answerId, param[0] if param[0] else -1] + param[1:]
            )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            db.commit()
            rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
        except(Exception, Error) as error:
            print(error)
            rv['error'], rv['status'] = str(error), -1
    else:
        rv['error'], rv['status'] = 'Must provide at least one of rating, comment, or myanswer', -2
    return jsonify(rv)

class DB:
    def __init__(self):
        self._db = None
    def cursor(self, names=False):
        return self._conn().cursor(cursor_factory=RealDictCursor if names else None)
    def commit(self):
        # nothign to commit if there is no db!
        if self._db:
            self._db.commit()
    def _conn(self):
        if not self._db:
            self._db = psycopg2.connect(user="ainlm",
                            password="ainlm",
                            host="127.0.0.1",
                            port="5432",
                            database="ainlm")
        return self._db

db = DB()
if __name__ == "__main__":
    app.run(host='localhost', port=4300)