import GPUtil
import psycopg2
from psycopg2 import Error
from psycopg2.extras import RealDictCursor
import re
import time
from flask import Flask, jsonify, request


app = Flask(__name__)

@app.after_request
def cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response


@app.route('/gpu', defaults={"cmd": False})
@app.route('/gpu/<cmd>')
def getStat(cmd):
    rv = []
    gpuList=GPUtil.getGPUs()
    for gpu in gpuList:
        rv.append({
            "id": gpu.id,
            "memoryFree": gpu.memoryFree,
            "memoryTotal": gpu.memoryTotal,
            "memoryUsed": gpu.memoryUsed,
            "memoryUtil": gpu.memoryUtil}
        )
        if cmd == 'all':
            rv[-1].update({
                "display_active": gpu.display_active,
                "display_mode": gpu.display_mode,
                "driver": gpu.driver,
                "load": gpu.load,
                "name": gpu.name,
                "serial": gpu.serial,
                "temperature": gpu.temperature,
                "uuid": gpu.uuid}
            )
    return jsonify(dict(status=0, response=rv))

@app.route('/db/list')
def listTables():
    global db
    rv={"status": 0}
    try:
        if not db:
            db_connect()    #sets the db to a connection
        cursor.execute("select * from pg_catalog.pg_tables")
        response = cursor.fetchall()
        rv['response'] = response
    except(Exception, Error) as error:
        print(error)
        rv['error'] = str(error)
        rv['status'] = -1
    return jsonify(rv)


@app.route('/db/answer/<qid>', methods=['GET'])
def answers(qid):
    #NOTE: using user entered parameters in a sql state can be SQL injection
    #  which is a serious vulnerability, in this case, we are ok since we
    #  are converting to int, otherwise, need to clean up qid

    # can pass /db/answer/1?names if you want to skip column names
    global db
    rv={"status": 0}

    try:
        if not db:
            db_connect()    #sets the db to a connection

        #cursor = db.cursor() # this is simpler if you don't care about column names
        cursor = db.cursor(cursor_factory=RealDictCursor if 'names' in request.args else None) 
        cursor.execute('''
            select a.id, a.answer, f.* from 
                question q 
                    join answer a on a.question = q.id
                    left join feedback f on f.answer = a.id
                where q.id = %(qid)s
        ''', {'qid' : qid})
        response = cursor.fetchall()
        rv['response'] = response

    except(Exception, Error) as error:
        print(error)
        rv['error'] = str(error)
        rv['status'] = -1
    return jsonify(rv)

@app.route('/db/question', methods=['GET'])
def questions():
    global db
    rv={"status": 0}
    try:
        if not db:
            db_connect()    #sets the db to a connection
        cursor = db.cursor(cursor_factory=RealDictCursor if 'names' in request.args else None) 
        cursor.execute('select * from question')
        response = cursor.fetchall()
        rv['response'] = response
    except(Exception, Error) as error:
        print(error)
        rv['error'] = str(error)
        rv['status'] = -1
    return jsonify(rv)


db=None
def db_connect():
    global db
    #establish the db connection
    db = psycopg2.connect(user="ainlm",
                            password="ainlm",
                            host="127.0.0.1",
                            port="5432",
                            database="ainlm") 


db=None
