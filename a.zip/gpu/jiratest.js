var https = require('https')
var express = require('express')
var app = express()
var port = 4305

var n=1
//program needs to get updated to it can detect and store tokens
// automatically; currenlty it doesn't do that so in order to work
// with global logon, you need to logon to Jira, and after you authenticated,
// cut and paste the values of the tokens below.  You can do this by using the developer's
// console in chrome or other browser (see how to view tokens in a browser)

// cookies can be uploaded from GUI or cut and paste directly into code
// below let's you cut and paste in two ways (2nd )
cookies = {
    'atlassian.xsrf.token' : null,
    'JSESSIONID': null
}
//cut and paste this from browser, it will find the right strings in there
// if running the express/web based version, it will ask you to upload it (see app.get('/'))
cookie="iamlang=en; Kd4zPCrb=AxqeXC2GAQAArpbma3f_XOpoEgVJ3QM4VlmBY9baxntb7huISuOL3u4jiu6qAYccqrmucnyzwH8AAOfvAAAAAA|1|0|f64605dbcdfd35cc560c16bf9509caf3b534c6d5; s_ecid=MCMID%7C24287396116528057970476257478037195196; _gcl_au=1.1.1232206010.1684760858; _4c_=%7B%22_4c_mc_%22%3A%22e28f0974-1483-43be-a0c8-0f1fd70ce676%22%7D; QuantumMetricUserID=76dc463756fb7161a663b8cc60c416e2; ixp=18697d04-2d3d-476c-9c09-076bf3db7db5; AMCV_55633F7A534535110A490D44%40AdobeOrg=1994364360%7CMCMID%7C24287396116528057970476257478037195196%7CMCAAMLH-1689776641%7C7%7CMCAAMB-1689776641%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1689179041s%7CNONE%7CMCAID%7CNONE%7CvVersion%7C3.4.0; mbox=PC#9168eb7fd0244444878024a6adb65769.34_0#1752416643|session#33f0eccefcff4e1b97b98ccb4595088e#1689173702; cust_type=new; browserid=A003322433703; svariants=NA; _gcl_aw=GCL.1689171845.Cj0KCQjwnrmlBhDHARIsADJ5b_k2q7Y5epk8EzPxdV3ygj1lO6Oq6mGxu0MkIGqSRakq_x7uDuC-oFMaAmmtEALw_wcB; _gcl_dc=GCL.1689171845.Cj0KCQjwnrmlBhDHARIsADJ5b_k2q7Y5epk8EzPxdV3ygj1lO6Oq6mGxu0MkIGqSRakq_x7uDuC-oFMaAmmtEALw_wcB; _uetvid=a0937690f8a111edadc6df45d675d4d7; _one_MjIxMDAw=85936bc9-793b-bc64-ed3c-e283e3054250; invoca_session=%7B%22ttl%22%3A%222023-08-11T14%3A24%3A09.638Z%22%2C%22session%22%3A%7B%22invoca_id%22%3A%22i-6b848b88-e6bd-44e6-9b99-3fa78fc1745e%22%2C%22extendedSource%22%3A%22S_AIB_IPM_NSP_G_TM_SEA_CRS_LF_SALE_GM_ALL_INF_FIB_NA_BND_EXM_SEAR_NA_NA_Prospecting_NA_NA_NA_CPC%3BATT%20Trademark%20IF%20Core%20Brand%20Terms%20-%20at%26t%3B700000001899547%3Bat%26t%22%2C%22gclid%22%3A%22Cj0KCQjwnrmlBhDHARIsADJ5b_k2q7Y5epk8EzPxdV3ygj1lO6Oq6mGxu0MkIGqSRakq_x7uDuC-oFMaAmmtEALw_wcB%22%2C%22source_code%22%3A%22ECBB0000000CE100P%22%7D%2C%22config%22%3A%7B%22ce%22%3Atrue%2C%22fv%22%3Afalse%2C%22rn%22%3Afalse%7D%7D; faqMode=INTRANET; JSESSIONID=E9B1C8F22575B4ADCCCAB44C7D49FC0C; atlassian.xsrf.token=B4VT-QE2G-5BVD-UR7T_ad6af7817849738f79f0b874b60ae058c987c8a1_lin"

Object.keys(cookies).forEach(c => {
    let rx = new RegExp(`${c}=([^;]*)`)
    let m = cookie.match(rx)
    cookies[c] = m[1]
})



app.get('/', (req,res) => {
    if (req.query.issue) {
        getJira(cookies, req.query.issue, res)
        //getJira sends the response since the call to jira  is async
    } 
    else {
        if (req.query.cookie) {
            Object.keys(cookies).forEach(c => {
                let rx = new RegExp(`${c}=([^;]*)`)
                let m = req.query.cookie.match(rx)
                cookies[c] = m[1]
            })       
            msg=`Cookie loaded...<p>Issue Name: <input type=text name=issue /><input type=submit >`
        } else {
        msg=`This is experimental...  Bring down the server after you are done.
          <ul>
            <li>first pick another tab on the browswer and log onto Jira</li>
            <li>after login, from the chrome menu select view->developer->developer tools</li>
            <li>in the developer tool pane, select "network" tab</li>
            <li>you will see a graph, underneath it should be a list of objects, pick the top object (usually user story name)</li>
            <li>on the right pane, click on 'headers' tab</li>
            <li>scroll down to the 'request header' section, and find the 'Cookie:' header</li>
            <li>Now cut and paste the cookie (many lines, until you see the start of the next header) in the below field/li>  
            <li>you should only do this once every few hours (the cookie has an expiration)</li>
            <li><b>bring down the server when you are done</li>
            </ul>        
            Load the cookie<br><input type=text name=cookie style='width: 200px; height: 100px' /><input type=submit >`
        }
        part1='</html><body><form >'
        part2='</form></body></html>'
        res.send(part1+msg+part2)
    }
})


app.listen(port, () => {
    console.log(`listening on port ${port}`)
})


const issueRoot = '/rest/api/2/issue/'
const jiraHost = 'jira.web.labs.att.com'

issueName='UMNAST-623'
issueName='UMNAST-608'
issueName='AINLM-25'
//issueName='OPNAST-451'

function getJira(cookies, issue, xres) {
    options = {
        'hostname' : jiraHost,
        'path' : issueRoot + issue,
        headers: {
            'Cookie' : Object.keys(cookies).map(x => `${x}=${cookies[x]}`).join('; ')
        }
    }
    let request = https.get(options, (res) => {
        var data=''
        res.on('data', (chunk) => {
            data += chunk
        }) 
        res.on('close', () => {
            response = res.statusCode === 200 ? data : data;
            xres ? xres.json(JSON.parse(response)) : console.log(JSON.stringify(response))
        })
    })
}

function metadata(comments) {
     return comments.filter(x => x.body.includes('$${'))
                    .map(x => {
                        try {
                            return JSON.parse(x.body.match(/\$\$(\{.*\})/)[1]
                                .replace(/([a-z][^:]*)(?=\s*:)/g, '"$1"'))
                        } catch (e) {
                            return {errno: -1, errstr: "cannot parse metadata"}
                        }
                    }).reduce((a,x) => Object.assign(a, x), {})
}

function results2(r) {
    var f = r.fields
    console.log(JSON.stringify(f, null, '   '))  
}
function results(r) {
    var f = r.fields
    var issue = {
        id: r.key,
        url: r.self,
        type: f.issuetype.name,
    }
    if ('project' in f) {
        Object.assign(issue, {team: f.project.key, teamName: f.project.name})
    }
    if ('comment' in f) {
        issue.mdata = metadata(f.comment.comments)
    }
    if ('issuelinks' in f) {
        Object.assign(issue, { 
            parents: f.issuelinks.filter(x => 'outwardIssue' in x).map(x => x.outwardIssue),
            children: f.issuelinks.filter(x => 'inwardIssue' in x).map(x => x.inwardIssue)
        })
    }
    if ('assignee' in f) {
        issue.assignee =  {
                attuid: (k = f.assignee).name,
                displayName: k.displayName,
                emailAddress: k.emailAddress
        }
    }
    
    var customMap= {15307: 'supportedBy'}
    Object.keys(customMap).forEach(k => {
        try {
            issue[customMap[k]] = f[`customfield_${k}`]
        } catch (e) {
            ;
        }
    })
    console.log(issue)
    console.log('====================================')
    if (issue.children) {
        issue.children.forEach(i => results(i))
    }
}
