import debugpy
debugpy.listen(('0.0.0.0', 4304))
debugpy.wait_for_client()
a = [1,3,4]
for i in a:
    print(i)
print('done')
