mkdir -p templates static
cp gui/dist/gui/index.html templates/
cp -r gui/dist/gui/* static/
