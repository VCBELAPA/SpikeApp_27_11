# get llama index from below:
#    https://pypi.org/project/llama-index/
#  or
#    pip3 install llama-index (or pip install llama-index based on your python installation)

simulator = False

import sys, os, re
# make sure you set 'OPENAI_API_KEY' to your os key from openAI
from flask import Flask, Response, jsonify, request, render_template, send_file
from llama_index import SimpleDirectoryReader, GPTVectorStoreIndex, StorageContext, load_index_from_storage

rootDir = os.path.dirname(os.path.realpath(__file__))

loadedDataset=''
query_engine = None

#data sets are in location corresponding to index: dataset[0] is in data0, storage0, etc.



app = Flask(__name__)


@app.route('/assets/<id>', methods=['GET'])
def asset_file(id):
    return send_file('gui/dist/gui/assets/' + id)


@app.route('/', methods=['GET'])
def root():
    return render_template('index.html') # Return index.html 

@app.route("/help")
def apis():
    return '''
    <html><body>
    <h2>APIs</h2>
    <table>
        <tr><td>/list :</td><td>list datasets (json array)</td></tr>
        <tr><td>/query/<dataset> :</td><td>[POST]send a query, requires post variable 'prompt'</td></tr>
        <tr><td>/upload/<dataset> :</td><td>[POST]uploads a file to a dataset & rebuilds the index</td></tr>
        <tr><td>/create/<dataset> :</td><td>[POST]creates a blank dataset</td></tr>
        <tr><td>/download/<dataset> :</td><td>downloads the file from a dataset</td></tr>
        <tr><td>/remove/<dataset>/<file> : </td><td>Removes a file from a data set and rebuilds the index</td></tr>
        <tr><td>/drop/<dataset> : </td><td>removes a dataset completely
    </table>
    '''
cannedResponse={
        "extra_info": {
            "48de7a38-f383-4cc2-9ccd-55a65ea20f91": {
                "file_name": "CEI User Manual_v1.pdf",
                "page_label": "11"
            },
            "5fd406c8-18d8-4713-b46b-0d2c4e690ee1": {
                "file_name": "CEI User Manual_v1.pdf",
                "page_label": "1"
            }
        },
        "response": "\nINL is an acronym for Inventory Network Link, which is a link between ServiceNow and the Cisco MPLS network that allows for automated circuit creation.",
        "source_nodes": [
            {
                "node": {
                    "doc_hash": "7d12b7c88fb1dde0421fb6162baef9746718c0f016fc1a49217c6a37da6b37aa",
                    "doc_id": "48de7a38-f383-4cc2-9ccd-55a65ea20f91",
                    "embedding": None,
                    "extra_info": {
                        "file_name": "CEI User Manual_v1.pdf",
                        "page_label": "11"
                    },
                    "node_info": {
                        "_node_type": "1",
                        "end": 282,
                        "start": 0
                    },
                    "relationships": {
                        "1": "0f073c92-1314-4960-bf9f-cc6a3e101ba1"
                    },
                    "text": "ServiceNow - Circuit Emulation (CEM) User Guide Version 1.0 4/21/2023     \n Once the user finishes entering the data, click on the submit to send the provisioning request to EPNM and creating inventory record in ServiceNow. ServiceNow will take the user to MPLS Tunnel table.      \n"
                },
                "score": 0.635094502097136
            },
            {
                "node": {
                    "doc_hash": "2ebe89d77cdd4e7472df022389673500be97d4e00d113b4a8f3173bca0bbb54c",
                    "doc_id": "5fd406c8-18d8-4713-b46b-0d2c4e690ee1",
                    "embedding": None,
                    "extra_info": {
                        "file_name": "CEI User Manual_v1.pdf",
                        "page_label": "1"
                    },
                    "node_info": {
                        "_node_type": "1",
                        "end": 916,
                        "start": 0
                    },
                    "relationships": {
                        "1": "dd556ac6-6ecc-4568-989f-af13c7790ce6"
                    },
                    "text": "ServiceNow - Circuit Emulation (CEM) User Guide Version 1.0 4/21/2023        ServiceNow - Circuit Emulation (CEM) User Guide   Purpose:  This user guide is for AT&T Employees and contractors who have need to use the automated circuit creation features implemented within ServiceNow (ServiceNow) as part of the CEM migration process. The application is known as Circuit Emulation Inventory (CEI), this application is intended for the Service Delivery Circuit design teams will give them the ability to port the CEM services over to the Cisco MPLS network and keep the network in synch with the ServiceNow inventory.   The guide walks step by step through the screens needed to accomplish the basic provisioning tasks of provisioning CEM services with the ServiceNow Circuit Emulation Inventory (CEI) application. This guide is written intended for someone with NO prior experience with the ServiceNow (ServiceNow).   "
                },
                "score": 0.633367267174356
            }
        ]
    }

@app.after_request
def cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response

@app.route("/list")
def listDatasets():
    myfiles = os.listdir(rootDir)
    mysets = (re.match("^data_([^ ]+)$",d).group(1) for d in myfiles if re.match("^data_",d))
    details = {}
    for d in mysets:
        details[d] = os.listdir(os.path.join(rootDir,'data_%s' % d))
    return jsonify({'status': 0, 'response': details})

@app.route("/query/<dataset>", methods=["POST"])
def query(dataset):
    error = []
    prompt = request.form.get("prompt")
    if not prompt:
        error.append("missing prompt")
    elif dataset != loadedDataset:
        if checkDataset(dataset):
            storagedir = os.path.join(rootDir, 'storage_' + dataset )
            storage_context = StorageContext.from_defaults(persist_dir=storagedir)
            index = load_index_from_storage(storage_context)
            if not simulator:
                query_engine = index.as_query_engine() #query engine is global
        else:
            error.append("dataset %s doesn't exist" % dataset)

    if not error:
        response = query_engine.query(prompt) if not simulator else cannedResponse
        return jsonify({'status': 0, 'response' : response})
    else:
        return jsonify({'status': -2, 'error': ','.join(error)})
    
@app.route("/upload/<dataset>", methods=["POST"])
def upload(dataset):
    error = []
    if not checkDataset(dataset):
        error.append('Invalid dataset')
    if 'myfile' not in request.files:
        error.append('Upload form corrupted (no "myfile" object)')
    if not error:
        myfile = request.files['myfile']
        if myfile.filename == '':
            error.append('no file selected')
        else:
            #ensure filename doesnot have a directory component
            fname = os.path.basename(myfile.filename)
            myfile.save(os.path.join(rootDir, 'data_'+dataset, fname))
            if not simulator:
                documents = SimpleDirectoryReader(os.path.join(rootDir, 'data_'+dataset)).load_data()
                index = GPTVectorStoreIndex.from_documents(documents)
                index.storage_context.persist(persist_dir=os.path.join(rootDir, 'storage_'+dataset))
            return jsonify({"status": 0})
    
    #if you get here, then you have an error
    return jsonify({"status": -2, "error": ",".join(error)  })


@app.route("/drop/<dataset>")
def drop(dataset):
    return "Would drop %s but this function is not yet implemented" % dataset

@app.route("/create/<dataset>", methods=['POST'])
def create(dataset):
    if checkDataset(dataset):
        return jsonify({'status': -2, 'error': 'Dataset %s already exists' % dataset})
    else:
        os.mkdir(os.path.join(rootDir, 'data_%s' % dataset))
        os.mkdir(os.path.join(rootDir, 'storage_%s' % dataset))
        return jsonify({'status' : 0 })

def checkDataset(dataset):
    return os.path.isdir(os.path.join(rootDir, 'data_' + dataset )) and os.path.isdir(os.path.join(rootDir, 'storage_' + dataset))

if __name__ == "__main__":
    app.run(host='localhost', port=4300)

