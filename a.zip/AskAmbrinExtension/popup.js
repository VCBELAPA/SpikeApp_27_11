let newButton = document.getElementById("click_button");
let storyButton = document.getElementById("story_button");
newButton.addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { "message": "create_button" });
});

storyButton.addEventListener("click", async () => {
    let inputtag = document.querySelector("#name");
    chrome.storage.sync.set({ 'us_name': inputtag.value });
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    console.log('sending message');
    chrome.tabs.sendMessage(tab.id, { "message": "generate_story", "prompt": inputtag.value });
});

document.addEventListener("DOMContentLoaded", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab.url.includes("jira.web.labs.att.com")) {
        const container = document.getElementsByClassName("container")[0];

        container.innerHTML = '<div class="title">This is not a Jira page.</div>';
    }
});
