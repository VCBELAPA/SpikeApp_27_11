// background.js
chrome.runtime.onInstalled.addListener(function () {
    console.log("Hello from background");
});

chrome.runtime.onMessage.addListener(function (request, sender, callback) {
    postRequest(request).then(data=>{
        console.log(data);
        callback(data);
    });
    return true;
});

async function postRequest(request) {
    if (request.action == "xhttp") {
        const response = await fetch(request.url, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, *cors, same-origin
            cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
            credentials: "same-origin", // include, *same-origin, omit
            headers: {
                "Content-Type": "application/json",
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            //redirect: "follow", // manual, *follow, error
            //referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
            body: JSON.stringify(request.data), // body data type must match "Content-Type" header
        });
        const data = await response.json();
        console.log(JSON.stringify(data));
        return data;
    }
}


