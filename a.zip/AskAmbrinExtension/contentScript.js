chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if( request.message === "generate_story" ) {
            chrome.runtime.sendMessage({
                method: 'POST',
                action: 'xhttp',
                url: 'https://askambrin.att.com/api/prompt_route/test/sp030n',
                data: {
                    "user_prompt" : request.prompt
                },
                tab_id: request.teb_id
            }, function(responseText) {
                chrome.storage.sync.set({ 'api_response': responseText });
                console.log(JSON.stringify(responseText));
                updateUI();
                /*Callback function to deal with the response*/
            });
        } else if ( request.message === 'create_button') {
            var link_button = document.getElementById("create_link");
            link_button.click();
        } else if ( request.message === 'api_response') {
            console.log('receving response from background');
            console.log(request.response);
        }
    }
);

function updateUI() {
    chrome.storage.sync.get(["us_name", "api_response"]).then((result) => {
        console.log(result.us_name);
        const description_text = result.api_response['Answer'];
        var summary = document.getElementById("summary");
        summary.value = result.us_name;
        var iframe = document.querySelector('#description-wiki-edit iframe');
        var description = iframe.contentWindow.document.getElementsByTagName("p")[0];
        description.innerText = description_text;
    });
}

