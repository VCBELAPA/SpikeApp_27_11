Instructions for setting up environments and running backend:
Run start.sh file
Command to run flask application locally:
flask --app run_Llama2 run -p port_number
Command to run flask application in Prod:
flask --app run_Llama2 run --host 0.0.0.0 -p 8082 
Note: when you run the backend you will be prompted to enter if you will lie to connect the APIs to the DB. Enter True if so, else enter False

Instructions for activating python virtual environment in lab2:
cd to root
Run command source lab2/bin/activate

Instructions for running Ingest program:
Run command python ingest.py
You will then be prompted to enter the name of the folder under documents that contains the pdfs you need to ingest and will be prompted to enter the name of the vector db to save the files in
