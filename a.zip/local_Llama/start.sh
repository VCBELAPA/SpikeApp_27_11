#!/bin/bash
pip install -r requirements.txt
cp environment.env .env
huggingface-cli login --token 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
