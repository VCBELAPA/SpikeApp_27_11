import logging
from langchain import PromptTemplate, LLMChain
import transformers
import os
import shutil
import subprocess
from datetime import date
import numpy as np
import torch
from langchain.llms import BaseLLM
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainExtractor
from chromadb.config import Settings
from flask import Flask, jsonify, request
from langchain.chains import RetrievalQA
from langchain.embeddings import HuggingFaceInstructEmbeddings
import psycopg2
from psycopg2 import Error
from psycopg2.extras import RealDictCursor
import re
import sys
from transformers import AutoModelForSeq2SeqLM
from langchain.schema import BaseOutputParser
import time
from langchain.chains import ConversationChain
# from langchain.embeddings import HuggingFaceEmbeddings
from langchain.llms import HuggingFacePipeline
from transformers import StoppingCriteria, StoppingCriteriaList
from typing import List
from ingest import ingest_single_text
# from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.vectorstores import Chroma
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    GenerationConfig,
    LlamaForCausalLM,
    LlamaTokenizer,
    pipeline,
)
from werkzeug.utils import secure_filename
from constants import CHROMA_SETTINGS, EMBEDDING_MODEL_NAME, PERSIST_DIRECTORY


DEVICE_TYPE = "cuda"
SHOW_SOURCES = True
logging.info(f"Running on: {DEVICE_TYPE}")
logging.info(f"Display Source Documents set to: {SHOW_SOURCES}")

EMBEDDINGS = HuggingFaceInstructEmbeddings(model_name=EMBEDDING_MODEL_NAME, model_kwargs={"device": DEVICE_TYPE})


# load Technical Info Vector DB
vector_db = Chroma(
    persist_directory=PERSIST_DIRECTORY,
    embedding_function=EMBEDDINGS,
    client_settings=CHROMA_SETTINGS,
)

RETRIEVER = vector_db.as_retriever(search_kwargs={"k": 1})

def format_template_with_docs(template, docs):
    start_position = template.find("{us_story_vector_db_docs}")
    end_position = start_position + 24
    template = template[:start_position] + docs + template[end_position:]
    return template

def Return_Context(RETRIEVER, user_prompt, template, placeholder):
    results = RETRIEVER.get_relevant_documents(user_prompt)
    context = ""
    for document in results:
        context += document.page_content 
    if placeholder == "vector_db_context":
        start_position = template.find("{vector_db_context}")
        end_position = start_position + 18
    elif placeholder == "vector_db_us":
        start_position = template.find("{vector_db_us}")
        end_position = start_position + 13
    template = template[:start_position] + context + template[end_position:]
    return template, results


# load the LLM for generating Natural Language responses
def load_model(model_dir):
    print(f"Loading model from: {model_dir}") 
    tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True, padding=True, truncation=True)
    model = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=torch.bfloat16, device_map="auto")
    pipe = pipeline(
        "text-generation",
        model=model_dir,
        device_map="auto", 
        #max_new_tokens = 250,
        max_new_tokens = 150,
        temperature=0,
        #top_p=0.6,
        top_p=0.25,
        repetition_penalty=1.5
    )
    local_llm = HuggingFacePipeline(pipeline=pipe)
    logging.info("Local LLM Loaded")    
    return local_llm


LLM = load_model("meta-llama/Llama-2-13b-chat-hf")
template = """
Context:
{context}
Use the given Context for the information needed to answer a question.
If the information needed to answer the question is not in context then tell the user that you cannot answer the question.\n
Question: {question}\n Answer:"""

use_db = input("Would you like to connect APIs to db? If so enter True, else enter False: ")
if use_db == True:
    db = DB()
else:
    db = None

QA_CHAIN_PROMPT = PromptTemplate(input_variables=["context", "question"], template=template)
QA = RetrievalQA.from_chain_type(llm=LLM, 
    chain_type="stuff", retriever=RETRIEVER, 
    return_source_documents=SHOW_SOURCES,
    chain_type_kwargs={"prompt": QA_CHAIN_PROMPT})

app = Flask(__name__)

@app.after_request
def cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = '*'
    return response


#Ingest PDF Documents
@app.route("/Ingest_PDFS/<domain>/<attuid>", methods=['POST'])
def ingestPDFS(domain, attuid):
    try:
        global vector_db
        global RETRIEVER
        global QA
        files = request.files.getlist('files')
        for file in files:
            if file.filename == "":
                return "No selected file", 400
            if file:
                filename = secure_filename(file.filename)
                folder_path = "/home/lab2/ainlm/Documents/SOURCE_DOCUMENTS"
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
                file_path = os.path.join(folder_path, filename)
                file.save(file_path)
                #Ingest Text
                vector_db = ingest_single_text(document=None, document_name=filename, DB=vector_db, PDF=True, document_path=file_path)
                
        response = {"response":"Documents have been saved successfully"}
        return response, 200
    
    except(Exception, Error) as error:
            print(error)
            prompt_response_dict['error'], prompt_response_dict['Status'] = str(error), -1
            return prompt_response_dict, 400

#Ingest Text
@app.route("/Ingest_Text/<domain>/<attuid>", methods=['POST'])
def ingestDocument(domain, attuid):
    try:
        global vector_db
        global RETRIEVER
        global QA
        Text = request.json['Text']
        File_Name = request.json['File Name']
        destination_file = "/home/lab2/ainlm/Documents/SOURCE_DOCUMENTS/" + File_Name
        with open(destination_file, 'w') as file:
            file.write(Text)
        #Ingest Text
        vector_db = ingest_single_text(document=Text, document_name=File_Name, DB=vector_db, PDF=False, document_path=None)
        '''RETRIEVER = vector_db.as_retriever()
        QA = RetrievalQA.from_chain_type(
            llm=LLM, chain_type="stuff", retriever=RETRIEVER, return_source_documents=SHOW_SOURCES, chain_type_kwargs={"prompt": QA_CHAIN_PROMPT})'''
        return {"response":"Text has been successfully saved"}, 200

    except(Exception, Error) as error:
            response = {"error":str(error), "Status":-1}
            return response, 400
    

#Remove inputted document from Vector DB
@app.route("/Remove_Document/<domain>/<attuid>", methods=['POST'])
def removeDocument(domain, attuid):
    try:
        global vector_db
        global RETRIEVER
        global QA
        document_name = request.json['Document_Name']
        # Define the search query and filter
        doc_info = vector_db.get(where={"source": document_name})
        if doc_info["ids"] == []:
            response = {"error":f"{document_name} does not exist in the vector db", "Status":-1}
            return response, 400
        for doc_id in doc_info["ids"]:
            vector_db.delete(doc_id)
        vector_db.persist()
        return {"response":"Document has been succsefully removed from the vector db", "Status":0}, 200

    except(Exception, Error) as error:
            print(error)
            prompt_response_dict['error'], prompt_response_dict['Status'] = str(error), -1
            return prompt_response_dict, 400


#Prompt the LLM
@app.route("/api/prompt_route/<domain>/<attuid>", methods=["POST"])
def prompt_route(domain, attuid):
    user_prompt = request.json["user_prompt"]
    global db
    global QA
    prompt_response_dict = {"Prompt" : user_prompt, "Status":0}
    if use_db == True:
        if user_prompt:
            try:
                #Store question, attuid, domain in question table
                cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
                if domain.isnumeric():  # if a number use it, else need to look it up
                    values = "values (%(domain)s, %(attuid)s, %(question)s)"
                else:
                    values = "select d.id, %(attuid)s, %(question)s from domain d where d.name = %(domain)s"

                cursor.execute("insert into question (domain, attuid, question) %s" % (values),
                            {"domain": domain, "attuid": attuid, "question": user_prompt}
                )
                cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
                db.commit()
                #Get Question ID
                question_id = cursor.fetchone()[0]
                #Input Prompt into model and get Answer
                start = time.time()
                res = QA(user_prompt)
                ans, docs = res["result"], res["source_documents"]
                end = time.time()
                Time = round(end - start, 2)
                prompt_response_dict["Answer"] = ans
                prompt_response_dict["Question Id"] = question_id
                prompt_response_dict["Time"] = Time
                prompt_response_dict["Sources"] = []
                for document in docs:
                    prompt_response_dict["Sources"].append((os.path.basename(str(document.metadata["source"])), str(document.page_content)))
                #Store Answer 

                cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
                cursor.execute("insert into answer (question, answer) values (%(qid)s, %(answer)s)",
                            {"qid": question_id, "answer": ans}
                )
                cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
                db.commit()
                #Get Answer ID
                answer_id = cursor.fetchone()[0]
                prompt_response_dict["Answer ID"] = answer_id
                return prompt_response_dict, 200
            except(Exception, Error) as error:
                print(error)
                prompt_response_dict['error'], prompt_response_dict['Status'] = str(error), -1
                return prompt_response_dict, 400
        else:
            return 'Missing required "question" parameter', 400
    else:
        if user_prompt:
            try:
                #Input Prompt into model and get Answer
                start = time.time()
                res = QA(user_prompt)
                ans, docs = res["result"], res["source_documents"]
                end = time.time()
                Time = round(end - start, 2)
                prompt_response_dict["Answer"] = ans
                prompt_response_dict["Time"] = Time
                prompt_response_dict["Sources"] = []
                for document in docs:
                    prompt_response_dict["Sources"].append((os.path.basename(str(document.metadata["source"])), str(document.page_content)))
                return prompt_response_dict, 200
            except(Exception, Error) as error:
                print(error)
                prompt_response_dict['error'], prompt_response_dict['Status'] = str(error), -1
                return prompt_response_dict, 400
        else:
            return 'Missing required "question" parameter', 400


#Send back Feedback
@app.route('/feedback/<answerId>', methods=['POST'])
def createFeedback(answerId):
    '''creates a an answer in the database for the question; must pass question id
        post variables: (at least one is required)
            rating 0-10; but can be any number
            comment: text with a comment
            myanwer: the answer provided by the user
            context_rating 0 or 10: rating for how well vector db returned info relvant to users question 
        returns:
            {status: 0|-errcode, response: id}  'id' is the is the id of this particular feedback
    '''
    global db
    if use_db == True:
        rv={"status": 0}
        #set any unprovided value to blank '' (distinguish between 0 and '' for rating)
        values = request.json["values"]
        
        param=list(map(lambda x: values[x] if x in values else '',
                    ['rating', 'comment', 'myanwer']))
                #, 'context_rating']))
        if len(list(filter(lambda x: x, param))) > 0: # have at least one of them
            try:
                cursor = db.cursor() #note this always returns arrays and not dicts (names=None)
                #note in the db, if rating is not provided, it will be set to -1
                cursor.execute("""insert into feedback (answer, rating, comment, myanswer) values (%s, %s, %s, %s)""",
                        [answerId, param[0] if param[0] else -1] + param[1:]
                )
                cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
                db.commit()
                rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
            except(Exception, Error) as error:
                print(error)
                rv['error'], rv['status'] = str(error), -1
        else:
            rv['error'], rv['status'] = 'Must provide at least one of rating, comment, or myanswer', -2
        return jsonify(rv)
    else:
        return {"Response": "Feedback was not saved due to DB not being activated"}
        
#Returns documents ingested for a vector db in the given domain (currently only one domain is supported) and the document count for that vector db
@app.route('/vector_db/<domain>/<attuid>', methods=['GET'])
def retrieveDbDocuments(domain, attuid):
    global vector_db
    global RETRIEVER
    try:
        ids = vector_db.get()
        documents = np.array([])
        for metadata in ids["metadatas"]:
            documents = np.append(documents, metadata["source"])
        documents = np.unique(documents)
        documents = documents.tolist()
        files_count = len(documents)
        response = {"documents": documents, "files count": files_count, "Status":0}
        return response, 200
    except(Exception, Error) as error:
            response = {"error":str(error), "Status":-1}
            return response, 400
    

class DB:
    def __init__(self):
        self._db = None
    def cursor(self, names=False):
        return self._conn().cursor(cursor_factory=RealDictCursor if names else None)
    def commit(self):
        # nothign to commit if there is no db!
        if self._db:
            self._db.commit()
    def _conn(self):
        if not self._db:
            self._db = psycopg2.connect(user="ainlm",
                            password="ainlm",
                            host="127.0.0.1",
                            port="5432",
                            database="ainlm")
        return self._db

if __name__ == "__main__":
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(filename)s:%(lineno)s - %(message)s", level=logging.INFO
    )
    app.run(debug=True, port=4500)
