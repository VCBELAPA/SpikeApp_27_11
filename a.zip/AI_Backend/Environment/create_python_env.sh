#!/bin/bash
#Run this script from the user's environment
echo "Enter the user's attuid: "
read attuid
echo "You entered $attuid"

#Create python env and install packages
VENV_DIR=/home/$attuid/python_env

python3 -m venv $VENV_DIR

pip3 install -r "requirements.txt"
if [ $? -ne 0 ]; then
    echo "Error failed to install all packages. To activate the environment enter source /home/$attuid/python_env/bin/activate"
    exit 1
fi
echo "All packages installed successfully. To activate the environment enter source /home/$attuid/python_env/bin/activate"
