#!/bin/bash
#Script to install backend environment dependencies for prod and dev servers
#and start docker server containers (neo4j for knowledge graph and text-generation-inference for Llama2 inference)

#Create and activate python virtual environment
VENV_DIR=~/poc1

python3 -m venv $VENV_DIR

source $VENV_DIR/bin/activate

sudo apt install postgresql

pip3 install -r ./requirements.txt

#Build and run neo4j graph database
chmod +x ../Server/start_neo4j
./../Server/start_neo4j.sh

#Build and run text generation inference server
chmod +x ../Server/start-text-generation.sh
./../Server/start-text-generation.sh

