#!/bin/bash
#Retrieve Server Ports
flags() {
    while test $# -gt 0; do
        case "$1" in
            -p|--production) export ENVIRONMENT_CONFIGS="production_configs.json" ;;
            -d|--development) export ENVIRONMENT_CONFIGS="test_configs.json" ;;
        esac
        shift
    done
}
flags "$@"

BACKEND_PORT=$(python3 -c "import json;
print(json.load(open('../Ask_Ambrin/configs/$ENVIRONMENT_CONFIGS'))['Ports']['backend'])")

RETRIEVER_TESTER_PORT=$(python3 -c "import json;
print(json.load(open('../Ask_Ambrin/configs/$ENVIRONMENT_CONFIGS'))['Ports']['retriever_tester'])")

if [ $ENVIRONMENT_CONFIGS == "production_configs.json" ]; then
    #Take down production backend server
    #Check if the backend server is running
    if fuser $BACKEND_PORT/tcp; then
        #if so then kill its process id 
        fuser -k $BACKEND_PORT/tcp
        echo "Killed the production backend server"
    else
        echo "The production backend server is not running"
    fi

    #Check if the retriever server is running
    if fuser $RETRIEVER_TESTER_PORT/tcp; then
        #if so then kill its process id 
        fuser -k $RETRIEVER_TESTER_PORT/tcp
        echo "Killed the production retriever server"
    else
        echo "The production retriever server is not running"
    fi 
else
    #Take down the development server
    #Check if the backend server is running
    if fuser $BACKEND_PORT/tcp; then
        #if so then kill its process id 
        fuser -k $BACKEND_PORT/tcp
        echo "Killed the development backend server"
    else
        echo "The development backend server is not running"
    fi
    #Check if the retriever server is running
    if fuser $RETRIEVER_TESTER_PORT/tcp; then
        #if so then kill its process id 
        fuser -k $RETRIEVER_TESTER_PORT/tcp
        echo "Killed the development retriever server"
    else
        echo "The development retriever server is not running"
    fi 
fi