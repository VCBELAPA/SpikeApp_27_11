#!/bin/bash
#Retrieve Server Ports
flags() {
    while test $# -gt 0; do
        case "$1" in
            -p|--production) export ENVIRONMENT_CONFIGS="production_configs.json" ;;
            -d|--development) export ENVIRONMENT_CONFIGS="test_configs.json" ;;
        esac
        shift
    done
}
flags "$@"

BACKEND_PORT=$(python3 -c "import json;
print(json.load(open('../Ask_Ambrin/configs/$ENVIRONMENT_CONFIGS'))['Ports']['backend'])")

RETRIEVER_TESTER_PORT=$(python3 -c "import json;
print(json.load(open('../Ask_Ambrin/configs/$ENVIRONMENT_CONFIGS'))['Ports']['retriever_tester'])")

#Activate python env and move to directory that contains server files
source ~/poc1/bin/activate
cd ../Ask_Ambrin
BACKEND_URL="localhost:${BACKEND_PORT}"
export BACKEND_URL="${BACKEND_URL}"

RETRIEVER_TESTER_URL="localhost:${RETRIEVER_TESTER_PORT}"
export RETRIEVER_TESTER_URL="${RETRIEVER_TESTER_URL}"

if [ $ENVIRONMENT_CONFIGS == "production_configs.json" ]; then
    #Start the production backend
    PRODUCTION_BRANCH="master"
    #Switch to the master branch
    git checkout $PRODUCTION_BRANCH
    if [ $? -eq 0 ]; then 
        backend_host=0.0.0.0
        gunicorn -w 1 -b localhost:$RETRIEVER_TESTER_PORT retriever_tester:app & disown
        gunicorn -w 1 -b $backend_host:$BACKEND_PORT backend:app & disown
        echo "Production Backend Started"
    else
        echo "Error: could not switch to master branch. Server was not started"
    fi
else
    #Start the development backend
    DEVELOPMENT_BRANCH="development"
    #Switch to the development branch
    git checkout $DEVELOPMENT_BRANCH
    if [ $? -eq 0 ]; then 
        backend_host=0.0.0.0
        gunicorn -w 1 -b localhost:$RETRIEVER_TESTER_PORT retriever_tester:app & disown
        gunicorn -w 1 -b $backend_host:$BACKEND_PORT backend:app & disown
        echo "Development Backend Started"
    else
        echo "Error: could not switch to development branch. Server was not started"
    fi
fi