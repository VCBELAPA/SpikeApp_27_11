model=meta-llama/Llama-2-70b-chat-hf
num_shard=4
volume=$PWD/../../inference-data
name="text-generation-inference"
token=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
sudo docker run --network llm_net --name $name --gpus all --shm-size 1g -p 8085:80 \
    -v $volume:/data -e HUGGING_FACE_HUB_TOKEN=$token \
    ghcr.io/huggingface/text-generation-inference:latest \
    --model-id $model --num-shard $num_shard \
    --max-input-length 4000 --max-total-tokens 4096

exit