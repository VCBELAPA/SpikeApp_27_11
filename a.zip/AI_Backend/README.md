# Backend DevOps
- To start the production backend server go into the Server folder and run the command ./start_backend.sh -p or ./start_backend.sh --production
- To start the development backend server go into the Server folder and run the command ./start_backend.sh -d or ./start_backend.sh --development
- To stop the production backend server go into the Server folder and run the command ./stop_backend.sh -p or ./stop_backend.sh --production
- To stop the production backend server go into the Server folder and run the command ./stop_backend.sh -d or ./stop_backend.sh --development
## NEO4J
    NEO4J is our graph database. The Neo4j graph database server runs in a docker container and the configurations can be found in the start_nero4j.sh file that is within the Server folder.
## Text-Generation-Inference
    The text generation inference serve is used to run inferences for the Llama2-70b model. Its configurations can be found within the start-text-generation.sh file that is within the Server folder.
## Setting Up Environment for New VM
    To install dependencies on a new vm, build and deploy the text-generation-inference server, and build and deploy the NEO4J server go into the Environment folder and run the setup.sh file
## Create New Environment for Developer in Development VM
### Create new user for each dev

```sh
# *** the below command has to be done my system admin ***.
sudo adduser ${attuid} # create a new user e.g. adduser jw570a. And follow the prompt to finished the user creation
```

```sh
# *** the below command has to be done my system admin ***.

# setup .ssh directory and user public keys
sudo su - ${attuid} # switch to the new user
mkdir -p .ssh && chmod 700 .ssh
cd .ssh
touch authorized_keys
chmod 600 authorized_keys

# then vi authorized_keys file to add developer's public key
```

Create a new pair of public and private ssh keys on vm new user account.

```sh
# creates a new paire of keys. Or user can copy paste their own keys from laptop to this VM.
ssh-keygen # keep hitting enter until finish
```

make sure your ssh public key is added to codecloud before you run the below clone command
steps for adding keys:

1. Go to codecloud.com and click upper right corner profile icon and then select *Manage Account*.
2. Then select *SSH Keys* and copy paste your own ssh pubic key (from id_rsa.pub file. use vi or cat command to see the content from it) into it.

```sh
# clone git repo to user's home directory
git clone ssh://git@10.19.5.14:2070/st_fed/ainlm2.git 
```
# set up virtual env
To setup a user's python virtual environment, go into the Environment folder and run the create_python_env.sh script