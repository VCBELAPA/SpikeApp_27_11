import os
from dotenv import load_dotenv

#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

from llama_index import (
    SimpleDirectoryReader,
    StorageContext,
    ServiceContext,
    KnowledgeGraphIndex,
    Document
)
from llama_index.graph_stores import SimpleGraphStore
from llama_index.graph_stores import Neo4jGraphStore
from langchain.llms import AzureOpenAI 
from llama_index.retrievers import KnowledgeGraphRAGRetriever

# using data from Wikipedia
from llama_index import download_loader
import json

dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files'
for file_path in os.listdir(dir_path):
    #Load single NDR document
    if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
        file_path = os.path.join(dir_path, file_path)
        with open(file_path, 'r') as f:
            NDR = json.load(f)
            break
paragraphs = ""
for section in NDR:
    if section == "metadata":
        continue
    else:
        for p in NDR[section]:
            paragraphs += p
    break
documents = [Document(text=paragraphs)]
llm = AzureOpenAI(deployment_name="text-davinci-003")
service_context = ServiceContext.from_defaults(llm=llm, chunk_size=512)
# neo4j database
username = "neo4j"
password = "ainlm_dev"
url = "bolt://localhost:7687"
database = "neo4j"
graph_store = Neo4jGraphStore(
    username=username,
    password=password,
    url=url,
    database=database
)
storage_context = StorageContext.from_defaults(graph_store=graph_store)
NDR_index = KnowledgeGraphIndex.from_documents(
    documents,
    storage_context=storage_context,
    max_triplets_per_chunk=2,
    service_context=service_context,
)
engine = NDR_index.as_query_engine()
response = engine.query("What is xleaf")
print(response.get_formatted_sources())

