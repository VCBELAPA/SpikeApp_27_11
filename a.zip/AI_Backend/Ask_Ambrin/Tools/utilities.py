import subprocess
import json
import sys
sys.path.append('./DB')       

def get_current_git_branch():
    try:
        result = subprocess.run(['git', 'branch', '--show-current'], 
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True)
        #Check if the command was successful
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            raise Exception( "Error: Could not load the current Git Branch")
    except Exception as error:
        return str(error)
    

