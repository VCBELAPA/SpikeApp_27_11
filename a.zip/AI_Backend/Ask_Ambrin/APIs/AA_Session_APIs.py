import sys
sys.path.append('../DB')       
from db import role_to_permissions, create_permissions_and_roles_in_db, remove_permissions_roles_and_db, check_user_roles_in_db, add_documents_to_db, remove_documents_from_db, get_all_documents_from_db, get_document_from_db

def create_session(app, request, session, db):
    try:
        cur = db.cursor()
        attuid = request.json["attuid"]
        session["attuid"] = attuid
        session["vector_db"] = {}
        cur.execute(f"SELECT * FROM user_permissions WHERE attuid = '{attuid}';")
        user_permissions = cur.fetchall()
        #Gets permissions of each role assigned to user for all vector dbs that user has role in 
        if user_permissions != []:
            user_roles = [row[0] for row in user_permissions]
            for role in user_roles:    
                cur = db.cursor()    
                cur.execute(f"SELECT * FROM permissions WHERE role = {role};")
                permissions = cur.fetchall()
                role_permissions = [row[0] for row in permissions]
                knowledge_base = permissions[0][1]
                cur = db.cursor()
                cur.execute(f"SELECT * FROM knowledge_base WHERE id = {knowledge_base};")
                knowledge_base = cur.fetchall()[0][0]
                session["vector_db"][knowledge_base] = role_permissions 
        cur.close()
        #For Inital AskAmbrin Deliverable the default knowledge base for all users will be P1P2
        if "P1P2" not in session["vector_db"].keys():
            requested_permissions, role_id = role_to_permissions("P1P2_User", db)
            cur = db.cursor()
            cur.execute(f"INSERT INTO user_permissions (role, attuid) VALUES ({role_id}, '{attuid}')")
            db.commit()
            cur.close()
            session["vector_db"]["P1P2"] = ["read"]
            app.logger.info(f'Adding {attuid} as {"User"} to {"P1P2"}')
        app.logger.info(f'Successfully initalized client session for {attuid}')
        return {'response':f"Client session for {attuid} has successfully been initalized", 'Status':0}, 200

    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error occured when initalizing session for a user. Error: {error}')
        return {'error': error, "Status":-1}, 400