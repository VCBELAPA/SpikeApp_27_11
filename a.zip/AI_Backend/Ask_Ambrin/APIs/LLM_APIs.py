import os
import json

from flask import Flask, jsonify, request, session, redirect, send_file
import requests

def prompt_llm(app, request, session, feedback_db, db, LLM, gpt_3_5, davinci, gpt4):
    try:
        db_cur = db.cursor()
        if "attuid" not in session.keys():
            app.logger.info(f'User requesting to send prompt to LLM does not have session initalized')
            #test url
            return redirect("https://askambrin.att.com/static/", code=302)
        vector_db = request.json["vector_db"]
        attuid = session["attuid"]
        prompt = request.json["prompt"]
        model = request.json["model"]
        if (vector_db in list(session["vector_db"].keys()) and 'read' in session["vector_db"][vector_db]):
            #Store question, attuid, domain in question table
            feedback_cur = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            db_cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{vector_db}' LIMIT 1;")
            knowledge_base_id = db_cur.fetchall()[0][1]
            #The prompt needs to be formatted to remove single quotes within the prompt to save in the db
            formatted_prompt = prompt.replace("'", "")
            feedback_cur.execute(f"insert into question (knowledge_base, attuid, question) values ({knowledge_base_id}, '{attuid}', '{formatted_prompt}');")
            feedback_cur.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            #Get Question ID                                                                                                                                                                                                                                                                                                                                                                                                                    
            question_id = feedback_cur.fetchone()[0]
            #Retrieve context and format template
            template = "Your task is not to define acronyms and abbreviations unless is given in the context, and also to give a direct response to what the user asks based on the given context and nothing else. Context: {prompt_context} User: {llm_prompt}? Response:"   
            #Retrieve four pieces of context
            response = requests.get("http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"paragraph", "retrieve count":4})
            if response.status_code == 200:
                contexts = response.json()
                app.logger.info(contexts)
            else:
                raise Exception("Error: could not retreive context")
            sections = [context["t"] for context in contexts]
            file_name = [context['fn'] for context in contexts]
            page_number = [context["pn"] for context in contexts]
            contexts = [context["p"] for context in contexts]
            prompt_context = ""
            for i, context in enumerate(contexts):
                prompt_context += (f"Fact {(i+1)} : " + context + "\n")
            llm_input = template.format(prompt_context=prompt_context, llm_prompt = prompt)
            #Prompt the LLM
            model = request.json["model"]
            if model == "Llama-2":
                ans = LLM(llm_input)
            elif model == "gpt-3.5":
                ans = gpt_3_5(llm_input)
            elif model == "davinci":
                ans = davinci(llm_input)
            elif model == "gpt4":
                ans = gpt4.predict(llm_input)
            #Store Answer 
            feedback_cur = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            feedback_cur.execute("insert into answer (question, answer) values (%(qid)s, %(answer)s)",
                            {"qid": question_id, "answer": ans}
                )
            feedback_cur.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            #Get Answer ID
            answer_id = feedback_cur.fetchone()[0]
            feedback_cur.close()
            db_cur.close()
            app.logger.info(f'User {attuid} has successfully prompted {model}')
            return {'model_response':ans, 'Status': 0, "Answer ID":answer_id, "Prompt":prompt, "Section Titles":sections, "Contexts":contexts, "file_name": file_name, "page_number": page_number}, 200
        else:
            return {"error": "User {attuid} does not have read permissions in {vector_db}", "Status": -1}, 400
    
    except Exception as error:
        db._db.rollback()
        feedback_db._db.rollback()
        app.logger.error(f'An error has occuered when user {attuid} attempted to prompt {model}. {error}')
        return {'error': f'An error has occuered when user {attuid} attempted to prompt {model}. {error}', 'Status':-1}, 400

def post_feedback(app, request, session, feedback_db, answerId):
    '''creates a an answer in the database for the question; must pass question id
        post variables: (at least one is required)
            rating 0-10; but can be any number
            comment: text with a comment
            myanswer: the answer provided by the user
            context_rating 0 or 10: rating for how well vector db returned info relvant to users question 
        returns:
            {status: 0|-errcode, response: id}  'id' is the is the id of this particular feedback
    '''
    rv={"status": 0}
    #set any unprovided value to blank '' (distinguish between 0 and '' for rating)
    values = request.json["values"]

    try:
        feedback_json = 'feedback.json'
        question = values['question']
        answer = values['myanswer']
        if answer != "":
            embedded_question = requests.get(f"{os.environ['RETRIEVER_TESTER_URL']}/embed", params={'sentence':question})
            if embedded_question.status_code != 200:
                return {'error' : str(embedded_question.content)}, 500  
            if not os.path.isfile(feedback_json):
                with open(feedback_json, 'w') as file:
                    json.dump([], file)
            with open(feedback_json, 'r+') as file:
                data = json.load(file)
                embedding = embedded_question.json()['embedding']
                new_entry = {'question_encoded' : embedding, 'answer' : answer}
                data.append(new_entry)
                file.seek(0)
                json.dump(data, file)
    except Exception as exc:
        return {'error' : str(exc)}, 500        

    param=list(map(lambda x: values[x] if x in values else '',
                    ['rating', 'comment', 'myanswer']))
    #, 'context_rating']))
    if len(list(filter(lambda x: x, param))) > 0: # have at least one of them
        try:
            cursor = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            #note in the db, if rating is not provided, it will be set to -1
            cursor.execute("""insert into feedback (answer, rating, comment, myanswer) values (%s, %s, %s, %s)""",
                        [answerId, param[0] if param[0] else -1] + param[1:]
                )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
            cursor.close()
            app.logger.info(f"Successfully saved feedback in DB for {param}")
        except Exception as error:
            app.logger.error(f"An error has occured while saving feedback in DB for {param}")
            feedback_db._db.rollback()
            rv['error'], rv['status'] = str(error), -1
    else:
        app.logger.error('Must provide at least one of rating, comment, or myanswer')
        rv['error'], rv['status'] = 'Must provide at least one of rating, comment, or myanswer', -2
    return jsonify(rv)