import os
import requests

def return_similar_embeddings_api(app, request):
    try:
        prompt = request.json["prompt"]
        similarity_search_text = request.json["similarity search text"]
        retrieve_count = request.json["retrieve count"]
        if similarity_search_text == "sentence":
            response = requests.get(f"http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"sentence", "retrieve count":retrieve_count})
            if response.status_code == 200:
                contexts = response.json()
            else:
                raise Exception("Error: could not retreive context")
        elif similarity_search_text == "paragraph":
            response = requests.get(f"http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"paragraph", "retrieve count":retrieve_count})
            if response.status_code == 200:
                contexts = response.json()
            else:
                raise Exception("Error: could not retreive context")
        else:
            raise Exception("Error: invalid similarity seach text type provided")
        sections = [context["t"] for context in contexts]
        file_names = [context["f"] for context in contexts]
        prompt_contexts = [context["p"] for context in contexts]
        similarity_score = [context["s"] for context in contexts]
        file_name = [context["fn"] for context in contexts]
        page_number = [context["pn"] for context in contexts]
        return {"context":prompt_contexts, "File Names":file_names, "Section Titles":sections, "Similarity Score" : similarity_score, "file_name": file_name, "page_number": page_number}, 200
        
    except Exception as error:
        return {"error": str(error)}, 400

def query_kg_api(app, request):
    try:
        query = request.json["prompt"]
        headers={
            'Content-type':'application/json', 
            'Accept':'application/json'
        }
        data = {"query":query}
        timeout_seconds = 600
        response = requests.post(f"{os.environ['RETRIEVER_TESTER_URL']}/knowledge_graph/NDR/query", json=data,headers=headers, timeout=timeout_seconds)
        response.raise_for_status()
        if response.status_code == 200:
            contexts = response.json()
        else:
            raise Exception("Error: could not retreive context")
        return contexts, 200
    except Exception as error:
        app.logger.error(str(error))
        return {"error": str(error)}, 400
