
def prompt_llm_api(app, request, Test_LLM, gpt_3_5, davinci, gpt4):
    try:
        prompt = request.json["prompt"]
        contexts = request.json["context"]
        if "template" not in request.json.keys():
            template = "Your task is not to define acronyms and abbreviations unless is given in the context, and also to give a direct response to what the user asks based on the given context and nothing else. Context: {prompt_context} User: {llm_prompt}? Response:"   
        else:
            template = request.json["template"]
        prompt_context = ""
        for i, context in enumerate(contexts):
            prompt_context += (f"Fact {(i+1) : } " + context + "\n")
        finalized_prompt = template.format(prompt_context=prompt_context, llm_prompt = prompt)
        #Prompt the LLM
        model = request.json["model"]
        if model == "Llama-2":
            answer = Test_LLM(finalized_prompt)
        elif model == "gpt-3.5":
            answer = gpt_3_5(finalized_prompt)
        elif model == "davinci":
            answer = davinci(finalized_prompt)
        elif model == "gpt4":
            answer = gpt4.predict(finalized_prompt)
        return {"answer":answer}, 200
    except Exception as error:
        return {"error":str(error)}, 400