from flask import Flask, jsonify, request, session, redirect, send_file
import requests
from lxml import etree                                                                                                                                                                                                                                                                                                 
from datetime import timedelta                                
import logging          
import sys
sys.path.append('DB')       
sys.path.append('Tools')      
sys.path.append('APIs')    
sys.path.append('APIs/Test_Ask_Ambrin_APIs')      

from test_embeddings_apis import return_similar_embeddings_api, query_kg_api

from test_llm_apis import prompt_llm_api

from AA_Session_APIs import create_session

from Knowledge_Base_APIs import (
    return_user_kb,
    vector_db,
    pdf_management,
    manage_permission,
    return_allFilesList,
    pdf_download

)
from LLM_APIs import (
    prompt_llm,
    post_feedback,

)
from db import DB           
from db import role_to_permissions, create_permissions_and_roles_in_db, remove_permissions_roles_and_db, check_user_roles_in_db, add_documents_to_db, remove_documents_from_db, get_all_documents_from_db, get_document_from_db
import numpy as np 
import os
import json
from flask_cors import CORS
from flask_session import Session  # Import Session
#import milvus_db
#from milvus_db import create_knowledge_base, remove_knowledge_base, Return_Collections_in_DB, Add_Text_to_Knowledge_Base, Remove_Text_From_Knowledge_Base
from utilities import get_current_git_branch
import io
from langchain.llms import HuggingFaceTextGenInference
from dotenv import load_dotenv
from langchain.llms import AzureOpenAI 
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage
from langchain.chains import LLMChain


#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

'''saml_url = 'https://saml.stage.att.com/isam/sps/attsamlidp/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https://idf-dev.az.3pc.att.com&RelayState=https://askambrin.att.com/static/'
saml_resp = requests.get(saml_url)
print(saml_resp)'''

#Initalize logging
environment = get_current_git_branch()
#If in development or application_testing branch, load environment configuration for test environment 
if environment != "master":
    #Load configs
    with open('./configs/test_configs.json') as json_file:
        configs = json.load(json_file)
    logging.basicConfig(filename = "test_backend.log", 
        format='%(asctime)s %(threadName)s : %(message)s',
        filemode='w',
        level = logging.DEBUG)
    environment = "development"
#If on master, load environemnt configuration for production environment
else:
    #Load configs
    with open('./configs/production_configs.json') as json_file:
        configs = json.load(json_file)
    logging.basicConfig(filename = "production_backend.log", 
        format='%(asctime)s %(threadName)s : %(message)s',
        filemode='w',
        level = logging.DEBUG)

app = Flask(__name__)
app.secret_key = "KLUCH"

'''manager = xmlsec.KeysManager()
key = xmlsec.Key.from_file("decryptionPvk.pem", xmlsec.constants.KeyDataFormatPem)
manager.add_key(key)
enc_ctx = xmlsec.EncryptionContext(manager)
root = etree.parse("enc1-res.xml").getroot()
enc_data = xmlsec.tree.find_child(root, "EncryptedData", xmlsec.constants.EncNs)
decrypted = enc_ctx.decrypt(enc_data)
print(etree.tostring(decrypted))'''


# Configure session type and options
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'None'
app.config['SESSION_COOKIE_SECURE'] = True

# Initialize the session
Session(app)

#Set client session to expire after 12 hours 
app.permanent_session_lifetime = timedelta(minutes=720)
db = DB (
        "RBAC", 
        search_path = configs["database"]["rbac_search_path"],
        host = configs["database"]["db_host"],
        port=configs["database"]["db_port"]
    )
feedback_db = DB (
        "ainlm", 
        search_path=configs["database"]["ainlm_search_path"],
        host = configs["database"]["db_host"],
        port=configs["database"]["db_port"]
    )
CORS(app, resources={r"/*" : {"origins" : "*"}}, supports_credentials=True)

try:
    #Connect LLM Pipelines
    gpt_3_5 = AzureOpenAI(
        deployment_name="gpt-35-turbo",
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    ) 
    davinci = AzureOpenAI(
        deployment_name="text-davinci-003",
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    )
    gpt4 = AzureChatOpenAI(
        deployment_name='gpt-4',
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    )
    LLM = HuggingFaceTextGenInference(
        inference_server_url="http://localhost:8085/",
        max_new_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        repetition_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"],
    )
    #Connect LLM Pipeline
    Test_LLM = HuggingFaceTextGenInference(
        inference_server_url="http://localhost:8085/",
        max_new_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        repetition_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"],
    )
except Exception as error:
    print(f"An error has occured while trying to connect to the LLM Server: {error}")

#@app.after_request
#def cors(response):
#    response.headers['Access-Control-Allow-Origin'] = 'http://localhost:4200 http://127.0.0.1'
#    response.headers['Access-Control-Allow-Headers'] = '*'
#    response.headers['Access-Control-Allow-Credentials'] = True
#    return response

#Initalize client session 
@app.route('/login', methods=["POST"])
#@flask_saml.login_required
def initalize_session():
    initalized_session = create_session(app, request, session, db)
    return initalized_session

#Get knowledge bases that user has a role in
@app.route('/user/knowledge_bases', methods=["GET"])
def return_user_knowledge_bases():
    with app.app_context():
        user_kb = return_user_kb(app, request, session)
    return user_kb

#Create or delete vector db
@app.route('/vector_db', methods=["POST", "DELETE"])
def knowledge_base():
    with app.app_context():
        kb = vector_db(app, request, session ,db)
    return kb

#API to add, delete, or returns pdf docs in vector db
@app.route('/vector_db/docs', methods=["POST", "DELETE"])
def docs():
    with app.app_context():
        doc = pdf_management(app, session, request, db, feedback_db)
    return doc

#Prompt language model
@app.route('/prompt', methods=["POST"])
def prompt():
    global feedback_db
    global db
    llm_function = prompt_llm(app, request, session, feedback_db, db, Test_LLM, gpt_3_5, davinci, gpt4)
    return llm_function


#Add or remove user permissions 
@app.route('/vector_db/access', methods=["POST",  "DELETE"])
def permissions():
    with app.app_context():
        manage_perms = manage_permission(app, request, session, db)
    return manage_perms

#Send back Feedback
@app.route('/feedback/<answerId>', methods=['POST'])
def createFeedback(answerId):
    with app.app_context():
        feedback = post_feedback(app, request, session, feedback_db, answerId)
    return feedback


#Return documents that have been ingested into knowledge base for download
@app.route('/pdf/download',methods=['POST'])
def download():
    with app.app_context():
        pdf = pdf_download(app, request, session, feedback_db, db)
    return pdf

    
#Return list of all documents that have been ingested into knowledge base 
@app.route('/vector_db/all',methods=['POST'])
def allFilesList():
    with app.app_context():
        files_list = return_allFilesList(app, request, session, feedback_db, db)
    return files_list

'''@app.route('/STT', methods=['POST'])
def getextension():
    try:
        print("Request Received")
        audio_file = request.files['audio']
        if(audio_file):
            res = getSTT(audio_file=audio_file)
            return jsonify(res)
        return jsonify({"text":"Not found"}), 404
    except Exception as error:
        app.logger.error(f"An error has occured while trying to transform speech to text: {str(error)}")
        return jsonify({"error": str(error), "Status":-1}), 400'''

'''This Following Section of APIs are used for testing and development purposes'''

#test apis for Prompting language model
#if environment != "master": 

@app.route('/embeddings', methods=["POST"])
def return_similar_embeddings():
    with app.app_context():
        embeddings = return_similar_embeddings_api(app, request)
    return embeddings


# Your task is to answer the question by using the context {prompt_context}. Question: {llm_prompt}
@app.route('/Test/LLM', methods =["POST"])
def prompt_LLM():
    with app.app_context():
        test_llm_api = prompt_llm_api(app, request, Test_LLM, gpt_3_5, davinci, gpt4)
    return test_llm_api

# Your task is to answer the question by using the context {prompt_context}. Question: {llm_prompt}
@app.route('/knowledge_graph', methods =["POST"])
def query_kg():
    test_query_kg = query_kg_api(app, request)
    return test_query_kg

    
if __name__ == '__main__':
    app.run(debug=True, threaded=True)