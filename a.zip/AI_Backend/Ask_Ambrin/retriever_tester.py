import json
import re
import os
import requests
from sentence_transformers import SentenceTransformer, util
from nltk.tokenize import sent_tokenize
from flask import Flask, request
from dotenv import load_dotenv
from llama_index.indices.query.schema import QueryBundle
import re
import inspect
from IPython.display import display, Markdown
from llama_index import load_index_from_storage, load_indices_from_storage, load_graph_from_storage
from llama_index.storage.index_store.simple_index_store import SimpleIndexStore
from llama_index.vector_stores import SimpleVectorStore
from llama_index.storage.docstore.simple_docstore import SimpleDocumentStore
from langchain.llms import HuggingFaceTextGenInference

#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

from llama_index import (
    SimpleDirectoryReader,
    StorageContext,
    ServiceContext,
    KnowledgeGraphIndex,
    Document
)
from llama_index.graph_stores import SimpleGraphStore
from llama_index.graph_stores import Neo4jGraphStore
from langchain.llms import AzureOpenAI 

# using data from Wikipedia
from llama_index import download_loader


class Retriever: 
    def __init__(self,embeddings_model):
        self.embeddingmodel = embeddings_model
    
    def get_page_from_st(self, st, file):
        if file == 'feedback.json':
            return None
        try:
            dir_path = './DB/Embeddings_Test_Files/UnEmbedded'
            for file_path in os.listdir(dir_path):
                    if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                        file_path = os.path.join(dir_path, file_path)
                        with open(file_path, 'r') as f:
                            NDR = json.load(f)
                            break
            metadata = NDR['metadata']
            f_name = metadata['file_name']
            page_number = metadata['page_numbers'][st]
            return f_name, page_number
        except Exception as e:
            error = "An exception occurred: %s" % e
            return {'error':error}

    #Transform preprocessed text in NDR json file into embeddings to conduct similarity search from
    def embeddings(self):
        try:
            dir_path = './DB/Embeddings_Test_Files/UnEmbedded'
            Ales_encoded_paragraphs_listoflists = []
            for file_path in os.listdir(dir_path):
                if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):
                    Ales_encoded_paragraphs_listoflists.append(self.ales_encode_text(os.path.join(dir_path, file_path)))
            Ales_encoded_paragraphs = [item for sublist in Ales_encoded_paragraphs_listoflists for item in sublist]
            with open('./DB/Embeddings_Test_Files/Embedded/ales_encoded_paragraphs.json', 'w') as f:
                json.dump(Ales_encoded_paragraphs, f)
            message = 'the embeddings are generated and stored.'
            return {'message': message}
        except Exception as e:
            error = "An exception occurred: %s" % e
            return {'error':error}

    #This is a test comment
    #Do similarity search on paragraph embeddings for prompt
    def retrieve_paragraphs(self, retrieve_count, Q):
        try:
            with open('./DB/Embeddings_Test_Files/Embedded/ales_encoded_paragraphs.json') as f:
                ales_encoded_paraggraphs = json.load(f)
        except Exception as e:
            return e
        sims = self.calc_similarities(Q, ales_encoded_paraggraphs, "paragraphs")
        # 'fn': self.get_page_from_st(s['section title'])[0], 'pn': self.get_page_from_st(s['section title'])[1],
        ans = []
        for s in list(sims)[0:retrieve_count]:
            result = self.get_page_from_st(s['section title'], s['file'])
            fn = self.get_page_from_st(s['section title'], s['file'])[0] if result is not None else None
            pn = self.get_page_from_st(s['section title'], s['file'])[1] if result is not None else None
            ans.append({'f': s['file'], 't': s['section title'], 'fn': fn, 'pn': pn, 'p': s['paragraph'], 's': float(s['similarity'])})
        return ans

    #Do similarity search on sentence embeddings for prompt and retrieve its paragraph
    def retrieve_sentences(self, retrieve_count, Q):
        try:
            with open('./DB/Embeddings_Test_Files/Embedded/sentence_transformed_NDR.json') as f:
                encoded_sentences = json.load(f)
        except Exception as e:
            return e
        sims = self.calc_similarities(Q, encoded_sentences["sentence"], "sentences")
        #Only return unique paragraphs
        ans = []
        retrieved = 0
        retrieved_paragraph_indexs = []
        sentence_count = len(sims)
        while len(ans) < retrieve_count and retrieved < sentence_count:
            paragraph_index = sims[retrieved]['paragraph index']
            if paragraph_index not in retrieved_paragraph_indexs:
                retrieved_paragraph_indexs.append(paragraph_index)
                ans.append({'f': sims[retrieved]['file'], 't': sims[retrieved]['section title'], 'fn': self.get_page_from_st(sims[retrieved]['section title'], None)[0], 'pn': self.get_page_from_st(sims[retrieved]['section title'], None)[1], 'p': encoded_sentences["paragraph index"][str(paragraph_index)], 's': float(sims[retrieved]['similarity'])})
            retrieved += 1
        return ans
    
    def calc_similarities(self, Q, encoded_paragraphs, text_type):
        encoded_question = self.embeddingmodel.encode(Q)
        cos_sims = []
        if text_type == "paragraphs":
            for np in encoded_paragraphs:
                try:
                    cos_sims.append({"paragraph": np["paragraph"],
                                    "section title": np["section title"],
                                    "file": np["file"],
                                    "similarity": util.cos_sim(encoded_question, np["encoded"]).numpy()[0][0]})
                except Exception as e:
                    print(f"An error has occured while trying to calculate similarity: {str(e)}")
        elif text_type == "sentences":
            for np in encoded_paragraphs:
                try:
                    cos_sims.append({"sentence": np["sentence"],
                                     "paragraph index": np["paragraph index"],
                                    "section title": np["section title"],
                                    "file": np["file"],
                                    "similarity": util.cos_sim(encoded_question, np["encoded"]).numpy()[0][0]})
                except Exception as e:
                    print(f"An error has occured while trying to calculate similarity: {str(e)}")

        with open('feedback.json', 'r') as json_file:
            data = json.load(json_file)
            for question in data:
                cos_sims.append({"paragraph": question['answer'],
                                    "section title": None,
                                    "file": 'feedback.json',
                                    "similarity": util.cos_sim(encoded_question, question['question_encoded']).numpy()[0][0]})

        sorted_cos_sims = sorted(cos_sims, key=lambda d: d['similarity'], reverse=True) 
        return sorted_cos_sims
    
    def ales_encode_text(self, file):
        with open(file) as f:
            ales_lines = f.readlines()
        # paragraphs_string = ''.join(ales_lines)
        paragraphs_object = json.loads(' '.join(ales_lines))

        paragraphs_encoded = []
        for k in list(paragraphs_object.keys()):
            for p in paragraphs_object[k]:
                paragraphs_encoded.append({"file": file.split('/')[-1], "section title": k, "paragraph": p, "encoded": self.embeddingmodel.encode(p).tolist()})
        return paragraphs_encoded

    def split_ndr_into_sentences_and_generate_embeddings(self):
        try:
            dir_path = './DB/Embeddings_Test_Files/UnEmbedded'
            Ales_encoded_paragraphs_listoflists = []
            for file_path in os.listdir(dir_path):
                if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                    file_path = os.path.join(dir_path, file_path)
                    file_name = file_path.split('/')[-1]
                    with open(file_path, 'r') as f:
                        NDR = json.load(f)
                        break
            paragraphs_index = {}
            sentence_NDR = {}
            i = 0
            sentence_NDR = []
            for section in NDR.keys():
                for paragraph in NDR[section]:
                    paragraphs_index[i] = paragraph
                    sentences = sent_tokenize(paragraph)
                    for sentence in sentences:
                        sentence_NDR.append({"sentence":sentence, "paragraph index":i, "encoded":self.embeddingmodel.encode(sentence).tolist(), "file":file_name, "section title":section})
                    i+=1
            finalized_sentence_NDR = {"sentence":sentence_NDR, "paragraph index":paragraphs_index}
            with open('./DB/Embeddings_Test_Files/Embedded/sentence_transformed_NDR.json', 'w') as f:
                json.dump(finalized_sentence_NDR, f)
            
        except Exception as error:
            print(error)
      
    #Transform preprocessed P2_US and Instar document into embeddings to conduct similarity search 
    #TODO: This function needs to be enhanced to handle all the json
    def create_embeddings_files(self, dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files/Raw/Instar_documents', target_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files/Embedded/Instar_documents.json'):
        try:
            yves_encoded_paragraphs_listoflists = []
            for file_path in os.listdir(dir_path):
                file_dir = os.path.join(dir_path, file_path)
                if os.path.isfile(file_dir):
                    with open(file_dir) as f:
                        yves_lines = f.readlines()
                    paragraphs_object = json.loads(' '.join(yves_lines))
                    yves_encoded_paragraphs_listoflists.append(self.encode_object(paragraphs_object, file_path))
            yves_encoded_paragraphs = [item for sublist in yves_encoded_paragraphs_listoflists for item in sublist]
            with open(target_path, 'w') as f:
                json.dump(yves_encoded_paragraphs, f)
            message = 'the embeddings are generated and stored.'
            return {'message': message}
        except Exception as e:
            error = "An exception occurred: %s" % e
            return {'error':error}


    def encode_object(self, paragraphs_object, file_name):
        paragraphs_encoded = []
        if type(paragraphs_object) is dict: 
            for k , p in paragraphs_object.items():
                paragraphs_encoded.append({"file": file_name, "section title": k, "paragraph": p, "encoded": self.embeddingmodel.encode(p).tolist()})
        elif type(paragraphs_object) is list: 
            for user_story in paragraphs_object:
                us_id = user_story[Key]
                for k , p in user_story.items():
                    paragraphs_encoded.append({"file": file_name, "user story id": us_id, "section title": k, "paragraph": p, "encoded": self.embeddingmodel.encode(p).tolist()})
        return paragraphs_encoded
    
    def embed_input_question(self, question):
        return self.embeddingmodel.encode(question).tolist()

      
class Knowledge_Graph_Retriever:
    def __init__(self, create_index, domain, llm):
        self.domain = domain
        self.llm = llm
        self.service_context = ServiceContext.from_defaults(llm=self.llm, chunk_size=512)
        if create_index == True:
            self.kg_engine = self.create_graph_from_domain()
        else:
            self.kg_engine = self.load_knowledge_graph()

    def create_graph_from_domain(self):
        try:
            dir_path = './DB/Embeddings_Test_Files/UnEmbedded'
            for file_path in os.listdir(dir_path):
                #Load single NDR document
                if file_path.endswith(f'{self.domain}.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                    file_path = os.path.join(dir_path, file_path)
                    with open(file_path, 'r') as f:
                        NDR = json.load(f)
                        break
            paragraphs = ""
            for section in NDR:
                if section == "metadata":
                    continue
                else:
                    for p in NDR[section]:
                        paragraphs += p
                    
            documents = [Document(text=paragraphs)]
            # neo4j database
            username = "neo4j"
            password = "ainlm_dev"
            url = "bolt://localhost:7687"
            database = "neo4j"
            graph_store = Neo4jGraphStore(
                username=username,
                password=password,
                url=url,
                database=database
            )
            storage_context = StorageContext.from_defaults(graph_store=graph_store)
            NDR_index = KnowledgeGraphIndex.from_documents(
                documents,
                max_triplets_per_chunk=2,
                service_context=self.service_context,
                storage_context=storage_context,
            )
            kg_engine = NDR_index.as_query_engine(include_text=True, response_mode="tree_summarize")
            #storage_context.persist(persist_dir=f"./storage")
            return kg_engine

        except Exception as error:
            print(error)

    def load_knowledge_graph(self):
        storage_context = StorageContext.from_defaults(
            docstore=SimpleDocumentStore.from_persist_dir(persist_dir=f"./storage"),
            vector_store=SimpleVectorStore.from_persist_dir(persist_dir=f"./storage"),
            index_store=SimpleIndexStore.from_persist_dir(persist_dir=f"./storage")
        )
        kg_engine = load_index_from_storage(storage_context, service_context=self.service_context)
        kg_engine = kg_engine.as_query_engine(include_text=True, response_mode="tree_summarize")
        return kg_engine
    def retrieve_NDR_triplets(self, query):
        nodes_list = []
        nodes = self.kg_engine.retrieve(QueryBundle(query))
        kg_mapping = []
        sub_pred_obj = []
        for node in nodes:
            #Retriever can show text mapping from node to file
            kg_mapping.append(node.text)
            
        return kg_mapping
    
    def query_knowledge_graph(self, query):
        response = self.kg_engine.query(query)  
        triplets = []
        for data in response.metadata:
            if "kg_rel_map" not in response.metadata[data].keys():
                continue
            else:
                triplets.append(response.metadata[data]["kg_rel_map"])
        return response, triplets

#Initalize embeddings retriever
embeddings_model = SentenceTransformer('all-MiniLM-L6-v2')
Embeddings_Retriever = Retriever(embeddings_model)
'''Llama = HuggingFaceTextGenInference(
        inference_server_url="http://localhost:8085/"
    )
davinci = AzureOpenAI(deployment_name="text-davinci-003")
KG_Retriever = Knowledge_Graph_Retriever(True, "NDR", davinci)'''

#Initalize NDR knowledge graph
app = Flask(__name__)

@app.route('/embeddings')
def embeddings():
    try:
        text_type = request.json["text type"]
        if text_type == "sentence":
            Embeddings_Retriever.split_ndr_into_sentences_and_generate_embeddings()
        elif text_type == "paragraph":
            Embeddings_Retriever.embeddings()
        else:
            raise Exception("Provide valid text type to embed")
        return {"message":f"{text_type} embeddings generated successfully"}

    except Exception as e:
        message = "An exception occurred: %s" % e
        return {"error":message}

@app.route('/retrieve')
def retrieve():
    try:
        text_type = request.args.get('text type')
        Q = request.args.get('prompt')
        retrieve_count = int(request.args.get('retrieve count'))
        if text_type == "sentence":
            ans = Embeddings_Retriever.retrieve_sentences(retrieve_count, Q)
        elif text_type == "paragraph":
            ans = Embeddings_Retriever.retrieve_paragraphs(retrieve_count, Q)
        return ans
    except Exception as e:
        return {"error":str(e)}
    
'''@app.route('/knowledge_graph/NDR/retrieve', methods =["POST"])
def retrieve_NDR_kg():
    try:
        query = request.json["query"]
        mapping = KG_Retriever.retrieve_NDR_triplets(query)
        return {"KG Retrieved Mapping" : str(mapping)}
    except Exception as error:
        return {"error":str(error)}

@app.route('/knowledge_graph/NDR/query', methods =["POST"])
def query_NDR_kg():
    try:
        query = request.json['query']
        response, triplets = KG_Retriever.query_knowledge_graph(query)
        return {"LLM Response" : str(response), "Tripplets":triplets}
    except Exception as error:
        return {"error":str(error)}'''
    
@app.route('/embed')
def embed():
    try:
        sentence = request.args.get('sentence')
        embedded_sentence = Embeddings_Retriever.embed_input_question(sentence)
        return {"embedding" : embedded_sentence}
    except Exception as error:
        return {"error":str(error)}, 500

if __name__ == '__main__':
   app.run()

