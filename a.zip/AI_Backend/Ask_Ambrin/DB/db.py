import psycopg2
import numpy as np
import sys
import os
from psycopg2 import Error
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

sys.path.append('..')    
load_dotenv('.env')

class DB:
    def __init__(self, DB, search_path, host, port):
        self._db = None
        self.DB = DB
        self.search_path = search_path
        self.host = host
        self.port = port
    def cursor(self, names=False):
        cur = self._conn().cursor(cursor_factory=RealDictCursor if names else None)
        cur.execute(f"set local search_path to {self.search_path}")
        return cur
    def commit(self):
        # nothign to commit if there is no db!
        if self._db:
            self._db.commit()
    def _conn(self):
        if not self._db:
            self._db = psycopg2.connect(
                            user=os.getenv('DB_USERNAME', ''),
                            password=os.getenv('DB_PASSWORD', ''),
                            host=self.host,
                            port=self.port,
                            database=self.DB)
        return self._db

def role_to_permissions(role, db):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM roles WHERE description = '{role}' LIMIT 1;")
        role_id = cur.fetchall()[0][0]
        cur = db.cursor()
        cur.execute(f'SELECT * FROM permissions WHERE role = {role_id};')
        permissions = cur.fetchall()
        role_permissions = [row[0] for row in permissions]
        cur.close()
        return role_permissions, role_id
    except Exception as error:
        db._db.rollback()
        return "error", error

'''Current roles are User, SE, and Admin. Current permissions are read, write, and manage. This function also adds the given attuid as admin over the knowledge base'''
def create_permissions_and_roles_in_db(app, knowledge_base, db, attuid):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchall()[0][1]
        roles = ['User', 'SE', 'Admin']
        Admin = ['read', 'write', 'manage']
        SE = ['read', 'write']
        User = ['read']
        roles_dict = {'Admin':Admin, 'SE':SE, 'User':User}
        admin_id = None
        for role in roles:
            kb_role = f"{knowledge_base}_{role}"
            cur = db.cursor()
            cur.execute(f"INSERT INTO roles (description) VALUES ('{kb_role}');")
            db.commit()
            cur = db.cursor()
            cur.execute(f"SELECT * FROM roles WHERE description = ('{kb_role}') LIMIT 1;")
            role_id = cur.fetchall()[0][0]
            for permission in roles_dict[role]:
                cur = db.cursor()
                cur.execute(f"INSERT INTO permissions (type, knowledge_base, role) VALUES ('{permission}', {kb_id}, {role_id});")
                db.commit()
            if role == 'Admin':
                #Set creater of vector db as admin of vector db
                cur = db.cursor()
                cur.execute(f"INSERT INTO user_permissions (role, attuid) VALUES ({role_id}, '{attuid}')")
                db.commit()
        cur.close()
        app.logger.info(f'Permissions and roles successfully added to {knowledge_base} with {attuid} as admin')
        return "success"
    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error has occured when creating roles and permissions for {knowledge_base}. {error}')
        return error

def remove_permissions_roles_and_db(app, knowledge_base, db):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchone()[1]
        cur = db.cursor()
        cur.execute(f"SELECT * FROM permissions WHERE knowledge_base = {kb_id};")
        role_ids = np.array([row[2] for row in cur.fetchall()])
        role_ids = np.unique(role_ids)
        role_ids = tuple(role_ids)
        cur = db.cursor()
        cur.execute(f"DELETE FROM permissions WHERE role IN {role_ids}")
        db.commit()
        cur = db.cursor()
        cur.execute(f"DELETE FROM roles WHERE id IN {role_ids}")
        db.commit()
        cur = db.cursor()
        cur.execute(f"DELETE FROM user_permissions WHERE role IN {role_ids}")
        db.commit()
        cur = db.cursor()
        cur.execute(f"Delete FROM knowledge_base WHERE id = {kb_id};")
        db.commit()
        cur.close()
        return "success"
    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error has occured while attempting to delete {knowledge_base} vector db')
        return error
    
def check_user_roles_in_db(attuid, knowledge_base, db, app):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchall()[0][1]
        cur = db.cursor()
        #Get all roles for this knowledge base
        cur.execute(f"SELECT * FROM permissions WHERE knowledge_base = {kb_id}")
        role_ids = np.array([row[2] for row in cur.fetchall()])
        role_ids = np.unique(role_ids)
        query = f"SELECT * FROM user_permissions WHERE attuid = '{attuid}' AND"
        for i, role in enumerate(role_ids):
            if i == 0:
                query += f" (role = {role}"
            else:
                query += f" OR role = {role}"
        query += ") LIMIT 1;"
        cur = db.cursor()
        cur.execute(query)
        result = cur.fetchall()
        cur.close()
        if result == []:
            return "User does not have role in this knowledge base"
        else:
            return "User has role in this knowledge base"
    except Exception as error:
        db._db.rollback()
        app.logger.error(f"Encountered an error when checking if {attuid} has role in {knowledge_base}")
        return f"Encountered an error when checking if {attuid} has role in {knowledge_base}. error:{error}"

def add_documents_to_db(db, feedback_db, docs_name, docs_content, knowledge_base, attuid, app):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchall()[0][1]
        max_docs = len(docs_name) - 1
        query = "INSERT INTO document (document_name, attuid, knowledge_base, document_data) VALUES"
        for i, doc in enumerate(docs_name):
            if i == max_docs:
                query += f" ('{doc}', '{attuid}', {kb_id}, {psycopg2.Binary(docs_content[i])});" 
            else:
                query += f" ('{doc}', '{attuid}', {kb_id}, {psycopg2.Binary(docs_content[i])})," 
        cur = feedback_db.cursor()
        cur.execute(query)
        feedback_db.commit()
        cur.close()
        app.logger.info(f"Added {str(docs_name)} to {knowledge_base} in db")
        return "success"
    except Exception as error:
        db._db.rollback()
        feedback_db._db.rollback()
        app.logger.error(f"An error has occured while attempting to add documents into {knowledge_base}. {str(error)}")
        return f"An error has occured while attempting to add one or more documents into {knowledge_base}. {str(error)}"

def remove_documents_from_db(db, feedback_db, docs_name, knowledge_base, app):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchall()[0][1]
        query = "DELETE FROM document WHERE document_name IN ("
        max_docs = len(docs_name) - 1
        for i, doc in enumerate(docs_name):
            if i == max_docs:
                query += f"'{doc}') "
            else:
                query += f"'{doc}', "
        query += f"AND knowledge_base = {kb_id};"
        cur = feedback_db.cursor()
        cur.execute(query)
        feedback_db.commit()
        cur.close()
        app.logger.info(f"Removed {str(docs_name)} from {knowledge_base} in db")
        return "success"
    except Exception as error:
        db._db.rollback()
        feedback_db._db.rollback()
        app.logger.error(f"An error has occured while attempting to remove one or more documents from {knowledge_base}. {str(error)}")
        return f"An error has occured while attempting to remove one or more documents from {knowledge_base}. {str(error)}"
    

def get_document_from_db(feedback_db, db, file_name, attuid, knowledge_base, app):
    try:
        cur = db.cursor()
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        kb_id = cur.fetchall()[0][1]
        cur.close()
        cursor = feedback_db.cursor()
        cursor.execute("SELECT document_name, document_data FROM document WHERE (document_name=%s AND knowledge_base=%s)", (file_name, kb_id))
        result = cursor.fetchone()
        cursor.close()
        app.logger.info(f'Successfully retrieved the {file_name} from {knowledge_base}')
        return "success", result
    except Exception as error: 
        app.logger.error(f"An error has occured while trying to return {file_name} from {knowledge_base}. {error}")
        return f"An error has occured while trying to return {file_name} from {knowledge_base}. {error}"
    
def get_all_documents_from_db(feedback_db, db, knowledge_base, app):
    try:
        cur = db.cursor()
        app.logger.info(knowledge_base)
        cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{knowledge_base}' LIMIT 1;")
        data = cur.fetchall()
        if len(data)==0:
            return (f"An error has occured while trying to return list of all files from {knowledge_base}. No KnowledgeBase Found"), None
        kb_id = data[0][1]
        cur.close()
        cursor = feedback_db.cursor()
        cursor.execute(f"SELECT document_name FROM document WHERE knowledge_base={kb_id}")
        result = cursor.fetchall()
        cursor.close()
        return "success", result
    except Exception as error: 
        app.logger.error(f"An error has occured while trying to return list of all files from {knowledge_base}. {error}")
        return f"An error has occured while trying to return list of all files from {knowledge_base}. {error}", None