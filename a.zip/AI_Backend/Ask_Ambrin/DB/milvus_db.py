from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Milvus
from langchain.document_loaders import TextLoader
from langchain.embeddings import HuggingFaceBgeEmbeddings
from langchain.schema import Document
import transformers
import json
from pymilvus import (
    connections,
    utility,
    Collection
)
from utilities import get_current_git_branch

environment = get_current_git_branch()
#If in development or application_testing branch, load environment configuration for test environment 
if environment == "development" or environment == "application_testing":
    #Load configs
    with open('test_configs.json') as json_file:
        configs = json.load(json_file)

#If on master, load environemnt configuration for production environment
else:
    #Load configs
    with open('production_configs.json') as json_file:
        configs = json.load(json_file)


#Load embeddings model
model_name = configs["embeddings_configs"]["model_name"]
model_kwargs = {'device': configs["embeddings_configs"]["device"]}
encode_kwargs = {'normalize_embeddings': configs["embeddings_configs"]["normalize_embeddings"]} # set True to compute cosine similarity
embeddings = HuggingFaceBgeEmbeddings(
    model_name=model_name,
    model_kwargs=model_kwargs,
    encode_kwargs=encode_kwargs
)
docs = [
    Document(page_content="This is test document one", metadata={"Document": "Sample_Document_One"}),
    Document(page_content="This is test document two", metadata={"Document": "Sample_Document_Two"}),
]
database = configs["milvus_db_configs"]["database"]


def create_knowledge_base(knowledge_base, chunks, app):
    try:
        global database
        global embeddings
        vector_db = Milvus.from_documents(
            chunks,
            embeddings,
            connection_args={"db_name" : database, "host": "127.0.0.1", "port": "19530"},
            collection_name = knowledge_base
        )
        app.logger.info(f"Knowledge Base {knowledge_base} successfully created")
        return "success"
    except Exception as error:
        app.logger.error(f"Error when attempted to create Knowledge Base {knowledge_base}: {str(error)}")
        return f"Error when attempted to create Knowledge Base {knowledge_base}: {str(error)}"

def remove_knowledge_base(knowledge_base, app):
    try:
        utility.drop_collection(knowledge_base)
        app.logger.info(f"Successfully removed Knowledge Base {knowledge_base}")
        return "success"
    except Exception as error:
        app.logger.error(f"Error when occured when attempting to remove Knowledge Base {knowledge_base}: {str(error)}")
        return f"Error when occured when attempting to remove Knowledge Base {knowledge_base}: {str(error)}"

def Return_Collections_in_DB(database):
    try:
        collections = utility.list_collections()
        return collections
    except Exception as e:
        return f"Error: {str(e)}"

def Add_Text_to_Knowledge_Base(knowledge_base, chunks, app):
    try:
        global database
        global embeddings
        vector_db = Milvus(
            embedding_function = embeddings,
            collection_name = knowledge_base,
            connection_args={"db_name" : database, "host": "127.0.0.1", "port": "19530"}
        )
        vector_db.add_documents(chunks)
        app.logger.info(f"Successfully ingested chunks into {knowledge_base}")
        return f"success"
    except Exception as error:
        app.logger.error(f"An error has occured when attempting to ingest chunks into {knowledge_base}: {str(error)}")
        return f"An error has occured when attempting to ingest chunks into {knowledge_base}: {str(error)}"

def Remove_Text_From_Knowledge_Base(knowledge_base, document, app):
    try:
        global database
        global embeddings
        global configs
        #Connect to milvus db
        conn = connections.connect(
            db_name=configs["milvus_db_configs"]["database"],
            host=configs["milvus_db_configs"]["host"],
            port=configs["milvus_db_configs"]["port"]
        )
        vector_db = Collection(knowledge_base)
        #Get the primary key of the document and delete it
        query = f'Document == "{document}"'
        result = vector_db.query(expr=query, output_fields=["pk"])
        primary_keys = [row["pk"] for row in result]
        result = "pk in " + str(primary_keys)
        vector_db.delete(result)
        app.logger.info(f"Document : {document} successfully deleted in knowledge base : {knowledge_base}")
        return "success"
    except Exception as error:
        app.logger.error(f"An error has occured when attempting to remove {document} from {knowledge_base}: {str(error)}")
        return f"An error has occured when attempting to remove {document} from {knowledge_base}: {str(error)}"