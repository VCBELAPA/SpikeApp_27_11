#!/bin/bash 
# Prefix to match the pod names 
prefix="milvus" 
# Get a list of pod names that start with the specified prefix 
pods=$(kubectl get pods -o custom-columns=:metadata.name --no-headers | grep "^$prefix") 
# Loop through the matched pod names and delete each one 
for pod in $pods; 
    do kubectl delete pod "$pod" 
done