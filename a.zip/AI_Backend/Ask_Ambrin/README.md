# AskAmbrin Backend
For the production or development server to run, the retriever application needs to be running. Note that the retriever server will be used during the development phases of the AskAmbrin project and most likely be depreciated in the future. Command to run the retriever server:

gunicorn -w 1 -b localhost:8083 retriever_tester:app & disown

To run the backend in the production server enter the command:

gunicorn -w 1 -b 0.0.0.0:8081 backend:app & disown

To run the backend in the development server enter the command:

gunicorn -w 1 -b 0.0.0.0:6081 backend:app & disown

The -w argument specifies how many workers or threads you want gunicorn to run.
To run the backend server for functionl testing enter the command:

flask --app backend run -p port_for_functional_testing (choose an arbitrary port between 4000-5000)

## Setting Up Python Virtual Environment
Create a python virtual environment, activate it, and install all the necessary python packages (run command pip install -r requirements.txt).
If you are in poc1 or lab2 run the commands: source ~/poc1/bin/activate or source ~/lab2/bin/activate to activate the python virtual environment that already has the necessary packages installed. 


## Role Based Access Control 
- There are currently three roles defined in this system: User (which has read permissions on a vector db), SE (which has read and write permissions on a vector db), and Admin (which has read, write, and manage permissions on a vector db).
- Manage permissions allow you to delete a vector db and any user from a vector db
- You can only add roles to a vector db that contain a subset of your permissions in that vector db. Ex: SE (read and write) can only add SEs or Users (read) to the vector db that they have that role in. 

## Database Environment 
- The database environment configurations automatically loads depending on the branch you are on when you run the backend. The production database configs load if you run the backend from the master branch and the devlopment database configs if you are on any other branch. To make changes to the current database configurations, you do this in the test_configs.json (for dev) file or production_configs.json file. This will allow you to change the schema connection for the RBAC database and ainlm database. 

## Milvus DB
- Milvus runs in kubernetes with a local, single node cluster (implemented with minikube). Its configurations for the development and production server automatically load when you start the backend (prod configs load when you are on master branch and dev configs when you are not in master branch). You can edit the configs in the test_configs.json (for dev) and production_configs.json. If you encounter any issues, Run the command: kubectl port-forward service/milvus 19530:19530 & disown 

## NEO4J
To build and run NEO4J container for the knowledge graph development database run the command: 
docker run -p 7474:7474 -p 7687:7687 -e NEO4J_apoc_export_file_enabled=true  -e NEO4J_apoc_import_file_enabled=true  -e NEO4J_apoc_import_file_use__neo4j__config=true  -e NEO4JLABS_PLUGINS=\[\"apoc\"\]  -d --env NEO4J_AUTH=<set server username>/<set server password> neo4j




