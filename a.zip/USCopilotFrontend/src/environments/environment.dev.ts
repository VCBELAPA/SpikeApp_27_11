import { NgxLoggerLevel } from "ngx-logger";

export const environment = {
    production: true,
    apiURL: 'http://localhost:4500',
    logging : {
      level: NgxLoggerLevel.DEBUG
    }
  };