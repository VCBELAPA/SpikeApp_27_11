import { NgxLoggerLevel } from "ngx-logger";

export const environment = {
    production: true,
    apiURL: '',
    logging : {
      level: NgxLoggerLevel.DEBUG
    }
  };