import { NgxLoggerLevel } from "ngx-logger";

export const environment = {
    production: false,
    apiURL: 'http://localhost:6081',
    logging : {
      level: NgxLoggerLevel.DEBUG
    }
  };