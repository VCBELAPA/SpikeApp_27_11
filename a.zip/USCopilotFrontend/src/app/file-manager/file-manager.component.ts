import { Component } from '@angular/core';
import { CommonService } from '../service/common.service';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import { NGXLogger } from 'ngx-logger';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-file-manager',
  templateUrl: './file-manager.component.html',
  styleUrls: ['./file-manager.component.scss']
})
export class FileManagerComponent {
  fileName = '';
  uploadMessage = '';
  formData : FormData | null = null;
  deleteMessage!: string;
  uploadProgress = false;
  deleteProgress: boolean = false;
  allKb: Observable<string[]>;
  logger: NGXLogger;

  /**
   *
   */
  constructor(public commonService : CommonService, private httpService: RESTAPIServiceService) {
    this.allKb = commonService.allKnowlwdgeBases;
    this.logger = commonService.logger;
    this.logger.debug("Constructing FileManagerComponent");
  }

  getKb() {
    return this.commonService.currentKB;
  }

  upload(event?: Event) {
    // gets called with or without event;  if event is NOT present, the file was already selected
    //    and user hit the upload button.  If event is present, then the user is just selecting the file
    if (event) {  // file is selected
      const element:HTMLInputElement = <HTMLInputElement>event.target;
      if (element.files) {
        this.formData = new FormData();
        this.fileName = '';
        this.formData.append('vector_db', this.commonService.currentKB.toString());
        for (let i = 0; i < element.files.length; i++) {
          this.formData.append('files', element.files[i]);
          if(this.fileName) {
            this.fileName =this.fileName + ", '" + element.files[i].name +"'";
          } else {
            this.fileName = element.files[i].name;
          }
        }
        this.logger.debug("Files attached for the upload:", this.formData);
      } else {
        this.uploadMessage = 'Internal error on file loader';
        this.logger.warn("No files found");
      }    
    } else {
      // this must be the upload trigger
      if(!this.commonService.currentKB) {
        this.uploadMessage = "Please select Knowledge Base";
        return;
      }
      if (!this.formData) {
        this.uploadMessage = 'intenal erorr:Select a file first';
      } else {
        // upload
        this.uploadProgress = true;
        //this.uploadMessage=`Uploading ${this.fileName}`;
        const httpOptions = {
          headers: new HttpHeaders({
            
          }),
          withCredentials: true
        };
        //this.formData.set("vector_db", this.commonService.currentKB);
        this.fileName="";
        this.httpService.postReq('/vector_db/docs', this.formData, httpOptions).subscribe({
          next: (data: any) => {
            this.logger.debug("Response from /vector_db/docs:", data);
            if (data['response']) {
              this.uploadMessage = data['response'];
            } else {
              this.uploadMessage = data.toString();
            }
          },
          error: (err) => {
            this.logger.error("Error Response from /vector_db/docs:", err);
            if(err.status == 400) {
              if (err.error['error']) this.uploadMessage = err.error['error'];
              else this.uploadMessage = err.error;
            } else if (err.message) {
              this.uploadMessage = err.message;
            } else {
              this.uploadMessage = err;
            }
            this.uploadProgress = false;
          },
          complete: () => {
            this.uploadProgress = false;
          }
        })
      }
    }
  }

  refreshKB() {}

  delete(f:NgForm){
    if(!f.value.doc_name) {
      this.deleteMessage = "Please Enter name of file";
      return;
    }
    if(!this.commonService.currentKB) {
      this.deleteMessage = "Please select Knowledge Base";
      return;
    }
    const body = {
     "doc_names" : [f.value.doc_name],
     "vector_db" : this.commonService.currentKB
    };
    this.deleteProgress = true;
    f.reset();
    this.httpService.deleteReq('/vector_db/docs', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /vector_db/docs:", data);
        if (data['response']) {
          this.deleteMessage = data['response'];
        } else {
          this.deleteMessage = data.toString();
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /vector_db/docs:", err);
        if(err.status == 400) {
          if (err.error['error']) this.deleteMessage = err.error['error'];
          else this.deleteMessage = err.error;
        } else if (err.message) {
          this.deleteMessage = err.message;
        } else {
          this.deleteMessage = err;
        }
        this.deleteProgress = false;
      },
      complete: () => {
        this.deleteProgress = false;
      }
    })
  }


  async uploadApitest(ms:any){
    await new Promise(resolve => setTimeout(resolve, ms)); // 3 sec
    this.uploadProgress = false;
    this.uploadMessage = 'Files Uploaded to Knowledge Base'
 }

 async deleteApitest(ms:any){
  await new Promise(resolve => setTimeout(resolve, ms)); // 3 sec
  this.deleteProgress = false;
  this.deleteMessage = 'Docunment Deleted from Knowledge Base'
}
}
