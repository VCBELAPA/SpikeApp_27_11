import { Component } from '@angular/core';
import { RESTAPIServiceService } from './service/restapiservice.service';
import { CommonService } from './service/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import packageJson from '../../package.json';
import { NGXLogger } from 'ngx-logger';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Ask Ambrin';
  screenWidth: number;
  attUid;
  loading = false;
  public version: string = 'v'+packageJson.version;
  logger:NGXLogger;
  attInfo:any;
  constructor(private httpService: RESTAPIServiceService, private commonService: CommonService, private _snackBar: MatSnackBar) {
    this.attInfo = commonService.getAttCard();
    this.logger = commonService.logger;
    this.logger.debug("Constructing AppComponent");
    this.attUid = commonService.getAttCard()['att_id'];
    this.loading = true;
    this.logger.debug("Requesting to /login:", {"attuid": this.attUid});
    this.httpService.postReq("/login", {"attuid": this.attUid}).subscribe({
      next: (data) => {
        // means session successfully initalized
        this.logger.debug("Response from /login:", data);
      },
      error: (err) => {
        // means session didn't initalized
        this.logger.error("Error Response from /login:", err);
        if(err.message) {
          this._snackBar.open(err.message, 'close')
        } else {
          this._snackBar.open(err, 'close')
        }
        this.loading = false;
      },
      complete: () => {
        // do nothing
        this.logger.debug('login done now loading all Kb');
        this.loadAllKb();
      }
    })
    // set screenWidth on page load
    this.screenWidth = window.innerWidth;
    window.onresize = () => {
      // set screenWidth on screen size change
      this.screenWidth = window.innerWidth;
    };
  }

  loadAllKb(){
    this.logger.debug("Request to /user/knowledge_bases:");
    this.httpService.getReq("/user/knowledge_bases").subscribe({
      next: (data:any) => {
        this.logger.debug("Response from /user/knowledge_bases:", data);
        this.commonService.allKnowlwdgeBases.next(data.user_knowledge_bases);
      },
      error: (err) => {
        this.logger.error("Error Response from /user/knowledge_bases:", err);
        this.loading = false;
      },
      complete: () => {
        // do nothing
        this.loading = false;
      }
    })
  }
}
