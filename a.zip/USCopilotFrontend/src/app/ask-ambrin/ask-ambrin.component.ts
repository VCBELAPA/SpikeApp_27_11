import { Component, Renderer2, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CommentDialogComponent } from '../comment-dialog/comment-dialog.component';
import { CommonService } from '../service/common.service';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { NGXLogger } from 'ngx-logger';
import { VoiceRecognitionService } from '../service/voice-recognition.service';
import { HttpHeaders } from '@angular/common/http';

//import * as RecordRTC from 'recordrtc'
import {Options, StereoAudioRecorder} from 'recordrtc'
@Component({
  selector: 'app-ask-ambrin',
  templateUrl: './ask-ambrin.component.html',
  styleUrls: ['./ask-ambrin.component.scss']
})

export class AskAmbrinComponent {
  att_id;
  att_initials;
  att_fname;
  att_lname;
  showExpert = false;
  expertId='';
  queryMessage = '';
  feedbackStatus = false;
  logger: NGXLogger;
  isStillRecoginze = false;
  currentModel = ""
  record:any;
  questionText = '';
  recording = false;
  contexts:any[] = [];
  latest_question = ''
  constructor(public dialog: MatDialog, private httpService: RESTAPIServiceService, public commonService: CommonService, public voiceService: VoiceRecognitionService, private renderer: Renderer2, private el: ElementRef){
    var temp = commonService.getAttCard();
    this.att_id = temp.att_id;
    this.att_initials = temp.att_initials;
    this.att_fname = temp.att_fname;
    this.att_lname = temp.att_lname;
    //this.allKb$ = commonService.AllKb;
    this.logger = commonService.logger;
    this.logger.debug("Constructing AskAmbrinComponent");
  }
  expert(){}

  startVoiceService() {
    //this.isStillRecoginze = this.voiceService.start() === true ? true : false;
    this.recording = true;
    let mediaConstrains = {
      video: false,
      audio: true
    }
    navigator.mediaDevices
      .getUserMedia(mediaConstrains)
      .then(this.successCallback.bind(this), this.errorCallback.bind(this))
  }

  successCallback(stream: MediaStream){
    var option:Options = {
      mimeType: "audio/wav"
    }
    var SterioAudioRecorder = StereoAudioRecorder
    this.record = new SterioAudioRecorder(stream, option);
    this.record.record();
  }

  errorCallback(){
    this.queryMessage = 'Can not do the audio recording for STT, try again';
  }

  stopVoiceService() {
    //this.isStillRecoginze = this.voiceService.stop() === false ? false : true;
    this.recording =false;
    this.record.stop(this.processRecording.bind(this))
  }

  processRecording(blob: any){
    this.feedbackStatus = true;
    //this.logger.debug(blob);
    let formData = new FormData();
    formData.append('audio', blob);
    this.httpService.specialpostReq("/STT", formData).subscribe({
      next: (data:any) => {
        this.logger.debug("Response from /STT :", data);
        this.questionText = data['text'];
      },
      error: (err) => {
        this.logger.error("Error Response from /STT:", err);
        if (err.status == 400) {
          if (err.error['error']) this.queryMessage = err.error['error'];
          else this.queryMessage = err.error;
        } else if(err.message) {
          this.queryMessage = err.message;
        } else {
          this.queryMessage = err;        
        }
        this.feedbackStatus = false;
      },
      complete: () => {
        // do nothing
        this.feedbackStatus = false;
      }
    })
  }

  openDialogCmt(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      'prompt' : "Give Feedback for the Answer",
      'answer' : "",
      'myAnswer': "",
      'context_rating': "",
      'rating':""
    };
    dialogConfig.width = '70%';
    dialogConfig.height = 'auto';
    this.logger.debug("Opening Feedback Dialog");
    const dialogRef = this.dialog.open(CommentDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result) {
        this.logger.debug("Feedback Dialog was closed", result);
        this.comment(result.answer, result.myAnswer, result.context_rating, result.rating);
      } else {
        this.logger.debug("Feedback Dialog was closed without any feeedback");
      }
    });
  }
  comment(cmt: any, myAnswer: any, context_rating: any, rating: any) {
    const body = {
      "values": {
        'comment': cmt,
        'myanswer':myAnswer,
        'context_rating': context_rating,
        'rating': rating,
        'question': this.latest_question
      } 
    }
    if(this.commonService.chat.length == 0) {
      this.queryMessage = "Please ask question or wait for answer to give feedback";
      return;
    }
    const aid = this.commonService.chat[this.commonService.chat.length - 1]["Answer ID"];
    this.logger.debug("Requesting to /feedback/"+aid+" with body:", body);
    this.feedbackStatus = true;
    this.httpService.postReq("/feedback/"+aid, body).subscribe({
      next: (data:any) => {
        this.logger.debug("Response from /feedback/"+aid+":", data);
        if(data.response) {
          this.queryMessage = "Feedback submitted, feedback ID:" + data.response;
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /feedback/"+aid+":", err);
        if (err.status == 400) {
          if (err.error['error']) this.queryMessage = err.error['error'];
          else this.queryMessage = err.error;
        } else if(err.message) {
          this.queryMessage = err.message;
        } else {
          this.queryMessage = err;        
        }
        this.feedbackStatus = false;
      },
      complete: () => {
        // do nothing
        this.feedbackStatus = false;
      }
    })
  }

  onSelect(event:Event){
    this.logger.debug("Changing the Knowlwdge Base");
    this.commonService.chat = [];
    this.commonService.questions = [];
    this.commonService.answers = [];
  }

  like(){
    this.comment('','','','10');
  }

  dislike() {
    this.comment('','','','0');
  }

  createTemplate(data:any){
    // data.model_response + "\n\n<hr><strong>Context Section Titles</strong>\n"+ data["Section Titles"].join("\n")
    var div = this.renderer.createElement('div');
    var ptag = this.renderer.createElement('p');
    this.renderer.appendChild(ptag, this.renderer.createText(data.model_response))
    var adiv = this.renderer.createElement('div');
    for (let index = 0; index < data["Section Titles"].length; index++) {
      const st = data["Section Titles"][index] || '';
      const fn = data["file_name"][index] || '' 
      const pn = data["page_number"][index] || ''
      // [routerLink]="" (click)="onGoToPage2()"
      //sections = sections + "<a [routerLink]=\"[]\" (click)='newTab('"+ fn+"','"+ pn+"')'>"+st+"</a>\n"
      const anchor = this.renderer.createElement('a');
      this.renderer.appendChild(anchor, this.renderer.createText(st));
      this.renderer.listen(anchor,'click', ()=> this.newTab(fn, pn));
      this.renderer.appendChild(adiv, anchor);
    }
    this.renderer.appendChild(div, ptag);
    this.renderer.appendChild(div, adiv);
    return div;
  }

  newTab(doc_name: string, page_number:number) {
    const body = {
      "file_name" : doc_name,
      "knowledge_base" : this.commonService.currentKB
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      responseType : 'blob',
      withCredentials: true
    };
    this.feedbackStatus = true;
    this.httpService.postReq('/pdf/download', body, httpOptions).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /pdf/download:", data);
        if (data) {
          const blob = new Blob([data], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          let test_url = url + '#page=' + page_number;
          this.logger.debug('URL for PDF:', url)
          const newTab = window.open(test_url, '_blank')
          //this.downloadMessage = data['response']+ ', Now Updating Knowledge Bases';
        } else {
          //this.downloadMessage = data.toString()+ ', Now Updating Knowledge Bases';
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /pdf/download:", err);
        if(err.status == 400) {
          if (err.error['error']) this.queryMessage = err.error['error'];
          else this.queryMessage = err.error;
        } else if(err.status == 200){
          const blob = new Blob([err.error['text']], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          const a = document.createElement('a');
          a.href = url;
          a.download = doc_name;
          a.click();
        } else if (err.message) {
          this.queryMessage = err.message;
        } else {
          this.queryMessage = err;
        }
        this.feedbackStatus = false;
      },
      complete: () => {
        this.feedbackStatus = false;
      }
    })
  }

  updateContext(data:any){
    this.contexts = []
    for (let index = 0; index < data["Section Titles"].length; index++) {
      const st = data["Section Titles"][index] || '';
      const fn = data["file_name"][index] || '' 
      const pn = data["page_number"][index] || ''
      // [routerLink]="" (click)="onGoToPage2()"
      //sections = sections + "<a [routerLink]=\"[]\" (click)='newTab('"+ fn+"','"+ pn+"')'>"+st+"</a>\n"
      const j = {
        "st" : st,
        "pn" : pn,
        "fn" : fn,
        "kb" : this.commonService.currentKB
      }
      this.contexts.push(j)
    }
  }

  query(f: NgForm) {
    if(!this.commonService.currentKB) {
      this.queryMessage = 'Please select a Knowledge Base first';
      return;
    }
    if(!this.currentModel) {
      this.queryMessage = 'Please select a LLM Model first';
      return;
    }
    const question = f.value.question;
    if(!question) {
      this.queryMessage = 'Please enter a Question';
      return;
    }
    f.reset();
    const body = {
      "vector_db" : this.commonService.currentKB,
      "prompt" : question,
      "model": this.currentModel
    }
    this.commonService.questions.push(question);
    this.logger.debug("Requesting to /prompt:", body);
    this.httpService.postReq("/prompt", body).subscribe({
      next: (data:any) => {
        // means session successfully initalized
        this.logger.debug("Response from /prompt:", data);
        if(data.model_response) {
          //this.logger.debug(data.model_response + "\n\nContext Section Titles\n"+ data["Section Titles"].join("\n"))
          // var div = this.createTemplate(data)
          // console.log(div)
          this.latest_question = question;
          this.updateContext(data)
          this.commonService.answers.push(data.model_response);
          this.commonService.chat.push(data);
        } else {
          this.commonService.answers.push("Unable to Get Answer At this time");
        }
      },
      error: (err) => {
        // means session didn't initalized
        this.logger.error("Error response from /prompt:", err);
        this.commonService.answers.push("Sorry,\nBecause of technical difficulties, I am unable to Answer right now. Please try again later")
        if(err.message) {
          this.queryMessage = err.message;
        } else {
          this.queryMessage = err;        
        }
      },
      complete: () => {
        // do nothing
      }
    })
  }

}
