import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AskAmbrinComponent } from './ask-ambrin.component';

describe('AskAmbrinComponent', () => {
  let component: AskAmbrinComponent;
  let fixture: ComponentFixture<AskAmbrinComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AskAmbrinComponent]
    });
    fixture = TestBed.createComponent(AskAmbrinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
