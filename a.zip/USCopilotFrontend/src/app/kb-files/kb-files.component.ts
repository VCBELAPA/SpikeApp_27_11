import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommonService } from '../service/common.service';
import { Observable } from 'rxjs';
import { NGXLogger } from 'ngx-logger';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { HttpHeaders } from '@angular/common/http';

export interface KbData {
  number: string;
  name: string;
}

@Component({
  selector: 'app-kb-files',
  templateUrl: './kb-files.component.html',
  styleUrls: ['./kb-files.component.scss']
})

export class KbFilesComponent {

  allKb$: Observable<string[]>;
  logger:NGXLogger;
  downloadMessage:string = '';
  downloadProgress:boolean = false;
  getKBMessage:string = '';
  getKBProgress:boolean = false;
  constructor(public commonService : CommonService, private httpService: RESTAPIServiceService) {
    // Create 100 users
    this.logger = commonService.logger;
    this.logger.debug("Constructing KbFilesComponebt");
    this.dataSource = new MatTableDataSource(this.kbArray);
    this.getKbFiles(this.currentKB);
    this.allKb$ = commonService.AllKb;
    // Assign the data to the data source for the table to render
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  currentKB = '';

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  kbArray: KbData[] = [];
  //backendUrl=environment.api_url;
  displayedColumns: string[] = ['number', 'name', 'new window'];
  dataSource: MatTableDataSource<KbData>;
  getKbFiles(domain: string) {
    this.logger.debug("Test: getting KB files");
    if(!domain) {
      this.setTableDataSource([])
      return;
    }
    //empty current dataSource
    this.kbArray = [];
    this.setTableDataSource([])
    this.getKBProgress = true;
    //this.dataSource = new MatTableDataSource(this.kbArray);
    const body = {
      "knowledge_base" : domain
    }
    this.httpService.postReq('/vector_db/all', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /pdf/download:", data);
        if (data) {
          this.setTableDataSource(data);
        } else {
          this.setTableDataSource([]);
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /pdf/download:", err);
        if(err.status == 400) {
          if (err.error['error']) this.getKBMessage = err.error['error'];
          else this.getKBMessage = err.error;
        } else if (err.message) {
          this.getKBMessage = err.message;
        } else {
          this.getKBMessage = err;
        }
        this.getKBProgress = false;
      },
      complete: () => {
        this.getKBProgress = false;
      }
    })
    
    
  }

  setTableDataSource(dataArray: any){
    for (let index = 0; index < dataArray.length; index++) {
      let element: string = dataArray[index].toString();
      let kbJson = {
        "number": (index + 1).toString(),
        "name": element
      }
      this.kbArray[index] = kbJson;
    }
    this.dataSource = new MatTableDataSource(this.kbArray);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  download(doc_name: string) {
    const body = {
      "file_name" : doc_name,
      "knowledge_base" : this.currentKB
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      responseType : 'blob',
      withCredentials: true
    };
    this.httpService.postReq('/pdf/download', body, httpOptions).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /pdf/download:", data);
        if (data) {
          const blob = new Blob([data], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          const newTab = window.open(url, '_blank')
          const a = document.createElement('a');
          a.href = url;
          a.download = doc_name;
          a.click();
          this.downloadMessage = data['response']+ ', Now Updating Knowledge Bases';
        } else {
          this.downloadMessage = data.toString()+ ', Now Updating Knowledge Bases';
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /pdf/download:", err);
        if(err.status == 400) {
          if (err.error['error']) this.downloadMessage = err.error['error'];
          else this.downloadMessage = err.error;
        } else if(err.status == 200){
          const blob = new Blob([err.error['text']], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          const a = document.createElement('a');
          a.href = url;
          a.download = doc_name;
          a.click();
        } else if (err.message) {
          this.downloadMessage = err.message;
        } else {
          this.downloadMessage = err;
        }
        this.downloadProgress = false;
      },
      complete: () => {
        this.downloadProgress = false;
      }
    })
  }

  delete(doc_name: string){
    const body = {
      "doc_names" : [doc_name],
      "vector_db" : this.currentKB
     };
     this.downloadProgress = true;
     this.httpService.deleteReq('/vector_db/docs', body).subscribe({
       next: (data: any) => {
         this.logger.debug("Response from /vector_db/docs:", data);
         if (data['response']) {
           this.downloadMessage = data['response'];
         } else {
           this.downloadMessage = data.toString();
         }
       },
       error: (err) => {
         this.logger.error("Error Response from /vector_db/docs:", err);
         if(err.status == 400) {
           if (err.error['error']) this.downloadMessage = err.error['error'];
           else this.downloadMessage = err.error;
         } else if (err.message) {
           this.downloadMessage = err.message;
         } else {
           this.downloadMessage = err;
         }
         this.downloadProgress = false;
       },
       complete: () => {
         this.downloadProgress = false;
         this.getKbFiles(this.currentKB)
       }
     })
  }


  newTab(doc_name: string) {
    const body = {
      "file_name" : doc_name,
      "knowledge_base" : this.currentKB
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      responseType : 'blob',
      withCredentials: true
    };
    this.downloadProgress = true;
    this.httpService.postReq('/pdf/download', body, httpOptions).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /pdf/download:", data);
        if (data) {
          const blob = new Blob([data], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          //let test_url = url + '#page=30';
          this.logger.debug('URL for PDF:', url)
          const newTab = window.open(url, '_blank')
          //this.downloadMessage = data['response']+ ', Now Updating Knowledge Bases';
        } else {
          //this.downloadMessage = data.toString()+ ', Now Updating Knowledge Bases';
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /pdf/download:", err);
        if(err.status == 400) {
          if (err.error['error']) this.downloadMessage = err.error['error'];
          else this.downloadMessage = err.error;
        } else if(err.status == 200){
          const blob = new Blob([err.error['text']], {type: 'application/pdf'});
          const url = window.URL.createObjectURL(blob)
          const a = document.createElement('a');
          a.href = url;
          a.download = doc_name;
          a.click();
        } else if (err.message) {
          this.downloadMessage = err.message;
        } else {
          this.downloadMessage = err;
        }
        this.downloadProgress = false;
      },
      complete: () => {
        this.downloadProgress = false;
      }
    })
  }

  onSelect(event:Event){
    this.logger.debug("Changing the Knowlwdge Base");
    this.getKbFiles(this.currentKB)
  }
}
