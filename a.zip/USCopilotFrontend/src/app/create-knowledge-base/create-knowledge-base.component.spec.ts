import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateKnowledgeBaseComponent } from './create-knowledge-base.component';

describe('CreateKnowledgeBaseComponent', () => {
  let component: CreateKnowledgeBaseComponent;
  let fixture: ComponentFixture<CreateKnowledgeBaseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CreateKnowledgeBaseComponent]
    });
    fixture = TestBed.createComponent(CreateKnowledgeBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
