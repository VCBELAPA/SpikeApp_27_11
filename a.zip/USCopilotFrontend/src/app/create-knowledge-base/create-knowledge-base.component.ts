import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '../service/common.service';
import { Observable } from 'rxjs';
import { MatSelect } from '@angular/material/select'
import { NGXLogger } from 'ngx-logger';

@Component({
  selector: 'app-create-knowledge-base',
  templateUrl: './create-knowledge-base.component.html',
  styleUrls: ['./create-knowledge-base.component.scss']
})
export class CreateKnowledgeBaseComponent implements OnInit {
  createMessage!: string;
  createProgress = false;
  deleteMessage!: string;
  deleteProgress: boolean = false;
  currentKb = "";
  allKb$!: Observable<string[]>;
  @ViewChild(MatSelect)
  matSelect!: MatSelect;
  logger: NGXLogger;
  constructor(private httpService: RESTAPIServiceService, public commonService: CommonService, private _snackBar: MatSnackBar) {
    this.logger = commonService.logger;
    this.logger.debug("Constructing CreateKnowledgeBaseComponent");
  }
  ngOnInit(): void {
    this.allKb$ = this.commonService.AllKb;
    this.allKb$.subscribe((newArray) => {
      this.deleteProgress = false;
      this.createProgress = false;
    })
  }
  create(f: NgForm) {
    if (!f.value.name) {
      this.createMessage = 'Enter Valid Name for Knowledge Base'
      return;
    }
    const body = {
      "vector_db": f.value.name
    };
    f.reset();
    this.createProgress = true;
    this.logger.debug("Requesting to /vector_db:", body);
    this.httpService.postReq('/vector_db', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /vector_db:", data);
        if (data['response']) {
          this.createMessage = data['response']+ ', Now Updating Knowledge Bases';
        } else {
          this.createMessage = data.toString()+ ', Now Updating Knowledge Bases';
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /vector_db:", err);
        if(err.status == 400) {
          if (err.error['error']) this.createMessage = err.error['error'];
          else this.createMessage = err.error;
        } else if (err.message) {
          this.createMessage = err.message;
        } else {
          this.createMessage = err;
        }
        this.createProgress = false;
      },
      complete: () => {
        this.logger.debug('created new KB, now reloading all KB');
        this.commonService.loadAllKb();
      }
    })
  }


  delete(f: NgForm) {
    if (!f.value.kbname) {
      this.deleteMessage = 'Select Name for Knowledge Base'
      return;
    }
    const body = {
      "vector_db": f.value.kbname
    };
    f.reset();
    this.deleteProgress = true;
    this.logger.debug("Requesting to Delete /vector_db:", body);
    this.httpService.deleteReq('/vector_db', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from Delete /vector_db:", data);
        if (data['response']) {
          this.deleteMessage = data['response'] + ', Now Updating Knowledge Bases';
        } else {
          this.deleteMessage = data.toString()+ ', Now Updating Knowledge Bases';
        }
      },
      error: (err) => {
        this.logger.error("Error Response from Dleete /vector_db:", err);
        if(err.status == 400) {
          if (err.error['error']) this.deleteMessage = err.error['error'];
          else this.deleteMessage = err.error;
        } else if (err.message) {
          this.deleteMessage = err.message;
        } else {
          this.deleteMessage = err;
        }
        this.deleteProgress = false;
      },
      complete: () => {
        this.logger.debug('deleted KB, now reloading all KB');
        this.commonService.loadAllKb();
        //location.reload();
      }
    })
  }
}
