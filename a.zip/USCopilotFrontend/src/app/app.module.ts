import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { KnowledgeBaseComponent } from './knowledge-base/knowledge-base.component';
import { CreateKnowledgeBaseComponent } from './create-knowledge-base/create-knowledge-base.component';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTabsModule } from '@angular/material/tabs';
import { FileManagerComponent } from './file-manager/file-manager.component';
import { UserManagerComponent } from './user-manager/user-manager.component';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AskAmbrinComponent } from './ask-ambrin/ask-ambrin.component';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatInputModule } from '@angular/material/input';
import { KbFilesComponent } from './kb-files/kb-files.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCardModule } from '@angular/material/card';
import { CommentDialogComponent } from './comment-dialog/comment-dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { HttpClientModule } from '@angular/common/http';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { LoggerModule } from 'ngx-logger'
import { environment } from 'src/environments/environment';
import { TestAskAmbrinComponent } from './test-ask-ambrin/test-ask-ambrin.component';
import {MatMenuModule} from '@angular/material/menu';
import { AbbreviationTableComponent } from './abbreviation-table/abbreviation-table.component';


@NgModule({
  declarations: [
    AppComponent,
    KnowledgeBaseComponent,
    CreateKnowledgeBaseComponent,
    FileManagerComponent,
    UserManagerComponent,
    KbFilesComponent,
    CommentDialogComponent,
    AskAmbrinComponent,
    TestAskAmbrinComponent,
    AbbreviationTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatSidenavModule,
    MatTabsModule,
    MatSelectModule,
    FormsModule,
    MatChipsModule,
    MatFormFieldModule,
    MatButtonModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatSnackBarModule,
    MatProgressBarModule,
    MatCardModule,
    MatDialogModule,
    MatRadioModule,
    HttpClientModule,
    MatButtonToggleModule,
    MatMenuModule,
    LoggerModule.forRoot(environment.logging)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
