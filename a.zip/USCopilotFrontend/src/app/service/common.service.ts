import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { RESTAPIServiceService } from './restapiservice.service';
import { BehaviorSubject } from 'rxjs';
import { NGXLogger } from 'ngx-logger';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  currentKB;
  att_id: string;
  att_fname: string;
  att_lname: string;
  att_initials: any;
  //AskAmbrin Component Variables
  questions : string[] = [];
  answers : string[] = [];
  chat: any[] = [];
  //AskAmbrin Component Variables
  public allKnowlwdgeBases = new BehaviorSubject<string[]>([]);


  constructor(private httpService: RESTAPIServiceService, private NGXlogger: NGXLogger) { 
    this.currentKB = '';
    this.logger.debug("Constructing CommonService");
    if(environment.production) {
      let attArray = decodeURIComponent((document.cookie.split(';').filter(s=>s.includes('attESHr'))[0] || '').trim()).split('|');
      this.att_id = attArray[2].split('@')[0];
      this.logger.info("Global Logon user:", this.att_id);
      this.att_fname = attArray[0].split('=')[1];
      this.att_lname = attArray[1];
      this.att_initials = this.att_fname.charAt(0) + this.att_lname.charAt(0);
    } else {
      this.att_id = 'sp030n';
      this.logger.info("Test user:", this.att_id);
      this.att_fname = 'SHREENAL';
      this.att_lname = 'PATEL';
      this.att_initials = 'SP';
    }
  }
  
  public get logger() : NGXLogger {
    return this.NGXlogger;
  }
  

  get AllKb(): BehaviorSubject<string[]>{
    return this.allKnowlwdgeBases;
  }

  setKB(kb: string) {
    this.currentKB = kb;
  }

  getKB() {
    return this.currentKB;
  }
  getAttCard() {
    return {
      "att_id" : this.att_id,
      "att_fname" : this.att_fname,
      "att_lname" : this.att_lname,
      "att_initials" : this.att_initials
    }
  }

  loadAllKb(){
    this.logger.debug("Requesting to /user/knowledge_bases");
    this.httpService.getReq("/user/knowledge_bases").subscribe({
      next: (data:any) => {
        this.logger.debug("Response from /user/knowledge_bases:", data);
        if(data.user_knowledge_bases == 'None') {
          this.allKnowlwdgeBases.next([]);
        } else {
          this.allKnowlwdgeBases.next(data.user_knowledge_bases)
        }
        //this.allKnowlwdgeBases = data.user_knowledge_bases;
      },
      error: (err) => {
        this.logger.error("Error Response from /user/knowledge_bases:", err);
        this.allKnowlwdgeBases.next([''])
        //this.allKnowlwdgeBases = ['test_vdb1']
      },
      complete: () => {
        // do nothing
      }
    })
  }

  
}
