import { Injectable } from '@angular/core';
import { CommonService } from '../service/common.service';
import { NGXLogger } from 'ngx-logger';
declare var webkitSpeechRecognition: any;
@Injectable({
	providedIn: 'root'
})
export class VoiceRecognitionService {

	recognition = new webkitSpeechRecognition();
	isStoppedSpeechRecog = false;
	public text = '';
	tempWords: any;
	transcript_arr: any[] = [];
	confidence_arr: any[] = [];
	isStarted = false; //<< this Flag to check if the user stop the service
	isStoppedAutomatically = true; //<< this Flag to check if the service stopped automaticically.
	logger: NGXLogger;
	public selectedVoice!: SpeechSynthesisVoice | null;
	public voices!: SpeechSynthesisVoice[];
	constructor(public commonService: CommonService) {
		this.logger = commonService.logger;
	}

	// I synthesize speech from the current text for the currently-selected voice.
	public speak(textToSay: string): void {
		if (!textToSay) {
			return;
		}
		this.stopVoice();
		this.synthesizeSpeechFromText(1, textToSay);
	}

	// I stop any current speech synthesis.
	public stopVoice(): void {
		if (speechSynthesis.speaking) {
			speechSynthesis.cancel();
		}
	}

	private synthesizeSpeechFromText(
		rate: number,
		text: string
	): void {

		var utterance = new SpeechSynthesisUtterance(text);
		//utterance.voice = voice;
		utterance.rate = rate;

		speechSynthesis.speak(utterance);

	}


}
