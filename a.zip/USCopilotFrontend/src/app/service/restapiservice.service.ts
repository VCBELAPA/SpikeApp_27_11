import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RESTAPIServiceService {

  constructor(private http: HttpClient) { 

  }

  url = environment.apiURL;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
    withCredentials: true
  };
  
  postReq(endpoint: string ,body: any, header?:any) {
    
    if(header) {
      return this.http.post(this.url + endpoint, body, header);
    } else {
      return this.http.post(this.url + endpoint, body, this.httpOptions);
    }
  }

  specialpostReq(url: string, formData: FormData) {
    let httpHeader = {
      headers: new HttpHeaders({
        
      }),
      //withCredentials: true,
    };
    return this.http.post("http://localhost:6088/STT1" , formData, httpHeader);
  }

  getReq(endpoint: string, header?:any) {
    if(header) {
      return this.http.get(this.url + endpoint, header);
    } else {
      return this.http.get(this.url + endpoint, this.httpOptions);
    }
  }

  deleteReq(endpoint: string, bodyJson?: any) {
    var httpHeader;
    if(bodyJson) {
      httpHeader = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        withCredentials: true,
        body : bodyJson
      };
      return this.http.delete(this.url + endpoint, httpHeader);
    } else {
      return this.http.delete(this.url + endpoint, this.httpOptions);
    }
  }
}
