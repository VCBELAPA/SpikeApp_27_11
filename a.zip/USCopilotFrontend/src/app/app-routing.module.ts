import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateKnowledgeBaseComponent } from './create-knowledge-base/create-knowledge-base.component';
import { KnowledgeBaseComponent } from './knowledge-base/knowledge-base.component';
import { AskAmbrinComponent } from './ask-ambrin/ask-ambrin.component';
import { TestAskAmbrinComponent } from './test-ask-ambrin/test-ask-ambrin.component';

const routes: Routes = [
  {
    path: 'Knowledge_Base',
    component: KnowledgeBaseComponent
  },
  {
    path: 'Create_Knowledge_Base',
    component: CreateKnowledgeBaseComponent
  },
  {
    path: 'Ask_Ambrin',
    component: AskAmbrinComponent
  },
  {
    path: 'Test_Ask_Ambrin',
    component: TestAskAmbrinComponent
  },
  { 
    path: '', 
    redirectTo: '/Knowledge_Base', 
    pathMatch: 'full' 
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
