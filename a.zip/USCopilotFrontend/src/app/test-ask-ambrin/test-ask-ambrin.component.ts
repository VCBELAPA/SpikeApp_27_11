import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CommonService } from '../service/common.service';
import { NGXLogger } from 'ngx-logger';
import { RESTAPIServiceService } from '../service/restapiservice.service';

@Component({
  selector: 'app-test-ask-ambrin',
  templateUrl: './test-ask-ambrin.component.html',
  styleUrls: ['./test-ask-ambrin.component.scss']
})
export class TestAskAmbrinComponent {

  contexts:any;
  logger: NGXLogger;
  currentContext: any;
  answer: any;
  configMessage:any;
  configProgress:boolean = false;
  prompt:any;
  questionMessage:any;
  questionProgress:boolean = false;
  question2Message:any;
  question2Progress:boolean = false;
  template:any = "Your task is not to define acronyms and abbreviations unless is given in the context, and also to give a direct response to what the user asks based on the given context and nothing else. Context: {prompt_context} User: {llm_prompt}? Response:";
  currentModel: any;
  KnowledgeAnswer: any;
  KnowledgeMessage: any;
  KnowledgeProgress:boolean = false;
  constructor(public commonService: CommonService, private httpService: RESTAPIServiceService) {
    this.logger = commonService.logger;
    this.logger.debug("Constructing TestAskAmbrinComponent");
  }
  question(f: NgForm){
    this.contexts= '';
    this.answer = '';
    this.currentContext = '';
    this.logger.debug(f.value)
    this.prompt = f.value.question;
    if(!f.value.question) {
      this.questionMessage = "Question is requried";
      return;
    }
    if(!f.value.currentModel) {
      this.questionMessage = "Model is requried";
      return;
    }
    if(!f.value.SimilaritySearchText) {
      this.questionMessage = "Similarity Search Text is requried";
      return;
    }
    if(!f.value.retriveCount) {
      this.questionMessage = "Retrive Count is requried";
      return;
    }
    this.currentModel = f.value.currentModel;
    const body = {
      "prompt" : f.value.question,
      "document_type" : "automated",
      "similarity search text": f.value.SimilaritySearchText,
      "retrieve count": f.value.retriveCount
    }
    var url = "/embeddings"
    if(body['document_type'] == 'search_engine') {
      url = "/Search_Engine"
    }
    this.questionProgress = true;
    this.httpService.postReq(url, body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from "+url+":", data);
        if (data) {
           this.contexts = [];
           for (let index = 0; index < data.context.length; index++) {
            const element = {
              "p" : data.context[index],
              "f" : data["File Names"][index],
              "t": data["Section Titles"][index],
              "s": data["Similarity Score"][index]
            }
            this.contexts.push(element);
           }
        } 
      },
      error: (err) => {
        this.logger.error("Error Response from "+url+":", err);
        if(err.status == 400) {
          if (err.error['error']) this.questionMessage = err.error['error'];
          else this.questionMessage = err.error;
        } else if (err.message) {
          this.questionMessage = err.message;
        } else {
          this.questionMessage = err;
        }
        this.questionProgress = false;
      },
      complete: () => {
        this.questionProgress = false;
      }
    })
    //this.contexts= [{"paragraph":"paragraph 1", "score": 0.41}, {"paragraph":"paragraph 2", "score": 0.51}, {"paragraph":"paragraph 3", "score": 0.48}];
  }
  question2(f: NgForm, list:any){
    //this.logger.debug(this.currentContext)
    if(!list.length) {
      this.question2Message = "Please select context"
      return;
    }
    if(!(f.value.template.includes("{prompt_context}") && f.value.template.includes("{llm_prompt}"))) {
      this.question2Message = "{prompt_context} and {llm_prompt} is requried in template"
      return;
    }
    var contextArray = list.map((x:any)=>x.value.p);
    const body = {
      "prompt" : this.prompt,
      "context" : contextArray,
      "template": f.value.template,
      "model": this.currentModel
    }
    this.question2Progress = true;
    //make api call
    this.httpService.postReq('/Test/LLM', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /test/LLM:", data);
        if (data) {
           this.answer = data.answer;
        } 
      },
      error: (err) => {
        this.logger.error("Error Response from /LLM:", err);
        if(err.status == 400) {
          if (err.error['error']) this.question2Message = err.error['error'];
          else this.question2Message = err.error;
        } else if (err.message) {
          this.question2Message = err.message;
        } else {
          this.question2Message = err;
        }
        this.question2Progress = false;
      },
      complete: () => {
        this.question2Progress = false;
      }
    })
    //this.answer = "Sample response";
  }
  config(f: NgForm){
    this.logger.debug(f.value);
    const body = {"configs" : f.value}
    if(!(body["configs"]["max_new_tokens"]) || !(body["configs"]["top_k"]) || !(body["configs"]["top_p"]) || !(body["configs"]["temperature"]) || !(body["configs"]["repetition_penalty"])) {
      this.configMessage = "All fields are requried";
      return;
    }
    if(!(body["configs"]["top_p"] >= 0 && body["configs"]["top_p"] <= 1)) {
      this.configMessage = "Top P should be between 0-1";
      return;
    }
    if(!(body["configs"]["temperature"] >= 0 && body["configs"]["temperature"] <= 1)) {
      this.configMessage = "Temperature should be between 0-1";
      return;
    }
    if(!(body["configs"]["repetition_penalty"] >= 0)) {
      this.configMessage = "Repetition Penalty should be between 0-1";
      return;
    }
    this.configProgress = true;
    this.httpService.postReq('/LLM/Configs', body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /LLM/Configs:", data);
        if (data) {
           this.configMessage = data.response;
        } 
      },
      error: (err) => {
        this.logger.error("Error Response from /LLM/Configs:", err);
        if(err.status == 400) {
          if (err.error['error']) this.configMessage = err.error['error'];
          else this.configMessage = err.error;
        } else if (err.message) {
          this.configMessage = err.message;
        } else {
          this.configMessage = err;
        }
        this.configProgress = false;
      },
      complete: () => {
        this.configProgress = false;
      }
    })

  }
  knowledgeGraph(f : NgForm){
    var question = f.value.question;
    if(!question) {
      this.KnowledgeMessage = "Question is requried";
      return;
    }
    const body = {
      'prompt' : question
    }
    this.KnowledgeProgress = true;
    this.httpService.postReq("/knowledge_graph", body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /knowledge_graph", data);
        if (data) {
           this.KnowledgeAnswer = data['LLM Response'];
        } 
      },
      error: (err) => {
        this.logger.error("Error Response from /knowledge_graph", err);
        if(err.status == 400) {
          if (err.error['error']) this.KnowledgeMessage = err.error['error'];
          else this.KnowledgeMessage = err.error;
        } else if (err.message) {
          this.KnowledgeMessage = err.message;
        } else {
          this.KnowledgeMessage = err;
        }
        this.KnowledgeProgress = false;
      },
      complete: () => {
        this.KnowledgeProgress = false;
      }
    })
  }
}