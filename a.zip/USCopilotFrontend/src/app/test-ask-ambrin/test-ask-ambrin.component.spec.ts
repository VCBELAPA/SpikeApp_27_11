import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestAskAmbrinComponent } from './test-ask-ambrin.component';

describe('TestAskAmbrinComponent', () => {
  let component: TestAskAmbrinComponent;
  let fixture: ComponentFixture<TestAskAmbrinComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestAskAmbrinComponent]
    });
    fixture = TestBed.createComponent(TestAskAmbrinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
