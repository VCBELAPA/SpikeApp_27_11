import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommonService } from '../service/common.service';
import { Observable } from 'rxjs';
import { NGXLogger } from 'ngx-logger';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { HttpHeaders } from '@angular/common/http';

export interface abData {
  id: number;
  term: string;
  definition: string;
  description: string;
  source: any;
}

@Component({
  selector: 'app-abbreviation-table',
  templateUrl: './abbreviation-table.component.html',
  styleUrls: ['./abbreviation-table.component.scss']
})
export class AbbreviationTableComponent {

  logger: NGXLogger;
  dataSource: MatTableDataSource<abData>;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  // abArray: abData[] = [
  //   {
  //     id: 1,
  //     term: 'ABF',
  //     definition: 'abandon failure',
  //     description: 'Lucent 5ESS switch message.',
  //     source: 'null',
  //   },
  //   {
  //     id: 2,
  //     term: 'ACR',
  //     definition: 'Abbreviated Cable Record',
  //     description: 'National Dispatch Center (NDC)',
  //     source: 'null'
  //   }
  // ]
  displayedColumns: string[] = ['id', 'term', 'definition', 'description', 'source'];

  constructor(public commonService: CommonService, private httpService: RESTAPIServiceService) {
    // Create 100 users
    this.logger = commonService.logger;
    this.logger.debug("Constructing AbbreviationTableComponent");
    this.dataSource = new MatTableDataSource(this.abArray);
    // Assign the data to the data source for the table to render
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  abArray:abData[] = [
    {
      "id": 1,
      "term": "DTV-AAJ TAX",
      "definition": "AAJ Tax Credits",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=24799",
      "source": null
    },
    {
      "id": 2,
      "term": "ABF",
      "definition": "abandon failure",
      "description": "Lucent 5ESS switch message.",
      "source": null
    },
    {
      "id": 3,
      "term": "ACR",
      "definition": "Abbreviated Cable Record",
      "description": "National Dispatch Center (NDC)",
      "source": null
    },
    {
      "id": 4,
      "term": "memory dialing",
      "definition": "abbreviated dialing",
      "description": "",
      "source": null
    },
    {
      "id": 5,
      "term": "ADC",
      "definition": "abbreviated dialing code",
      "description": "Web application used to house abbreviated dialing codes used on the mobility network. It is owned by the business marketing group.",
      "source": null
    },
    {
      "id": 6,
      "term": "ADG",
      "definition": "Abbreviated Dialing Group",
      "description": "",
      "source": null
    },
    {
      "id": 7,
      "term": "ADN",
      "definition": "Abbreviated Dialing Number",
      "description": "",
      "source": null
    },
    {
      "id": 8,
      "term": "ADS",
      "definition": "abbreviated dialing sequence",
      "description": "",
      "source": null
    },
    {
      "id": 9,
      "term": "ADWAMA",
      "definition": "abbreviated dialing with automatic message accounting (AMA)",
      "description": "",
      "source": null
    },
    {
      "id": 10,
      "term": "AND",
      "definition": "abbreviated number dialing",
      "description": "A feature that allows you to program frequently called numbers into your phone so that you can initiate calls with a short (one- or two-character) code rather than entering the entire number. Also called repertory dialing, memory dialing, speed dialing, or one-touch dialing.",
      "source": null
    },
    {
      "id": 11,
      "term": "AOD",
      "definition": "Abbreviated Office Dialing",
      "description": "Wireless Office Dialing (WOD) for Global System for Mobile Communications (GSM) - a system that allows a company employee to access the company's internal extensions by dialing only 3, 4, or 5 digits on a wireless phone. Formerly called Enterprise Abbreviated Dialing (EAD).",
      "source": null
    },
    {
      "id": 12,
      "term": "AOC",
      "definition": "Abbreviated Order Code",
      "description": "",
      "source": null
    },
    {
      "id": 13,
      "term": "ATLAS",
      "definition": "Abbreviated Test Language for All Systems",
      "description": "",
      "source": null
    },
    {
      "id": 14,
      "term": "ATH",
      "definition": "abbreviated trouble history",
      "description": "",
      "source": null
    },
    {
      "id": 15,
      "term": "ABRV",
      "definition": "Abbreviation",
      "description": "",
      "source": null
    },
    {
      "id": 16,
      "term": "ABBYY",
      "definition": "ABBYY Comparator",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym. \nFor more information, use this direct link to the entry in MOTS: http://ebiz.sbc.com/mots/detail.cfm?id=29494",
      "source": null
    },
    {
      "id": 17,
      "term": "ABC",
      "definition": "ABC Digits of a Number",
      "description": "(First 3 digits)",
      "source": null
    },
    {
      "id": 18,
      "term": "ABFSALARMTRAQ",
      "definition": "ABFS-ALARMTRAQ",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=20903",
      "source": null
    },
    {
      "id": 19,
      "term": "ABFSWeb",
      "definition": "ABFS Website",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=22344",
      "source": null
    },
    {
      "id": 20,
      "term": "Cricket ABI",
      "definition": "ABI - Cricket Wireless Business Intelligence Tool",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=22538",
      "source": null
    },
    {
      "id": 21,
      "term": "american business indicator",
      "definition": "abi number",
      "description": "",
      "source": null
    },
    {
      "id": 22,
      "term": "AMS",
      "definition": "Abis Monitoring System",
      "description": "A component in a wireless location system used to passively monitor the Global System for Global Communications (GSM) base transceiver station (BTS) - base station controller (BSC) signaling links on the Abis interface through T1/DS-3/OC-3 connections. The AMS decodes Abis messages, extracts and stores key information from the filtered messages, and transfers location support data to the serving mobile location center (SMLC) through Transmission Control Protocol/Internet Protocol (TCP/IP).",
      "source": null
    },
    {
      "id": 23,
      "term": "AMU",
      "definition": "Abis Monitoring Unit",
      "description": "A component in the Geometrix wireless location system used to provide information about Global System for Mobile Communications (GSM) wireless calls for initiating a location request. The AMU is used to extract the required information from the GSM network by monitoring the GSM 'Abis' interface between the base transceiver station (BTS) and the base station controller (BSC) for 911 calls. Once the AMU determines that a 911 call has been initiated, it then copies the required call information and transfers it to the geolocation control system (GCS).",
      "source": null
    },
    {
      "id": 24,
      "term": "ABN",
      "definition": "Abnormal",
      "description": "(Status Condition)",
      "source": null
    },
    {
      "id": 25,
      "term": "ABEND",
      "definition": "abnormal end",
      "description": "An operating system message that means a crash, lockup, or termination. ABEND usually signals a very serious problem and requires a restart or reboot. Also called 'abortive end.'",
      "source": null
    },
    {
      "id": 26,
      "term": "ASC",
      "definition": "Abnormal Station Code",
      "description": "",
      "source": null
    },
    {
      "id": 27,
      "term": "DTV-BO-AAXS",
      "definition": "Abode Domain Server",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=26579",
      "source": null
    },
    {
      "id": 28,
      "term": "ABTK",
      "definition": "abort task",
      "description": "Nortel: A Maintenance and Administration Position (MAP) command that allows a user to discontinue a manually initiated procedure.",
      "source": null
    },
    {
      "id": 29,
      "term": "AGL",
      "definition": "above ground level",
      "description": "A measurement of antenna height and location, along with geographical coordinates and other information, often required by regulatory agencies.",
      "source": null
    },
    {
      "id": 30,
      "term": "AMSL",
      "definition": "above mean sea level",
      "description": "A measurement of antenna height and location, along with geographical coordinates and other information, often required by regulatory agencies.",
      "source": null
    },
    {
      "id": 31,
      "term": "DTV-BO-ABRE",
      "definition": "ABR Encryptor",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=26469",
      "source": null
    },
    {
      "id": 32,
      "term": "ABSCON",
      "definition": "ABS Contract Management System",
      "description": "",
      "source": null
    },
    {
      "id": 33,
      "term": "ABSGlobalCustSvc",
      "definition": "ABS Global Customer Services",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=22762",
      "source": null
    },
    {
      "id": 34,
      "term": "ABS PMPS",
      "definition": "ABS Provisioning Metrics Process Support Data Lake",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=21776",
      "source": null
    },
    {
      "id": 35,
      "term": "ABS RECON+",
      "definition": "ABS Recon+ Frontier",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=13999",
      "source": null
    },
    {
      "id": 36,
      "term": "ABSRS",
      "definition": "ABS Reporting Services",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=21902",
      "source": null
    },
    {
      "id": 37,
      "term": "ASF",
      "definition": "ABS Salesforce",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym. \nFor more information, use this direct link to the entry in MOTS: http://ebiz.sbc.com/mots/detail.cfm?id=29572",
      "source": null
    },
    {
      "id": 38,
      "term": "ABS-SG",
      "definition": "Abs Service Guide",
      "description": "Displays Legacy-T service descriptions, rates and charges, and general information for business customers http://serviceguide.att.com/ABS/ext/.Includes an internal application that manages business content http://serviceguide.att.com/ABS/business/.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=14666",
      "source": null
    },
    {
      "id": 39,
      "term": "ABS Tariffs",
      "definition": "ABS Tariff Library",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=14668",
      "source": null
    },
    {
      "id": 40,
      "term": "ABSFO-IRIS",
      "definition": "ABSFO-ALARMS",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=19258",
      "source": null
    },
    {
      "id": 41,
      "term": "ACE",
      "definition": "Absolute Customer Experience",
      "description": "",
      "source": null
    },
    {
      "id": 42,
      "term": "ARFCN",
      "definition": "absolute radio frequency channel number",
      "description": "",
      "source": null
    },
    {
      "id": 43,
      "term": "ATD",
      "definition": "absolute time difference",
      "description": "",
      "source": null
    },
    {
      "id": 44,
      "term": "AES",
      "definition": "Abstract Expert System",
      "description": "",
      "source": null
    },
    {
      "id": 45,
      "term": "ASN",
      "definition": "Abstract Syntax Notation",
      "description": "",
      "source": null
    },
    {
      "id": 46,
      "term": "ASN.1",
      "definition": "Abstract Syntax Notation 1",
      "description": "",
      "source": null
    },
    {
      "id": 47,
      "term": "ASN.1",
      "definition": "Abstract Syntax Notation One",
      "description": "A local area network (LAN) 'grammar,' with rules and symbols, that is used to describe and define protocols and programming languages. It is the Open Systems Interconnection (OSI) standard for describing data types.",
      "source": null
    },
    {
      "id": 48,
      "term": "ATC",
      "definition": "abstract test case",
      "description": "A specification of the actions required to achieve a specific test purpose.",
      "source": null
    },
    {
      "id": 49,
      "term": "ATM",
      "definition": "abstract test method",
      "description": "A testing architecture consisting of a lower tester, upper tester, and test coordination procedures and their relationships to the system under test.",
      "source": null
    },
    {
      "id": 50,
      "term": "ATS",
      "definition": "abstract test suite",
      "description": "A group of test procedures composed of specific actions required to achieve a specific test purpose.",
      "source": null
    },
    {
      "id": 51,
      "term": "AWT",
      "definition": "Abstract Window Toolkit",
      "description": "",
      "source": null
    },
    {
      "id": 52,
      "term": "APIE",
      "definition": "Abstraction Polymorphism Inheritance and Encapsulation",
      "description": "",
      "source": null
    },
    {
      "id": 53,
      "term": "ACF",
      "definition": "AC fail (alarm)",
      "description": "",
      "source": null
    },
    {
      "id": 54,
      "term": "AC IT MGMT",
      "definition": "AC IT Management Site",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=14103",
      "source": null
    },
    {
      "id": 55,
      "term": "Sales Cloud (ACC)",
      "definition": "ACCBusiness - Salesforce.com",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=21115",
      "source": null
    },
    {
      "id": 56,
      "term": "ACFBI",
      "definition": "Accelerated Consumer Franchise Bundle Initiative",
      "description": "",
      "source": null
    },
    {
      "id": 57,
      "term": "ACFBI",
      "definition": "accelerated consumer franchise bundling initiative",
      "description": "",
      "source": null
    },
    {
      "id": 58,
      "term": "ADR",
      "definition": "Accelerated Depreciation Range",
      "description": "",
      "source": null
    },
    {
      "id": 59,
      "term": "AGP",
      "definition": "Accelerated Graphics Port",
      "description": "A platform bus specification that enables high performance graphics capabilities, especially 3D, on personal computers (PCs).",
      "source": null
    },
    {
      "id": 60,
      "term": "AIR",
      "definition": "Accelerated Interval Response",
      "description": "",
      "source": null
    },
    {
      "id": 61,
      "term": "AMS",
      "definition": "Accelerated Manual System",
      "description": "",
      "source": null
    },
    {
      "id": 62,
      "term": "AMP",
      "definition": "Accelerated Market Presence",
      "description": "",
      "source": null
    },
    {
      "id": 63,
      "term": "AMP",
      "definition": "Accelerated Mobile Pages",
      "description": "The Accelerated Mobile Pages (AMP) Project is an open source initiative that makes it easy for publishers to create mobile-friendly content once and have it load instantly everywhere.\n\nAMP technology is used on the consumer website to help it load faster for mobile searchers.",
      "source": null
    },
    {
      "id": 64,
      "term": "ATD97",
      "definition": "Accelerated Technology Deployment 1997",
      "description": "A five-year (1993-1997) end office switch modernization program which reduced switch types form the then current seven to two: Lucent's 5ESS family and NORTEL's DMS100 family.",
      "source": null
    },
    {
      "id": 65,
      "term": "CCOACT",
      "definition": "Accelerator Compliance Team",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym. \nFor more information, use this direct link to the entry in MOTS: http://ebiz.sbc.com/mots/detail.cfm?id=28787",
      "source": null
    },
    {
      "id": 66,
      "term": "ASI",
      "definition": "Accent Services Inc.",
      "description": "",
      "source": null
    },
    {
      "id": 67,
      "term": "ACC",
      "definition": "acceptable channel coding",
      "description": "",
      "source": null
    },
    {
      "id": 68,
      "term": "AQL",
      "definition": "acceptable quality level",
      "description": "According to Lean Six Sigma, when a continuing series of lots is considered, a quality level that (for the purposes of sampling inspection) is the limit of a satisfactory process average.",
      "source": null
    },
    {
      "id": 69,
      "term": "AUP",
      "definition": "Acceptable Use Policy",
      "description": "",
      "source": null
    },
    {
      "id": 70,
      "term": "ATP",
      "definition": "acceptance test plan",
      "description": "",
      "source": null
    },
    {
      "id": 71,
      "term": "ATP",
      "definition": "acceptance test procedure",
      "description": "?",
      "source": null
    },
    {
      "id": 72,
      "term": "ACC",
      "definition": "Access",
      "description": "Access type",
      "source": null
    },
    {
      "id": 73,
      "term": "AA",
      "definition": "Access Analytics",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=26372",
      "source": null
    },
    {
      "id": 74,
      "term": "AAPS",
      "definition": "Access Area Planning System",
      "description": "",
      "source": null
    },
    {
      "id": 75,
      "term": "AA",
      "definition": "Access Arrangement",
      "description": "",
      "source": null
    },
    {
      "id": 76,
      "term": "ABM",
      "definition": "Access Billing Management",
      "description": "",
      "source": null
    },
    {
      "id": 77,
      "term": "ABPT",
      "definition": "Access Broadband Portal Tool",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=18781",
      "source": null
    },
    {
      "id": 78,
      "term": "AB",
      "definition": "access burst",
      "description": "",
      "source": null
    },
    {
      "id": 79,
      "term": "ACDD",
      "definition": "Access Capability Due Date",
      "description": "Transport Order Manager‘s (TOM) circuit delivery due date",
      "source": null
    },
    {
      "id": 80,
      "term": "AC&M",
      "definition": "Access Capacity Management",
      "description": "",
      "source": null
    },
    {
      "id": 81,
      "term": "ACMC/ACMCS/ACMS",
      "definition": "Access Capacity Management Center System",
      "description": "",
      "source": null
    },
    {
      "id": 82,
      "term": "ACMS - Message",
      "definition": "Access Capacity Management System - Message",
      "description": "ACMS is an OSS used by the Regional Path Work Centers (RPWC) to perform the Toll Connect DS0 Ordering functions. MOTS_ID 12765 was listed as a sub application of this record, but was changed because 12765 is a parent application of mots_id 12807 (sls).\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=14165",
      "source": null
    },
    {
      "id": 83,
      "term": "ACMS - SPECIALS",
      "definition": "Access Capacity Management System - Specials",
      "description": "ACMS acts as the data base of record for the specials access inventory and acts as the industry standard ordering module that electronically interfaces with the Exchange Companies. It also tracks an access order through various stages of it life cycle reflecting this status in its data files.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=12672",
      "source": null
    },
    {
      "id": 84,
      "term": "ACPP",
      "definition": "Access Capacity Planning Platform",
      "description": "Gateway to applications commonly used in the Access Capacity Planning business process. ACPP will be the target access capacity management solution. Its application will combine the best of existing NETMART, TRACE, tariff and research tools. The objectives are to support access cost reduction, to provide combined view of LD and LOCAL tail-migration opportunity, and to support network planning process to roll-over circuits on-net.DBOR will be the single source of data to ACPP, and EFMS will provide work flow management.ACPP is a sub application of NetMart.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=14104",
      "source": null
    },
    {
      "id": 85,
      "term": "DTV-ACTS",
      "definition": "Access Card Tracking System",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=24801",
      "source": null
    },
    {
      "id": 86,
      "term": "ACG",
      "definition": "Access Carrier Gateway",
      "description": "Electronic Communication - Primary Interexchange Carrier (EC-PIC) application",
      "source": null
    },
    {
      "id": 87,
      "term": "ACN",
      "definition": "access carrier name",
      "description": "",
      "source": null
    },
    {
      "id": 88,
      "term": "ACNA",
      "definition": "ACCESS CARRIER NAME ABBREVIATION",
      "description": "",
      "source": null
    },
    {
      "id": 89,
      "term": "ACES",
      "definition": "Access Certificates for Electronic Services",
      "description": "The purpose of ACES is to facilitate public access to the services offered by government agencies through use of information technologies, including on-line access to computers for purposes of reviewing, retrieving, providing, and exchanging information.",
      "source": null
    },
    {
      "id": 90,
      "term": "ACAS",
      "definition": "Access Change Analysis System",
      "description": "Construction & Engineering (C&E)",
      "source": null
    },
    {
      "id": 91,
      "term": "AC/ACH",
      "definition": "Access Channel",
      "description": "1. Physical connection device owned and Maintained by AT&T to which Customer connect Customer Servers\n\n2. In code division multiple access (CDMA), a reverse channel used by mobile stations for communicating to base stations. The access channel is used for short signaling message exchanges such as call originations, responses to pages, and registrations.\nAbbreviated as either AC or ACH",
      "source": null
    },
    {
      "id": 92,
      "term": "ACN",
      "definition": "Access Channel Number",
      "description": "",
      "source": null
    },
    {
      "id": 93,
      "term": "ACAS",
      "definition": "Access Charge Analysis System",
      "description": "",
      "source": null
    },
    {
      "id": 94,
      "term": "ACES",
      "definition": "Access Charge Extraction System",
      "description": "",
      "source": null
    },
    {
      "id": 95,
      "term": "ACT-BC",
      "definition": "Access Charge Tool-Billing & Collection System",
      "description": "",
      "source": null
    },
    {
      "id": 96,
      "term": "ACT-SPL",
      "definition": "Access Charge Tool - SPL system",
      "description": "",
      "source": null
    },
    {
      "id": 97,
      "term": "ACT3-SW",
      "definition": "Access Charge Tool - Switching",
      "description": "",
      "source": null
    },
    {
      "id": 98,
      "term": "ACT-IV-SW-FM",
      "definition": "Access Charge Tool IV - Switched - File Model System",
      "description": "",
      "source": null
    },
    {
      "id": 99,
      "term": "ACT-MM",
      "definition": "Access Charge Tool Micro Model",
      "description": "Access Charge Tool Micro Model (system)",
      "source": null
    },
    {
      "id": 100,
      "term": "ACT-IV-SPL",
      "definition": "Access Charge Tool release IV SPL System",
      "description": "",
      "source": null
    },
    {
      "id": 101,
      "term": "ACV",
      "definition": "Access Charge Verification",
      "description": "",
      "source": null
    },
    {
      "id": 102,
      "term": "ACMS",
      "definition": "Access Circuit Maintenance System",
      "description": "ATS Contract Management System is a database to hold AT&T Maintenance Support contracts and application modules to manage Purchase/Budget Requests, Financial data, and reporting.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=25938",
      "source": null
    },
    {
      "id": 103,
      "term": "ACTL",
      "definition": "Access Circuit Termination Location",
      "description": "",
      "source": null
    },
    {
      "id": 104,
      "term": "AC",
      "definition": "access class",
      "description": "",
      "source": null
    },
    {
      "id": 105,
      "term": "ACS",
      "definition": "access communications server",
      "description": "",
      "source": null
    },
    {
      "id": 106,
      "term": "ACSD",
      "definition": "Access Complaints Shared Documents",
      "description": "",
      "source": null
    },
    {
      "id": 107,
      "term": "AC",
      "definition": "Access Condition",
      "description": "",
      "source": null
    },
    {
      "id": 108,
      "term": "AC",
      "definition": "Access Connection",
      "description": "",
      "source": null
    },
    {
      "id": 109,
      "term": "ACMC",
      "definition": "Access Connection Maintenance System",
      "description": "Record database for tracking PON (Purchase Order Number).",
      "source": null
    },
    {
      "id": 110,
      "term": "ACC",
      "definition": "access control class",
      "description": "",
      "source": null
    },
    {
      "id": 111,
      "term": "ACF",
      "definition": "ACCESS CONTROL FACILITY",
      "description": "ACF or ACF2 or CA-ACF2 - Access Control Facility, a third-party security package for MVS, similar in function to RACF by IBM. Presently marketed by Computer Associates (\"CA\"), ACF2 was the security product in use on BellSouth (\"cB\") until replaced by RACF.",
      "source": null
    },
    {
      "id": 112,
      "term": "ACF",
      "definition": "Access Control Field",
      "description": "",
      "source": null
    },
    {
      "id": 113,
      "term": "ACL",
      "definition": "access control list",
      "description": "A network security feature that controls the use of available services. The ACL defines services available with a list of hosts (Internet Protocol addresses) permitted to use the services.",
      "source": null
    },
    {
      "id": 114,
      "term": "ACL",
      "definition": "Access Control List",
      "description": "Information security term which defines users and roles for access to systems",
      "source": null
    },
    {
      "id": 115,
      "term": "ACP",
      "definition": "Access Control Point",
      "description": "",
      "source": null
    },
    {
      "id": 116,
      "term": "ACR",
      "definition": "access control register",
      "description": "",
      "source": null
    },
    {
      "id": 117,
      "term": "MOBNT-ACS Jumpbox",
      "definition": "Access Control System Jumpbox",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=21967",
      "source": null
    },
    {
      "id": 118,
      "term": "AC",
      "definition": "Access Controller",
      "description": "",
      "source": null
    },
    {
      "id": 119,
      "term": "ACM",
      "definition": "Access Conversation Minutes",
      "description": "",
      "source": null
    },
    {
      "id": 120,
      "term": "ACF",
      "definition": "Access Coordination Function",
      "description": "",
      "source": null
    },
    {
      "id": 121,
      "term": "ACI",
      "definition": "access core network interface",
      "description": "",
      "source": null
    },
    {
      "id": 122,
      "term": "ACF",
      "definition": "Access Cost Factor",
      "description": "",
      "source": null
    },
    {
      "id": 123,
      "term": "ACM",
      "definition": "Access Cost Management",
      "description": "",
      "source": null
    },
    {
      "id": 124,
      "term": "ACMF",
      "definition": "Access Cost Management - Fixed",
      "description": "",
      "source": null
    },
    {
      "id": 125,
      "term": "ACM - LDFM",
      "definition": "Access Cost Management/Access Cost Management - Fixed",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=7511",
      "source": null
    },
    {
      "id": 126,
      "term": "AC",
      "definition": "Access Customer",
      "description": "",
      "source": null
    },
    {
      "id": 127,
      "term": "ACNA",
      "definition": "Access Customer Name Abbreviation",
      "description": "A three-digit alphanumeric code assigned to identify carriers, including both incumbent local exchange carriers (ILECs) and competitive local exchange carriers (CLECs) for billing and other identification purposes. Vendor's acronym is IAC.",
      "source": null
    },
    {
      "id": 128,
      "term": "ACTL",
      "definition": "Access Customer Terminal Information or Location",
      "description": "Identifies the CLLI code of the customer facility terminal location. Provisioning Field Identifier (FID)",
      "source": null
    },
    {
      "id": 129,
      "term": "APOT",
      "definition": "Access Customer Terminal Location Point Of Termination",
      "description": "",
      "source": null
    },
    {
      "id": 130,
      "term": "ADUF",
      "definition": "Access Daily Usage Feed",
      "description": "Daily Feed of access usages records to CLECs. ADUF receives files from UCM. It edits and packages these access records and ships the records to the CLECs. The CLECs can use these daily access files to recover access charges. BASIS is the vehicle used to charge for the CLEC for the ADUF service.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=15298",
      "source": null
    },
    {
      "id": 131,
      "term": "ADI",
      "definition": "access data interface",
      "description": "",
      "source": null
    },
    {
      "id": 132,
      "term": "SAMS",
      "definition": "Access Data Warehouse (also known as ADW or SAMS)",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=13782",
      "source": null
    },
    {
      "id": 133,
      "term": "ACDN",
      "definition": "access directory number",
      "description": "",
      "source": null
    },
    {
      "id": 134,
      "term": "AED",
      "definition": "Access Edge Device",
      "description": "An edge device is a device that provides an entry point into enterprise or service provider core networks.",
      "source": null
    },
    {
      "id": 135,
      "term": "AFP",
      "definition": "Access Facility Provisioning",
      "description": "",
      "source": null
    },
    {
      "id": 136,
      "term": "AFTER",
      "definition": "Access Forecasting Tool / EAF Replacement",
      "description": "",
      "source": null
    },
    {
      "id": 137,
      "term": "AFID",
      "definition": "access function identity",
      "description": "",
      "source": null
    },
    {
      "id": 138,
      "term": "AGW",
      "definition": "Access Gateway",
      "description": "",
      "source": null
    },
    {
      "id": 139,
      "term": "AGOC",
      "definition": "Access Generic Order Control",
      "description": "",
      "source": null
    },
    {
      "id": 140,
      "term": "AGCH",
      "definition": "Access Grant Channel",
      "description": "A circuit used to allocate a standalone dedicated control channel (SDCCH) to a mobile for signaling (in order to obtain a dedicated channel), following a request on the random access channel (RACH). In Global System for Mobile Communications (GSM) technology, AGCH is a common control channel used by the base transceiver station (BTS) to send information to the mobile station (MS), including which dedicated control channels to use. The first timing advance value (TVA) is also sent on AGCH.",
      "source": null
    },
    {
      "id": 141,
      "term": "AID",
      "definition": "Access Identifier",
      "description": "",
      "source": null
    },
    {
      "id": 142,
      "term": "AI",
      "definition": "Access Interface",
      "description": "",
      "source": null
    },
    {
      "id": 143,
      "term": "AIU",
      "definition": "Access Interface Unit",
      "description": "",
      "source": null
    },
    {
      "id": 144,
      "term": "AIM",
      "definition": "Access Intervention Management",
      "description": "The Access Intervention Management (AIM) Team is the single point of interface for escalations at the 5th level and above with AT&T's Domestic US, Puerto Rico and Virgin Islands external access suppliers.",
      "source": null
    },
    {
      "id": 145,
      "term": "ALOC",
      "definition": "Access Line Class Mark",
      "description": "",
      "source": null
    },
    {
      "id": 146,
      "term": "ALG",
      "definition": "Access Line Group",
      "description": "",
      "source": null
    },
    {
      "id": 147,
      "term": "A-Link",
      "definition": "Access Link",
      "description": "Also called the \"site link\" and the local loop. Access link is the private communications circuit that connects a location to the AT&T frame relay network. This network is also called a frame relay cloud. The communications channel that carries signals between a signal transfer point (STP) and a signaling point (SP), service control point (SCP), or service signaling point (SSP).",
      "source": null
    },
    {
      "id": 148,
      "term": "ALCAP",
      "definition": "Access Link Control Application Protocol",
      "description": "also Access Link Control Application Part",
      "source": null
    },
    {
      "id": 149,
      "term": "ALU",
      "definition": "Access Link Utilization",
      "description": "Network Performance Report (NPR)/Inforvista customer performance reports",
      "source": null
    },
    {
      "id": 150,
      "term": "AGA",
      "definition": "Access List Generation Aid",
      "description": "",
      "source": null
    },
    {
      "id": 151,
      "term": "AMS",
      "definition": "Access Management System",
      "description": "1) Design/Specifications Development. Account Management System provides Account Receivable, Collection and Treatment Information for Exchange Carrier Customers for 8 states and CLEC 7 state data from CRIS and CABS\n2) Element Management System (EMS) that provides remote interface with the Lightspeed Access nodes 7340/7342/736x FTTP and 7330 FTTN. Contains 5520 AMS-9.X\nAlso abbreviated as 5520 AMS\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=10097",
      "source": null
    },
    {
      "id": 152,
      "term": "AMS (EMS)",
      "definition": "Access Management System",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=14664",
      "source": null
    },
    {
      "id": 153,
      "term": "AMS - West",
      "definition": "Access Management System - West",
      "description": "",
      "source": null
    },
    {
      "id": 154,
      "term": "AMS - SE",
      "definition": "Access Management Systems - SE",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=16149",
      "source": null
    },
    {
      "id": 155,
      "term": "AM",
      "definition": "Access Module",
      "description": "",
      "source": null
    },
    {
      "id": 156,
      "term": "AMG",
      "definition": "Access Module Group",
      "description": "access component of the Integrated Multimedia Service (IMS) supporting Universal Services Platform (USP). The AMG is comprised of the Session Border Controller (SBC) and other sub components.",
      "source": null
    },
    {
      "id": 157,
      "term": "AMIS",
      "definition": "Access Monitoring Information System",
      "description": "",
      "source": null
    },
    {
      "id": 158,
      "term": "AMSVPP",
      "definition": "Access Multi-Service Volume Pricing Plan",
      "description": "",
      "source": null
    },
    {
      "id": 159,
      "term": "AMF",
      "definition": "Access Multiplexing Function",
      "description": "",
      "source": null
    },
    {
      "id": 160,
      "term": "AN",
      "definition": "Access Network",
      "description": "",
      "source": null
    },
    {
      "id": 161,
      "term": "ANCM",
      "definition": "Access Network Capacity Management",
      "description": "",
      "source": null
    },
    {
      "id": 162,
      "term": "ANOPT",
      "definition": "Access Network Optimization Project Tracking",
      "description": "",
      "source": null
    },
    {
      "id": 163,
      "term": "ANS - SE",
      "definition": "Access Network System - SE",
      "description": "",
      "source": null
    },
    {
      "id": 164,
      "term": "LCATOOL",
      "definition": "Access Number Database Update Tools",
      "description": "",
      "source": null
    },
    {
      "id": 165,
      "term": "AOMT",
      "definition": "Access Option Management Tool",
      "description": "",
      "source": null
    },
    {
      "id": 166,
      "term": "AO",
      "definition": "Access Order",
      "description": "",
      "source": null
    },
    {
      "id": 167,
      "term": "AOSTE",
      "definition": "Access Order Specification Tracking Environment",
      "description": "This is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\n For more information, use this direct link to the entry in MOTS: \n http://ebiz.sbc.com/mots/detail.cfm?id=19409",
      "source": null
    },
    {
      "id": 168,
      "term": "ACCOLC",
      "definition": "Access Overload Class",
      "description": "A two-digit code designed to guide systems in prioritizing certain special-use customers (such as emergency service) in the event of system overload. Many systems do not use this feature. The overload class is set to 0 plus the last digit of the phone number to provide randomization.",
      "source": null
    },
    {
      "id": 169,
      "term": "APC",
      "definition": "Access permission Code",
      "description": "Provisioning Field Identifier (FID)",
      "source": null
    },
    {
      "id": 170,
      "term": "APAGS",
      "definition": "Access Planning And Grooming System",
      "description": "",
      "source": null
    },
    {
      "id": 171,
      "term": "AP",
      "definition": "Access Point",
      "description": "The device that provides connection to a wireless system or network, for example, a wireless local area network (WLAN). Also known as a base station, the access point is usually connected to a wired network.\n A location where a Wi-Fi signal originates or is received.",
      "source": null
    },
    {
      "id": 172,
      "term": "APD",
      "definition": "Access Point Data",
      "description": "",
      "source": null
    },
    {
      "id": 173,
      "term": "APDB",
      "definition": "access point database",
      "description": "",
      "source": null
    },
    {
      "id": 174,
      "term": "APN",
      "definition": "Access Point Name",
      "description": "(1) The logical identifier for the point of entry to an external packet data network. (2) The service description and routing for General Packet Radio Service/enhanced data rate for global evolution (GPRS/EDGE) data for application use. APN examples used by Cingular include wap.cingular, isp.cingular, and blackberry.net. Commercial Connectivity Services (CCS) rate plans include the isp.cingular APN, bundled in all CCS rate plans.",
      "source": null
    },
    {
      "id": 175,
      "term": "APN",
      "definition": "Access Point Naming",
      "description": "Access Point Naming is the assigning of identifying names (URLs) to access points that allow names to identify node IP addresses within GSM and GPRS networks. An APN is composed of two parts; a network ID and an operator specific ID. The network ID identifies the service requested by a user in a network and the operator ID identifies the specific routing information.",
      "source": null
    },
    {
      "id": 176,
      "term": "APOT",
      "definition": "Access Point of Termination",
      "description": "",
      "source": null
    },
    {
      "id": 177,
      "term": "APR",
      "definition": "Access Point Roaming",
      "description": "A capability that allows handover from cell to cell within a wireless local area network (WLAN), such as from a Bluetooth piconet to a macro network.",
      "source": null
    },
    {
      "id": 178,
      "term": "AP",
      "definition": "Access Preamble",
      "description": "",
      "source": null
    },
    {
      "id": 179,
      "term": "APO",
      "definition": "Access Protection Option",
      "description": "",
      "source": null
    },
    {
      "id": 180,
      "term": "APIO",
      "definition": "access provided initiated orders",
      "description": "",
      "source": null
    },
    {
      "id": 181,
      "term": "AP",
      "definition": "Access Provider",
      "description": "",
      "source": null
    },
    {
      "id": 182,
      "term": "AQ",
      "definition": "Access Quote",
      "description": "",
      "source": null
    },
    {
      "id": 183,
      "term": "AR",
      "definition": "Access Rate",
      "description": "The data transmission rate of the user access channel. The speed of the access channel determines the maximum rate at which the end user can inject data into a frame relay network.",
      "source": null
    },
    {
      "id": 184,
      "term": "AR_ADDR",
      "definition": "access request address",
      "description": "In Bluetooth technology, an indicator used by the parked slave to determine in which slave-to-master half slot in the access window it is allowed to send access request messages. It is valid only as long as the slave is parked and is not necessarily unique.",
      "source": null
    },
    {
      "id": 185,
      "term": "DTV-ARIS",
      "definition": "Access Request Information Systems",
      "description": "ARIS is a business process modeling tool (vendor is Software AG) that runs on a client server infrastructure. ARIS is used in decision to leverage the Amdocs methodology to support analysis and design (what usually takes place as part of creation of our SAS/HLD deliverables) for the Billing Transformation program.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=24823",
      "source": null
    },
    {
      "id": 186,
      "term": "ARM",
      "definition": "Access Resource Manager",
      "description": "",
      "source": null
    },
    {
      "id": 187,
      "term": "ARCH",
      "definition": "access response channel",
      "description": "A logical channel defined by the IS-136 protocol sent from the cell site to the phone. It carries system responses to phone requests.",
      "source": null
    },
    {
      "id": 188,
      "term": "ART - C",
      "definition": "Access Review Tool",
      "description": "Periodic snapshot of Datamart used to conduct periodic review of user access requests.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=17756",
      "source": null
    },
    {
      "id": 189,
      "term": "AR",
      "definition": "Access Router",
      "description": "Access Router Common Back Bone (CBB) that connects to customers",
      "source": null
    },
    {
      "id": 190,
      "term": "ARACS",
      "definition": "Access Router Auto Configuration System",
      "description": "",
      "source": null
    },
    {
      "id": 191,
      "term": "ARR",
      "definition": "Access Router Redundancy",
      "description": "",
      "source": null
    },
    {
      "id": 192,
      "term": "ARR-SS-DR",
      "definition": "Access Router Redundancy-Single Site-Dual Router",
      "description": "",
      "source": null
    },
    {
      "id": 193,
      "term": "AC",
      "definition": "Access Section",
      "description": "of Universal Service Order (USO) or Customer Service Record (CSR))",
      "source": null
    },
    {
      "id": 194,
      "term": "ASC",
      "definition": "Access Service Center",
      "description": "",
      "source": null
    },
    {
      "id": 195,
      "term": "ASC/DSS",
      "definition": "Access Service Center / Decision Support System",
      "description": "This application allows the ASC service reps to evaluate FOC intervals for Access Service Requests (ASRs) from EXACT as well as measure the Speed of Order Issuance (SOI) from the time an ASR is received to the time an order is distributed. ASC/DSS combines data from EXACT, SORD, (and CABS). The application currently provides reporting for all regions for most reports. Legacy reports are being evaluated and updated to all-region reporting as the data from the various systems is available and has been validated.\nThis is a Mechanized Operations Tracking System (MOTS) entry. The 'Term' field contains the MOTS entry application name, and the 'Acronym' field contains the MOTS entry acronym.\nFor more information, use this direct link to the entry in MOTS:\nhttp://ebiz.sbc.com/mots/detail.cfm?id=272",
      "source": null
    },
    {
      "id": 196,
      "term": "ASC",
      "definition": "Access Service Class",
      "description": "",
      "source": null
    },
    {
      "id": 197,
      "term": "ASG",
      "definition": "Access Service Group",
      "description": "",
      "source": null
    },
    {
      "id": 198,
      "term": "ASIP/FAS",
      "definition": "Access Service Improvement Process/Facility Availability System",
      "description": "",
      "source": null
    },
    {
      "id": 199,
      "term": "ASR",
      "definition": "Access Service Request",
      "description": "",
      "source": null
    },
    {
      "id": 200,
      "term": "ABAN",
      "definition": "Access Service Request Billing Agreement",
      "description": "Provisioning Field Identifier (FID)",
      "source": null
    }
  ]
}