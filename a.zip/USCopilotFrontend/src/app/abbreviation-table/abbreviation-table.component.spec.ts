import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbbreviationTableComponent } from './abbreviation-table.component';

describe('AbbreviationTableComponent', () => {
  let component: AbbreviationTableComponent;
  let fixture: ComponentFixture<AbbreviationTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AbbreviationTableComponent]
    });
    fixture = TestBed.createComponent(AbbreviationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
