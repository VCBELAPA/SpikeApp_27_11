import { Component } from '@angular/core';
import { CommonService } from '../service/common.service';
import { NgForm } from '@angular/forms';
import { RESTAPIServiceService } from '../service/restapiservice.service';
import { Observable } from 'rxjs';
import { NGXLogger } from 'ngx-logger';

@Component({
  selector: 'app-user-manager',
  templateUrl: './user-manager.component.html',
  styleUrls: ['./user-manager.component.scss']
})
export class UserManagerComponent {
  constructor(public commonService: CommonService, private httpService: RESTAPIServiceService) {
    this.allKb$ = commonService.AllKb;
    this.logger = commonService.logger;
    this.logger.debug("Constructing UserManagerComponent");
  }
  logger:NGXLogger;
  allKb$: Observable<string[]>;
  currentKb = '';
  addUserMessage = '';
  removeUserMessage = '';
  addUserProgress = false;
  removeUserProgress = false;
  addUser(f: NgForm) {
    if (!f.value.att_uid || !f.value.user_role) {
      this.addUserMessage = 'Please Enter AttUID and User Role'
      return;
    }
    if (!this.commonService.currentKB) {
      this.addUserMessage = 'Please select Knowledge Base'
      return;
    }
    const role = f.value.user_role;
    const attuid = f.value.att_uid;
    const body = {
      "vector_db": this.commonService.currentKB,
      "role": role,
      "attuid": attuid
    };
    f.reset();
    this.addUserProgress = true;
    this.logger.debug("Requesting to /vector_db/acces:", body);
    this.httpService.postReq("/vector_db/access", body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from /vector_db/acces:", data);
        if (data.response) {
          this.addUserMessage = data.response;
        }
      },
      error: (err) => {
        this.logger.error("Error Response from /vector_db/acces:", err);
        if (err.status == 400) {
          if (err.error['error']) this.addUserMessage = err.error['error'];
          else this.addUserMessage = err.error;
        } else if (err.message) {
          this.addUserMessage = err.message;
        } else {
          this.addUserMessage = err;
        }
        this.addUserProgress = false;
      },
      complete: () => {
        // do nothing
        this.addUserProgress = false;
      }
    })
  }

  removeUser(f: NgForm) {
    if (!f.value.att_uid) {
      this.removeUserMessage = 'Please Enter AttUID and User Role'
      return;
    }
    if (!this.commonService.currentKB) {
      this.removeUserMessage = 'Please select Knowledge Base'
      return;
    }
    const attuid = f.value.att_uid;
    const body = {
      "vector_db": this.commonService.currentKB,
      "attuid": attuid
    };
    f.reset();
    this.removeUserProgress = true;
    this.logger.debug("Requesting to delete /vector_db/acces:", body);
    this.httpService.deleteReq("/vector_db/access", body).subscribe({
      next: (data: any) => {
        this.logger.debug("Response from delete /vector_db/acces:", data);
        if (data.response) {
          this.removeUserMessage = data.response;
        }
      },
      error: (err) => {
        this.logger.error("Error Response from delete /vector_db/acces:", err);
        if (err.status == 400) {
          if (err.error['error']) this.removeUserMessage = err.error['error'];
          else this.removeUserMessage = err.error;
        } else if (err.message) {
          this.removeUserMessage = err.message;
        } else {
          this.removeUserMessage = err;
        }
        this.removeUserProgress = false;
      },
      complete: () => {
        // do nothing
        this.removeUserProgress = false;
      }
    })
  }


}
