# USCopilotFrontend

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.1.1.

## To run GUI in local Machine

After cloning the project just follow the instructions.

```
cd USCopilotFrontend
npm install
ng serve --host 127.0.0.1 --port 4200 --open
```

this will open a new tab in the browser and load the GUI If not use this URL `http://127.0.0.1:4200/static/`

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io). currently There are no unit tests

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities. currently There are no tests

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
