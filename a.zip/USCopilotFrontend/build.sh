#!/bin/bash
export PATH=/home/jenkins/bin:$PATH
export http_proxy=http://pxyapp.proxy.att.com:8080
export all_proxy=http://pxyapp.proxy.att.com:8080
export https_proxy=http://pxyapp.proxy.att.com:8080
# use package json for tag number
export tag=$(node -e 'console.log(require("./package.json").version)')
export image=$(node -e 'console.log(require("./package.json").name)')

npm i
unset http_proxy
unset https_proxy
unset all_proxy
npm run build
docker build -t ${image}:${tag} .
