import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { environment } from 'src/environments/environment';

export interface KbData {
  number: string;
  name: string;
}

@Component({
  selector: 'app-kb-files',
  templateUrl: './kb-files.component.html',
  styleUrls: ['./kb-files.component.css']
})
export class KbFilesComponent {
  constructor(private http: HttpClient, private _snackBar: MatSnackBar) {
    // Create 100 users
    this.getKbFiles("test");
    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(this.kbArray);
  }
  

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  kbArray: KbData[] = [];
  backendUrl=environment.api_url;
  displayedColumns: string[] = ['number', 'name', 'download'];
  dataSource: MatTableDataSource<KbData>;

  getKbFiles(domain:string){
    console.log("getting KB files");
    //empty current dataSource
    this.kbArray = [];
    this.dataSource = new MatTableDataSource(this.kbArray);
    const api$ = this.http.get<any>(this.backendUrl + "/vector_db/"+domain+"/sp030n");
    api$.subscribe({
      next: (data) => {
        const docs = data.documents;
        for (let index = 0; index < docs.length; index++) {
          let element:string = docs[index].toString();
          let kbJson = {
            "number": (index+1).toString(),
            "name": element
          }
          this.kbArray[index] = kbJson;
        }
        this.dataSource = new MatTableDataSource(this.kbArray);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (err) => {
        console.log(err);
        
      },
      complete: () => {
        
      },
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  download(doc_name:string) {
    this._snackBar.open(doc_name, 'close')
  }

}
