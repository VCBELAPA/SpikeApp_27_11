import { Component , ViewEncapsulation} from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import {CommentDialogComponent} from './comment-dialog/comment-dialog.component'
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { environment } from 'src/environments/environment';
import { FormControl, NgForm, Validators } from '@angular/forms';

export interface BackendResp {
  status: number;
  error: string | undefined;
  response: object | undefined;
}

//const VERSION = '#AINLM_VERSION#'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class AppComponent {
  title = 'Ask Ambrin';
  showKm = false;
  model = '';
  //ne=true;
  //kmInputs=['kmName', 'other'];
  domainData: any[][] = [];
  kmData: {[key: string]: string[]} = {};
  km='';
  apiStatus='';
  prompt='';
  activeKm='P1/P2';
  //backendUrl='http://130.3.77.227:8081';
  //dbUrl="http://130.3.77.227:8081";
  //backendUrl='http://localhost:4500';
  backendUrl=environment.api_url;
  att_id = 'sp030n';
  att_initials = 'SP';
  att_fname = 'SHREENAL';
  att_lname = 'PATEL'
  apiResponse = <BackendResp>{status : 0};
  waiting = false;
  response = "";
  kmFiles = ['file1','file2'];
  showUpdate = false;
  teach=false;
  create=false;
  uploadMessage='';
  createMessage='';
  uploadFile : EventTarget | null = null;
  formData : FormData | null = null;
  kmName = '';
  infoMsg='No Knowledge bases loaded, please pick one from the sidebar'
  fileName='';
  questions : string[] = [];
  answers : string[] = [];
  chat : any[] =[]
  showComment = false;
  cmt = '';
  showExpert = false;
  expertId='';
  gpu: number[] = [];
  sources: string[][] = [];
  text: string = '';
  deleteMessage = '';
  responseMessage ='';
  currentApplicationVersion = environment.appVersion;


  constructor( private http: HttpClient, private _snackBar: MatSnackBar, public dialog: MatDialog ) {
    this.loadKm();
    this.gpuStat();
    if (environment.production) {
      this.getAttuid();
    }
  }

  getAttuid(){
    let attArray = decodeURIComponent((document.cookie.split(';').filter(s=>s.includes('attESHr'))[0] || '').trim()).split('|');
    console.log(attArray);
    this.att_id = attArray[2].split('@')[0];
    console.log('att_id: '+this.att_id);
    this.att_fname = attArray[0].split('=')[1];
    this.att_lname = attArray[1];
    this.att_initials = this.att_fname.charAt(0) + this.att_lname.charAt(0);
  }

  changeModel(){
    if(this.model == 'falcon') {
      this.backendUrl=environment.api_url;
    } else if (this.model == 'llama') {
      this.backendUrl=environment.api_url;
    }
  }

  openWindow(title:string, data:string) {
    var newStr = data.replaceAll('<', "&lt").replaceAll('>', "&gt");
    var newWindow = window.open();
    var html = "<h1>"+title+"</h1><p style='white-space: pre-line;white-space: pre-wrap;'>"+newStr+"</p>";
    newWindow!.document.write(html);
  }

  openDialogCmt(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      'prompt' : "leave a comment or Correct Answer",
      'answer' : "",
      'myAnswer': "",
      'context_rating': ""
    };
    dialogConfig.width = '70%';
    dialogConfig.height = 'auto';
    const dialogRef = this.dialog.open(CommentDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('The dialog was closed ' + JSON.stringify(result));
      this.comment(result.answer, result.myAnswer, result.context_rating);
    });
  }

  openDialogText(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      'text': true,
      'prompt' : "Text Input",
      'answer' : "",
      'file_name': ""
    };
    dialogConfig.width = '70%';
    dialogConfig.height = 'auto';
    const dialogRef = this.dialog.open(CommentDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('The dialog was closed ' + JSON.stringify(result));
      this.textInput(result.file_name, result.answer);
    });
  }

  loadKm() {
    this.apiStatus='waiting';
    const api$ = this.http.get<any>(this.backendUrl + '/domains');
    api$.subscribe({
      next: (data) => {
        this.domainData = data.response; // {status: 0, response: 'stirng', 'error': 'string'}
        this.apiStatus = data.status ? 'Response ok' : `errors: ${data.error}`;
        console.log(JSON.stringify(this.domainData));
        this.domaintoKm();
      },
      error: (err) => {
        this.apiStatus = `errors: ${err.message}`;
        console.log(JSON.stringify(err));
        
        this.domainData=[
          [
              2,
              "test",
              "used for testing only"
          ],
          [
              3,
              "P1/P2",
              "P1/P2 related information"
          ],
          [
              4,
              "CANOPI",
              "CANOPI documents"
          ]
      ];
      this.domaintoKm();
      },
      complete: () => {
        
          this.apiStatus='';
        
        
      }
    })
  }

  domaintoKm(){
    for(var i: number = 0; i < this.domainData.length; i++) {
      for(var j: number = 0; j< this.domainData[i].length; j++) {
          this.kmData[this.domainData[i][1]] = [];
          this.kmData[this.domainData[i][1]].push(this.domainData[i][2])
          console.log(JSON.stringify(this.kmData));
          
      }
  }
  }

  query(f : NgForm) {
    console.log(f.value)
    this.prompt = f.value.question;
    if (!this.prompt) {
      return;
    } 
    this.apiStatus='waiting';
    console.log("inside query");
    this.response='';
    let formData=new FormData();
    formData.set('prompt', this.prompt)
    const bodyJson = {
      "user_prompt" : this.prompt
    };
    const headers = { 'content-type': 'application/json'}  
    const body = JSON.stringify(bodyJson);
    console.log(body);
    const api$ = this.http.post<any>(this.backendUrl + "/api/prompt_route/test/" + this.att_id, body, {'headers':headers} );
    this.questions.push(this.prompt);
    this.prompt = "";
    f.reset();
    api$.subscribe({
      next: (data) => {
        console.log(JSON.stringify(data));
        this.apiResponse = data.Answer;
        this.sources = data.Sources;
        const chatJson = {
          "question":data.prompt,
          "question_id":data["Question Id"],
          "answer":data["Answer"],
          "answer_id":data["Answer ID"]
        };
        this.chat.push(chatJson);
        this.apiStatus = data.status ? 'Response ok' : `errors: ${data.error}`;
        this.gpuStat();
      },
      error: (err) => {
        this.responseMessage = `errors: ${err.message}`;
        this.answers.push("Sorry,\n Because of technical difficulties, I am unable to Answer right now. Please try again later");
        console.log("inside query error" + this.answers.toString());
        // sample sources
        this.sources = 
          [
            [
              "sample.pdf",
              "Pytorch is a library in Python that can be used to build ar2ﬁcial neural networks."
            ],
            [
              "sample.pdf",
              "Pytorch is a library in Python that can be used to build ar2ﬁcial neural networks."
            ]
          ]
        
      },
      complete: () => {
        this.response = this.apiResponse.toString();
        this.answers.push(this.response);
      }
    })
  } 

  regenerate() {
    this.apiStatus='waiting';
    console.log("inside query");
    
    this.response='';
    this.prompt = this.questions[this.questions.length -1];
    const bodyJson = {
      "user_prompt" : this.prompt
    };
    const headers = { 'content-type': 'application/json'}  
    const body = JSON.stringify(bodyJson);
    console.log(body);
    const api$ = this.http.post<any>(this.backendUrl + "/api/prompt_route/test/" + this.att_id, body, {'headers':headers} );
    this.questions.push(this.prompt);
    this.prompt = "";
    api$.subscribe({
      next: (data) => {
        console.log(JSON.stringify(data));
        this.apiResponse = data.Answer;
        this.sources = data.Sources;
        const chatJson = {
          "question":data.prompt,
          "question_id":data["Question Id"],
          "answer":data["Answer"],
          "answer_id":data["Answer ID"]
        };
        this.chat.push(chatJson);
        this.apiStatus = data.status ? 'Response ok' : `errors: ${data.error}`;
        this.gpuStat();
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        this.answers.push(this.response);
        
        console.log("inside query error" + this.answers.toString());
        // sample sources
        this.sources = 
          [
            [
              "sample.pdf",
              "Pytorch is a library in Python that can be used to build ar2ﬁcial neural networks."
            ],
            [
              "sample.pdf",
              "Pytorch is a library in Python that can be used to build ar2ﬁcial neural networks."
            ]
          ]
        
      },
      complete: () => {
        this.response = this.apiResponse.toString();
        this.answers.push(this.response);
      }
    })
  }
/*
onUpdate(event: Event) {
      const element:HTMLInputElement = <HTMLInputElement>event.target;
      if (element.files) {  // this was the file object, store the file info
        this.formData.set('myfile', element.files[0])
        this.fileName = element.files[0].name
      } else {  // must be metadata so store that
        this.formData.set(element.name, element.value)
      }
      this.formData.forEach((f) => console.log(f))
  }

  upload() {
      //const formData = new FormData();
      //formData.append("myfile", this.file);
      if (this.formData.has('myfile')) {
        const upload$ = this.http.post<BackendResp>(this.uploadUrl, this.formData);
        */
  upload(event?: Event) {
    // gets called with or without event;  if event is NOT present, the file was already selected
    //    and user hit the upload button.  If event is present, then the user is just selecting the file
    
    if (event) {  // file is selected
      const element:HTMLInputElement = <HTMLInputElement>event.target;
      if (element.files) {
        this.formData = new FormData();
        this.fileName = '';
        for (let i = 0; i < element.files.length; i++) {
          this.formData.append('files', element.files[i]);
          this.fileName = this.fileName +", " + element.files[i].name;
        }
        //this.formData.append('files', this.formData.getAll('file'));
        console.log('inside upload' + this.fileName);
        console.log(this.formData);
      } else {
        this.uploadMessage = 'Internal error on file loader';
      }    
    } else {
      // this must be the upload trigger
      if (!this.formData) {
        this.uploadMessage = 'intenal erorr:Select a file first';
      } else {
        // upload
        this.uploadMessage=`Uploading ${this.fileName}`
        this.fileName="";
        const api$ = this.http.post<any>(this.backendUrl + "/Ingest_PDFS/test/" + this.att_id, this.formData );
        api$.subscribe({
          next: (data) => {
            this.uploadMessage = "Files successfully uploded.";
            console.log('inside upload' + JSON.stringify(data));
          },
          error: (err) => {
            this.uploadMessage = `errors: ${err.message}`;
            console.log('inside upload error' + JSON.stringify(err));
            this._snackBar.open('upload Failed', 'close')
          },
          complete: () => {
            
              this.uploadMessage='Files successfully uploded.';
              //this.loadKm();
            
          }
        })
      }
    }
  }

  newKm() {
    if (!this.kmName.match(/^\w+$/)) {
      this.createMessage = 'Only alphanumeric and _ is allowed in KM name';
    } else {
      const api$ = this.http.post<BackendResp>(this.backendUrl + `/create/${this.kmName}`,null );
      api$.subscribe({
        next: (data) => {
          this.apiResponse = data;
          this.createMessage = data.status ? 'Response ok' : `errors: ${data.error}`;
        },
        error: (err) => {
          this.createMessage = `errors: ${err.message}`;
        },
        complete: () => {
            this.createMessage='Done';
            //this.loadKm();
          }
      })
    }
  } 

  like() {
    this.apiStatus='waiting';
    const body = {
      "values": {
        'rating': '10'
      } 
    }
    const headers = { 'content-type': 'application/json'};
    //get answer id for last question
    const aid = this.chat[this.chat.length - 1]["answer_id"].toString();;
    //const aid = this.chat[this.chat.length - 1]["answer_id"].toString();
    const api$ = this.http.post<any>(this.backendUrl + '/feedback/'+aid, body,{'headers':headers});
    api$.subscribe({
      next: (data) => {
        console.log("inside like" + JSON.stringify(data));
        this._snackBar.open('Like feedback submitted', 'close')
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside like error" + this.response);
        this._snackBar.open(err.message, 'close')
      },
      complete: () => {
        this.apiStatus='';
      }
    })
  }

  dislike() {
    this.apiStatus='waiting';
    const body = {
      "values": {
        'rating': '0'
      } 
    }
    //get answer id for last question
    const headers = { 'content-type': 'application/json'}
    const aid = this.chat[this.chat.length - 1]["answer_id"].toString();
    const api$ = this.http.post<any>(this.backendUrl + '/feedback/'+aid, body, {'headers':headers});
    api$.subscribe({
      next: (data) => {
        console.log(data.response);
        this._snackBar.open('Unlike feedback submitted', 'close')
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside dislike error" + this.response);
        this._snackBar.open(err.message, 'close')
      },
      complete: () => {
        this.apiStatus='';
      }
    })
  }

  comment(cmt:string, myAns:string, context_rating:string) {
    this.apiStatus='waiting';
    const formData = new FormData();
    formData.set('comment', cmt);
    formData.set('myAnswer', myAns);
    const body = {
      "values": {
        'comment': cmt,
        'myanwer':myAns,
        'context_rating': context_rating
      } 
    }
    const headers = { 'content-type': 'application/json'}
    //get answer id for last question
    const aid = this.chat[this.chat.length - 1]["answer_id"].toString();
    const api$ = this.http.post<any>(this.backendUrl + '/feedback/'+aid, body,{'headers':headers});
    api$.subscribe({
      next: (data) => {
        console.log(data.response);
        this._snackBar.open('Comment/Answer submitted', 'close')
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside comment error" + this.response);
        this._snackBar.open(err.message, 'close')
      },
      complete: () => {
        this.apiStatus='';
      }
    })
  }

  textInput(file_name:string, text:string) {
    this.apiStatus='waiting';
    const body = {
      "Text" : text,
      "File Name": file_name + '.txt'
    };
    const headers = { 'content-type': 'application/json'}  
    const api$ = this.http.post(this.backendUrl + "/Ingest_Text/test/" + this.att_id, body, {'headers':headers});
    api$.subscribe({
      next: (data) => {
        this._snackBar.open(JSON.stringify(data), 'close')
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside expert error" + JSON.stringify(err));
        this._snackBar.open('delete documents Failed', 'close')
      },
      complete: () => {
        if (this.apiResponse.status === 0) {
          this.response = (<{response: string}>this.apiResponse.response)['response'];
          this.apiStatus='';
        }
      }
    })
  }

  expert() {
    this.apiStatus='waiting';
    let formData=new FormData();
    formData.set('expertId', this.expertId);
    const body = {
      "question" : this.questions[this.questions.length -1],
      "answer": this.answers[this.answers.length -1],
      "expertId": this.expertId
    };
    this.expertId = '';
    console.log("inside expert", JSON.stringify(body));
    const api$ = this.http.post<BackendResp>(this.backendUrl + `/expert/${this.activeKm}`, body );
    api$.subscribe({
      next: (data) => {
        
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside expert error" + this.response);
      },
      complete: () => {
        if (this.apiResponse.status === 0) {
          this.response = (<{response: string}>this.apiResponse.response)['response'];
          this.apiStatus='';
        }
      }
    })
  }

  injest(){
    this.apiStatus='waiting';
    console.log('Ingest docunment api call');
    const api$ = this.http.get<any>(this.backendUrl + "/api/run_ingest" );
    api$.subscribe({
      next: (data) => {
        console.log("inside injest" + data);
        this._snackBar.open(data, 'close')
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside injest error" + JSON.stringify(err));
        this._snackBar.open('injest documents Failed', 'close')
      },
      complete: () => {
        if (this.apiResponse.status === 0) {
          this.response = (<{response: string}>this.apiResponse.response)['response'];
          this.apiStatus='';
        }
      }
    })
  }

  delete(f:NgForm){
    this.apiStatus='waiting';
    if(!f.value.doc_name) {
      return;
    }
    const body = {
     "Document_Name" : f.value.doc_name
    };
    f.reset();
    const headers = { 'content-type': 'application/json'} 
    const api$ = this.http.post<any>(this.backendUrl + "/Remove_Document/test/" + this.att_id, body, {'headers':headers});
    api$.subscribe({
      next: (data) => {
        this.deleteMessage = 'Docunment deleted successfully';
        this._snackBar.open(data, 'close')
      },
      error: (err) => {
        this.deleteMessage = err.error.error;
      },
      complete: () => {
        this.deleteMessage = 'Docunment deleted successfully';
      }
    })
  }

  gpuStat(){
    /*
    this.apiStatus='waiting';
    const api$ = this.http.get<any>("http://localhost:5000/gpu");
    api$.subscribe({
      next: (data) => {
        console.log(JSON.stringify(data));
        for(var i in data["response"]) {
          var stat = (data["response"][i]["memoryUtil"] * 100);
          this.gpu.push(stat);
        }
        console.log(this.gpu.toString());
      },
      error: (err) => {
        this.response = `errors: ${err.message}`;
        this.apiStatus = `errors: ${err.message}`;
        console.log("inside expert error" + JSON.stringify(err));
      },
      complete: () => {
        if (this.apiResponse.status === 0) {
          this.response = (<{response: string}>this.apiResponse.response)['response'];
          this.apiStatus='';
        }
      }
    })
    */
  }
}