export const environment = {
    production: false,
    appVersion: require('../../package.json').version + '-dev',
    //api_url: 'http://130.3.77.227:4500'
    //api_url : 'http://127.0.0.1:4500'
    api_url: "http://localhost:8081"
};
