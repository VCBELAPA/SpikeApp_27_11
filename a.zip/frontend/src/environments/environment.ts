export const environment = {
    production: true,
    appVersion: require('../../package.json').version,
    api_url: ''
};
