'use strict';

const fs = require('fs')
const version = JSON.parse(fs.readFileSync('./package.json', 'utf-8')).version;
console.log(version)

