# Text Generation Inference Python gRPC Server

A Python gRPC server for Text Generation Inference

## Install

```shell
make install
```

## Run

```shell
make run-dev
```