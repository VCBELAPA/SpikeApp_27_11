#!/bin/bash

VENV_DIR=~/poc1

python -m venv 
$VENV_DIR

source $VENV_DIR/bin/activate

sudo apt install postgresql

pip install -r ~/ainlm2/Jira_Copilot_Backend/requirements.txt
