import os
from dotenv import load_dotenv

#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

from llama_index import (
    SimpleDirectoryReader,
    StorageContext,
    ServiceContext,
    KnowledgeGraphIndex,
    Document
)
from llama_index.graph_stores import SimpleGraphStore
from llama_index.graph_stores import Neo4jGraphStore
from langchain.llms import AzureOpenAI 
from llama_index.retrievers import KnowledgeGraphRAGRetriever

# using data from Wikipedia
from llama_index import download_loader


WikipediaReader = download_loader("WikipediaReader")
loader = WikipediaReader()
documents = loader.load_data(pages=["2005 Azores subtropical storm"], auto_suggest=False)
llm = AzureOpenAI(
        deployment_name="text-davinci-003",
    )
service_context = ServiceContext.from_defaults(llm=llm, chunk_size=512)

# neo4j database
username = "neo4j"
password = "ainlm_dev"
url = "bolt://localhost:7687"
database = "neo4j"
graph_store = Neo4jGraphStore(
        username=username,
        password=password,
        url=url,
        database=database
    )


storage_context = StorageContext.from_defaults(graph_store=graph_store)



index = KnowledgeGraphIndex.from_documents(
    documents,
    storage_context=storage_context,
    max_triplets_per_chunk=2,
    service_context=service_context,
)
retriever = index.as_retriever()
response = retriever.retrieve("Azores subtropical storm")
print(response)
query_engine = index.as_query_engine(include_text=False, response_mode="tree_summarize")
response = query_engine.query("Azores subtropical storm")

