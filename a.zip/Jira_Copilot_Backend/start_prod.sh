#!/bin/bash

gunicorn -w 1 -b localhost:8083 retriever_tester:app & disown

gunicorn -w 1 -b 0.0.0.0:8081 backend:app & disown