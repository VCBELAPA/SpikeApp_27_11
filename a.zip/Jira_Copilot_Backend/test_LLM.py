from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    pipeline,
)
import transformers
import torch

model_dir = "meta-llama/Llama-2-13b-chat-hf"
tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True, padding=True, truncation=True)
model_config = transformers.AutoConfig.from_pretrained(
    model_dir
)
model = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=torch.bfloat16, device_map="auto")
pipe = pipeline(
        "text-generation",
        model=model_dir,
        device_map="auto", 
        config=model_config,
        max_new_tokens = 300,
        temperature=0.00001,
        repetition_penalty=1.5
)
