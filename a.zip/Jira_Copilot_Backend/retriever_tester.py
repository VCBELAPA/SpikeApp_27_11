import json
import re
import os
import requests
from sentence_transformers import SentenceTransformer, util
from nltk.tokenize import sent_tokenize
from flask import Flask, request
from dotenv import load_dotenv
from llama_index.indices.query.schema import QueryBundle
import re
import inspect

#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

from llama_index import (
    SimpleDirectoryReader,
    StorageContext,
    ServiceContext,
    KnowledgeGraphIndex,
    Document
)
from llama_index.graph_stores import SimpleGraphStore
from llama_index.graph_stores import Neo4jGraphStore
from langchain.llms import AzureOpenAI 

# using data from Wikipedia
from llama_index import download_loader



class Retriever: 
    def __init__(self,embeddings_model):
        self.embeddingmodel = embeddings_model
        self.NDR_kg_engine = self.create_graph_from_NDR()
    
    def get_page_from_st(self, st):
        try:
            dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files'
            for file_path in os.listdir(dir_path):
                    if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                        file_path = os.path.join(dir_path, file_path)
                        with open(file_path, 'r') as f:
                            NDR = json.load(f)
                            break
            metadata = NDR['metadata']
            f_name = metadata['file_name']
            page_number = metadata['page_numbers'][st]
            return f_name, page_number
        except Exception as e:
            error = "An exception occurred: %s" % e
            return {'error':error}

    #Transform preprocessed text in NDR json file into embeddings to conduct similarity search from
    def embeddings(self):
        try:
            dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files'
            Ales_encoded_paragraphs_listoflists = []
            for file_path in os.listdir(dir_path):
                if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):
                    Ales_encoded_paragraphs_listoflists.append(self.ales_encode_text(os.path.join(dir_path, file_path)))
            Ales_encoded_paragraphs = [item for sublist in Ales_encoded_paragraphs_listoflists for item in sublist]
            with open('ales_encoded_paragraphs.json', 'w') as f:
                json.dump(Ales_encoded_paragraphs, f)
            message = 'the embeddings are generated and stored.'
            return {'message': message}
        except Exception as e:
            error = "An exception occurred: %s" % e
            return {'error':error}

    #This is a test comment
    #Do similarity search on paragraph embeddings for prompt
    def retrieve_paragraphs(self, retrieve_count, Q):
        try:
            with open('ales_encoded_paragraphs.json') as f:
                ales_encoded_paraggraphs = json.load(f)
        except Exception as e:
            return e
        sims = self.calc_similarities(Q, ales_encoded_paraggraphs, "paragraphs")
        # 'fn': self.get_page_from_st(s['section title'])[0], 'pn': self.get_page_from_st(s['section title'])[1],
        ans = [{'f': s['file'], 't': s['section title'], 'fn': self.get_page_from_st(s['section title'])[0], 'pn': self.get_page_from_st(s['section title'])[1], 'p': s['paragraph'], 's': float(s['similarity'])} for s in list(sims)[0:retrieve_count]]
        return ans
    #Do similarity search on sentence embeddings for prompt and retrieve its paragraph
    def retrieve_sentences(self, retrieve_count, Q):
        try:
            with open('sentence_transformed_NDR.json') as f:
                encoded_sentences = json.load(f)
        except Exception as e:
            return e
        sims = self.calc_similarities(Q, encoded_sentences["sentence"], "sentences")
        #Only return unique paragraphs
        ans = []
        retrieved = 0
        retrieved_paragraph_indexs = []
        sentence_count = len(sims)
        while len(ans) < retrieve_count and retrieved < sentence_count:
            paragraph_index = sims[retrieved]['paragraph index']
            if paragraph_index not in retrieved_paragraph_indexs:
                retrieved_paragraph_indexs.append(paragraph_index)
                ans.append({'f': sims[retrieved]['file'], 't': sims[retrieved]['section title'], 'fn': self.get_page_from_st(sims[retrieved]['section title'])[0], 'pn': self.get_page_from_st(sims[retrieved]['section title'])[1], 'p': encoded_sentences["paragraph index"][str(paragraph_index)], 's': float(sims[retrieved]['similarity'])})
            retrieved += 1
        return ans
    
    def calc_similarities(self, Q, encoded_paragraphs, text_type):
        encoded_question = self.embeddingmodel.encode(Q)
        cos_sims = []
        if text_type == "paragraphs":
            for np in encoded_paragraphs:
                try:
                    cos_sims.append({"paragraph": np["paragraph"],
                                    "section title": np["section title"],
                                    "file": np["file"],
                                    "similarity": util.cos_sim(encoded_question, np["encoded"]).numpy()[0][0]})
                except Exception as e:
                    print(f"An error has occured while trying to calculate similarity: {str(e)}")
        elif text_type == "sentences":
            for np in encoded_paragraphs:
                try:
                    cos_sims.append({"sentence": np["sentence"],
                                     "paragraph index": np["paragraph index"],
                                    "section title": np["section title"],
                                    "file": np["file"],
                                    "similarity": util.cos_sim(encoded_question, np["encoded"]).numpy()[0][0]})
                except Exception as e:
                    print(f"An error has occured while trying to calculate similarity: {str(e)}")

        sorted_cos_sims = sorted(cos_sims, key=lambda d: d['similarity'], reverse=True) 
        return sorted_cos_sims
    
    def ales_encode_text(self, file):
        with open(file) as f:
            ales_lines = f.readlines()
        # paragraphs_string = ''.join(ales_lines)
        paragraphs_object = json.loads(' '.join(ales_lines))

        paragraphs_encoded = []
        for k in list(paragraphs_object.keys()):
            for p in paragraphs_object[k]:
                paragraphs_encoded.append({"file": file.split('/')[-1], "section title": k, "paragraph": p, "encoded": self.embeddingmodel.encode(p).tolist()})
        return paragraphs_encoded

    def split_ndr_into_sentences_and_generate_embeddings(self):
        try:
            dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files'
            Ales_encoded_paragraphs_listoflists = []
            for file_path in os.listdir(dir_path):
                if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                    file_path = os.path.join(dir_path, file_path)
                    file_name = file_path.split('/')[-1]
                    with open(file_path, 'r') as f:
                        NDR = json.load(f)
                        break
            paragraphs_index = {}
            sentence_NDR = {}
            i = 0
            sentence_NDR = []
            for section in NDR.keys():
                for paragraph in NDR[section]:
                    paragraphs_index[i] = paragraph
                    sentences = sent_tokenize(paragraph)
                    for sentence in sentences:
                        sentence_NDR.append({"sentence":sentence, "paragraph index":i, "encoded":self.embeddingmodel.encode(sentence).tolist(), "file":file_name, "section title":section})
                    i+=1
            finalized_sentence_NDR = {"sentence":sentence_NDR, "paragraph index":paragraphs_index}
            with open('sentence_transformed_NDR.json', 'w') as f:
                json.dump(finalized_sentence_NDR, f)
            
        except Exception as error:
            print(error)
    
    def create_graph_from_NDR(self):
        try:
            dir_path = '/home/azureuser/ainlm2/Jira_Copilot_Backend/test_files'
            for file_path in os.listdir(dir_path):
                #Load single NDR document
                if file_path.endswith('NDR.json') and os.path.isfile(os.path.join(dir_path, file_path)):    
                    file_path = os.path.join(dir_path, file_path)
                    with open(file_path, 'r') as f:
                        NDR = json.load(f)
                        break
            paragraphs = ""
            for section in NDR:
                if section == "metadata":
                    continue
                else:
                    for p in NDR[section]:
                        paragraphs += p
                    
            documents = [Document(text=paragraphs)]
            llm = AzureOpenAI(deployment_name="text-davinci-003")
            service_context = ServiceContext.from_defaults(llm=llm, chunk_size=512)
            # neo4j database
            username = "neo4j"
            password = "ainlm_dev"
            url = "bolt://localhost:7687"
            database = "neo4j"
            graph_store = Neo4jGraphStore(
                username=username,
                password=password,
                url=url,
                database=database
            )
            storage_context = StorageContext.from_defaults(graph_store=graph_store)
            NDR_index = KnowledgeGraphIndex.from_documents(
                documents,
                storage_context=storage_context,
                max_triplets_per_chunk=2,
                service_context=service_context,
            )
            return NDR_index.as_query_engine(include_text=False, response_mode="no_text")
        except Exception as error:
            print(error)

    def query_NDR_knowledge_graph(self, query):
        nodes_list = []
        nodes = self.NDR_kg_engine.retrieve(QueryBundle(query))
        kg_mapping = []
        for node in nodes:
            kg_mapping.append({"KG Map":node.metadata["kg_rel_map"], "Node Score":node.get_score()})
        return kg_mapping
    

#Initalize embeddings retriever
embeddings_model = SentenceTransformer('all-MiniLM-L6-v2')
Embeddings_Retriever = Retriever(embeddings_model)
#Initalize NDR knowledge graph
app = Flask(__name__)

@app.route('/embeddings')
def embeddings():
    try:
        text_type = request.json["text type"]
        if text_type == "sentence":
            Embeddings_Retriever.split_ndr_into_sentences_and_generate_embeddings()
        elif text_type == "paragraph":
            Embeddings_Retriever.embeddings()
        else:
            raise Exception("Provide valid text type to embed")
        return {"message":f"{text_type} embeddings generated successfully"}

    except Exception as e:
        message = "An exception occurred: %s" % e
        return {"error":message}

@app.route('/retrieve')
def retrieve():
    try:
        text_type = request.args.get('text type')
        Q = request.args.get('prompt')
        retrieve_count = int(request.args.get('retrieve count'))
        if text_type == "sentence":
            ans = Embeddings_Retriever.retrieve_sentences(retrieve_count, Q)
        elif text_type == "paragraph":
            ans = Embeddings_Retriever.retrieve_paragraphs(retrieve_count, Q)
        return ans
    except Exception as e:
        return {"error":str(e)}
    
@app.route('/knowledge_graph/NDR/query')
def query_NDR_kg():
    try:
        query = request.json["query"]
        mapping = Embeddings_Retriever.query_NDR_knowledge_graph(query)
        return {"KG Retrieved Mapping" : str(mapping)}
    except Exception as error:
        return {"error":str(error)}
    

if __name__ == '__main__':
   app.run(port="4100")

