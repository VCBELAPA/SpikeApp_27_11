from flask import Flask, jsonify, request, session, redirect, send_file
import requests
from lxml import etree                                                                                                                                                                                                                                                                                                 
from datetime import timedelta                                
import logging                                         
from db import DB           
from db import role_to_permissions, create_permissions_and_roles_in_db, remove_permissions_roles_and_db, check_user_roles_in_db, add_documents_to_db, remove_documents_from_db, get_all_documents_from_db, get_document_from_db
import numpy as np 
import os
import json
from flask_cors import CORS
from flask_session import Session  # Import Session
#import milvus_db
#from milvus_db import create_knowledge_base, remove_knowledge_base, Return_Collections_in_DB, Add_Text_to_Knowledge_Base, Remove_Text_From_Knowledge_Base
from utilities import get_current_git_branch
import io
from langchain.llms import HuggingFaceTextGenInference
from dotenv import load_dotenv
from langchain.llms import AzureOpenAI 
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage
from langchain.chains import LLMChain


#Load Environmental Variables for OpenAI Apis
load_dotenv('.env')
os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = os.getenv('OPENAI_API_BASE')
os.environ["OPENAI_API_KEY"] = os.getenv('OPENAI_API_KEY')

'''saml_url = 'https://saml.stage.att.com/isam/sps/attsamlidp/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https://idf-dev.az.3pc.att.com&RelayState=https://askambrin.att.com/static/'
saml_resp = requests.get(saml_url)
print(saml_resp)'''

#Initalize logging
environment = get_current_git_branch()
#If in development or application_testing branch, load environment configuration for test environment 
if environment != "master":
    #Load configs
    with open('test_configs.json') as json_file:
        configs = json.load(json_file)
    logging.basicConfig(filename = "test_backend.log", 
        format='%(asctime)s %(threadName)s : %(message)s',
        filemode='w',
        level = logging.DEBUG)
    environment = "development"
#If on master, load environemnt configuration for production environment
else:
    #Load configs
    with open('production_configs.json') as json_file:
        configs = json.load(json_file)
    logging.basicConfig(filename = "production_backend.log", 
        format='%(asctime)s %(threadName)s : %(message)s',
        filemode='w',
        level = logging.DEBUG)

app = Flask(__name__)
app.secret_key = "KLUCH"

'''manager = xmlsec.KeysManager()
key = xmlsec.Key.from_file("decryptionPvk.pem", xmlsec.constants.KeyDataFormatPem)
manager.add_key(key)
enc_ctx = xmlsec.EncryptionContext(manager)
root = etree.parse("enc1-res.xml").getroot()
enc_data = xmlsec.tree.find_child(root, "EncryptedData", xmlsec.constants.EncNs)
decrypted = enc_ctx.decrypt(enc_data)
print(etree.tostring(decrypted))'''


# Configure session type and options
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'None'
app.config['SESSION_COOKIE_SECURE'] = True

# Initialize the session
Session(app)

#Set client session to expire after 12 hours 
app.permanent_session_lifetime = timedelta(minutes=720)
db = DB (
        "RBAC", 
        search_path = configs["database"]["rbac_search_path"],
        host = configs["database"]["db_host"],
        port=configs["database"]["db_port"]
    )
feedback_db = DB (
        "ainlm", 
        search_path=configs["database"]["ainlm_search_path"],
        host = configs["database"]["db_host"],
        port=configs["database"]["db_port"]
    )
CORS(app, resources={r"/*" : {"origins" : "*"}}, supports_credentials=True)

try:
    #Connect LLM Pipelines
    gpt_3_5 = AzureOpenAI(
        deployment_name="gpt-35-turbo",
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    ) 
    davinci = AzureOpenAI(
        deployment_name="text-davinci-003",
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    )
    gpt4 = AzureChatOpenAI(
        deployment_name='gpt-4',
        max_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        frequency_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"]
    )
    LLM = HuggingFaceTextGenInference(
        inference_server_url="http://localhost:8085/",
        max_new_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        repetition_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"],
    )
    #Connect LLM Pipeline
    Test_LLM = HuggingFaceTextGenInference(
        inference_server_url="http://localhost:8085/",
        max_new_tokens=configs["LLM"]["llm_configs"]["max_tokens"],
        top_p=configs["LLM"]["llm_configs"]["top_p"],
        temperature=configs["LLM"]["llm_configs"]["temperature"],
        repetition_penalty=configs["LLM"]["llm_configs"]["frequency_penalty"],
    )
except Exception as error:
    print(f"An error has occured while trying to connect to the LLM Server: {error}")

#@app.after_request
#def cors(response):
#    response.headers['Access-Control-Allow-Origin'] = 'http://localhost:4200 http://127.0.0.1'
#    response.headers['Access-Control-Allow-Headers'] = '*'
#    response.headers['Access-Control-Allow-Credentials'] = True
#    return response

#Initalize client session 
@app.route('/login', methods=["POST"])
#@flask_saml.login_required
def initalize_session():
    try:
        global db 
        cur = db.cursor()
        attuid = request.json["attuid"]
        session["attuid"] = attuid
        session["vector_db"] = {}
        cur.execute(f"SELECT * FROM user_permissions WHERE attuid = '{attuid}';")
        user_permissions = cur.fetchall()
        #Gets permissions of each role assigned to user for all vector dbs that user has role in 
        if user_permissions != []:
            user_roles = [row[0] for row in user_permissions]
            for role in user_roles:    
                cur = db.cursor()    
                cur.execute(f"SELECT * FROM permissions WHERE role = {role};")
                permissions = cur.fetchall()
                role_permissions = [row[0] for row in permissions]
                knowledge_base = permissions[0][1]
                cur = db.cursor()
                cur.execute(f"SELECT * FROM knowledge_base WHERE id = {knowledge_base};")
                knowledge_base = cur.fetchall()[0][0]
                session["vector_db"][knowledge_base] = role_permissions 
        cur.close()
        #For Inital AskAmbrin Deliverable the default knowledge base for all users will be P1P2
        if "P1P2" not in session["vector_db"].keys():
            requested_permissions, role_id = role_to_permissions("P1P2_User", db)
            cur = db.cursor()
            cur.execute(f"INSERT INTO user_permissions (role, attuid) VALUES ({role_id}, '{attuid}')")
            db.commit()
            cur.close()
            session["vector_db"]["P1P2"] = ["read"]
            app.logger.info(f'Adding {attuid} as {"User"} to {"P1P2"}')
        app.logger.info(f'Successfully initalized client session for {attuid}')
        return {'response':f"Client session for {attuid} has successfully been initalized", 'Status':0}, 200

    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error occured when initalizing session for a user. Error: {error}')
        return {'error': error, "Status":-1}, 400

#Get knowledge bases that user has a role in
@app.route('/user/knowledge_bases', methods=["GET"])
def return_user_knowledge_bases():
    try:
        if "attuid" not in session.keys():
            app.logger.info(f'User requesting to return knowledge bases they have a role in does not have a session initalized')
            #test url
            return redirect("https://askambrin.att.com/static/", code=302)
        if session["vector_db"] != {}:
            knowledge_bases = list(session["vector_db"].keys())
        else:
            knowledge_bases = "None"
        app.logger.info(f"User {session['attuid']} has successfully returned their knowledge bases: {knowledge_bases}")
        return {"user_knowledge_bases":knowledge_bases, 'Status':0}, 200

    except Exception as error:
        attuid = session["attuid"]
        app.logger.info(f'An error has occured when user {attuid} has requested to return knowledge bases they have roles in. {error}')
        return {'error': f'An error has occured when user {attuid} has requested to return knowledge bases they have roles in. {error}', 'Status':-1}, 400

#Create or delete vector db
@app.route('/vector_db', methods=["POST", "DELETE"])
def vector_db():
    try:
        if "attuid" not in session.keys():
            app.logger.info(f'User requesting to {request.method} vector_db does not have a session initalized')
            #test url
            return redirect("https://askambrin.att.com/static/", code=302)
        
        global db
        cur = db.cursor()

        vector_db = request.json["vector_db"]
        attuid = session['attuid']
        if request.method == "POST":
            #Read in PDF files
            #docs = request.files.getlist('files')
            #docs_name = [file.filename for file in docs]
            #docs_content = [file.read() for file in docs]
            #Insert Function to preprocess documents

            #chunks = None

            #Create the knowledge base
            #result = create_knowledge_base(vector_db, chunks, app)
            result = "success"
            if result != "success":
                cur.close()
                raise Exception(str(result))
            cur.execute(f"INSERT INTO knowledge_base (description) VALUES ('{vector_db}');")
            db.commit()

            #Create the roles and permissions in the db
            status = create_permissions_and_roles_in_db(app, vector_db, db, attuid)
            if status != "success":
                cur.close()
                raise Exception(status)
            
            #Preprocess the pdfs into chunks

            #Embedded docs in knowledge base
            #result = add_documents_to_db(db, docs_name, docs_content, vector_db, attuid, app)
            if result != "success":
                cur.close()
                raise Exception(str(result))
            #Update user session so that they are admin in new knowledge base
            session["vector_db"][vector_db] = ['read', 'write', 'manage']
            cur.close()
            app.logger.info(f"Knowledge base and role for {vector_db} successfully saved in db")
            return {'response': f"User {attuid} successfully created {vector_db} vector db", 'Status':0}, 200                
    

        elif request.method == "DELETE":
            #Check if user has permissions to delete the knowledge base
            if 'manage' in session['vector_db'][vector_db]:
                #Insert logic to delete vector db
                #result = remove_knowledge_base(vector_db)
                result = "success"
                if result != "success":
                    cur.close()
                    raise Exception(str(result))
                
                #Remove the roles, permissions, and the knowledge base from db
                status = remove_permissions_roles_and_db(app, vector_db, db)
                if status != "success":
                    cur.close()
                    raise Exception(str(status))
                
                #Remove documents from db
                #result = remove_documents_from_db()
                if result != "success":
                    cur.close()
                    raise Exception(result)
                
                #Remove vector db from user's session
                del session["vector_db"][vector_db]
                app.logger.info(f"Knowledge base and role for {vector_db} successfully removed in db")
                cur.close()
                return {'response': f"User {attuid} successfully deleted {vector_db} vector db", 'Status':0}, 200
                
            else:
                cur.close()
                return {'error': f'User {attuid} does not have permissions to delete {vector_db}', 'Status': -1}, 403
                
    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error has occured when user {attuid} attempted to {request.method} {vector_db}. {error}')
        return {'error': f'An error has occured when user {attuid} attempted to {request.method} {vector_db}. {error}', 'Status': -1}, 400

#API to add, delete, or returns pdf docs in vector db
@app.route('/vector_db/docs', methods=["POST", "DELETE"])
def docs():
    try:
        global db
        global feedback_db
        attuid = session["attuid"]
        #Check if the user has the permissions to write documents into this knowledge base
        if request.method == "POST" and "write" in session["vector_db"][request.form.get("vector_db")]:
            vector_db = request.form.get("vector_db")
            docs = request.files.getlist('files')
            docs_name = [file.filename for file in docs]
            docs_content = [file.read() for file in docs]
            #Preprocess the pdfs into chunks 

            #Add the chunks processed from the pdfs into the knowledge base
            '''result = Add_Text_to_Knowledge_Base(vector_db, docs_content, app)
            if result != "success":
                raise Exception(str(result))'''
            
            #save pdfs in db
            result = add_documents_to_db(db, feedback_db, docs_name, docs_content, vector_db, attuid, app)
            if result != "success":
                raise Exception(str(result))
            return {"response":f"{attuid} successfully added {docs_name} in {vector_db}", "Status":0}, 200

        #Check if the user has the permissions to delete documents in this knowledge base
        elif request.method == "DELETE" and "write" in session["vector_db"][request.json["vector_db"]]:
            vector_db = request.json["vector_db"]
            docs_name = request.json["doc_names"]
            #Remove the documents embeddings that are in the knowledge base
            '''result = Remove_Text_From_Knowledge_Base(vector_db, docs_content, app)
            if result != "success":
                raise Exception(str(result))'''
            
            #Remove documents from db
            result = remove_documents_from_db(db, feedback_db, docs_name, vector_db, app)
            if result != "success":
                raise Exception(str(result))
            return {"response":f"{attuid} successfully deleted {docs_name}in {vector_db}", "Status":0}, 200
        
        else:
            app.logger.info(f"User {attuid} does not have permissions to add or delete documents in {vector_db}")
            return {"response": f"User {attuid} does not have permissions to add or delete documents in {vector_db}", "Status":-1}, 403
    except Exception as error:
        db._db.rollback()
        feedback_db._db.rollback()
        app.logger.error(f"Error has occured when {attuid} attempted to {request.method} document in {vector_db}: {str(error)}")
        return {'error': f"Error has occured when {attuid} attempted to {request.method} document in {vector_db}: {str(error)}", "Status":-1}, 400


#Prompt language model
@app.route('/prompt', methods=["POST"])
def prompt():
    try:
        global feedback_db
        global db
        db_cur = db.cursor()
        if "attuid" not in session.keys():
            app.logger.info(f'User requesting to send prompt to LLM does not have session initalized')
            #test url
            return redirect("https://askambrin.att.com/static/", code=302)
        vector_db = request.json["vector_db"]
        attuid = session["attuid"]
        prompt = request.json["prompt"]
        model = request.json["model"]
        if (vector_db in list(session["vector_db"].keys()) and 'read' in session["vector_db"][vector_db]):
            #Store question, attuid, domain in question table
            feedback_cur = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            db_cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{vector_db}' LIMIT 1;")
            knowledge_base_id = db_cur.fetchall()[0][1]
            #The prompt needs to be formatted to remove single quotes within the prompt to save in the db
            formatted_prompt = prompt.replace("'", "")
            feedback_cur.execute(f"insert into question (knowledge_base, attuid, question) values ({knowledge_base_id}, '{attuid}', '{formatted_prompt}');")
            feedback_cur.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            #Get Question ID                                                                                                                                                                                                                                                                                                                                                                                                                    
            question_id = feedback_cur.fetchone()[0]
            #Retrieve context and format template
            template = "Your task is not to define acronyms and abbreviations unless is given in the context, and also to give a direct response to what the user asks based on the given context and nothing else. Context: {prompt_context} User: {llm_prompt}? Response:"   
            #Retrieve four pieces of context
            response = requests.get("http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"paragraph", "retrieve count":4})
            if response.status_code == 200:
                contexts = response.json()
                app.logger.info(contexts)
            else:
                raise Exception("Error: could not retreive context")
            sections = [context["t"] for context in contexts]
            file_name = [context['fn'] for context in contexts]
            page_number = [context["pn"] for context in contexts]
            contexts = [context["p"] for context in contexts]
            prompt_context = ""
            for i, context in enumerate(contexts):
                prompt_context += (f"Fact {(i+1)} : " + context + "\n")
            llm_input = template.format(prompt_context=prompt_context, llm_prompt = prompt)
            #Prompt the LLM
            model = request.json["model"]
            if model == "Llama-2":
                ans = LLM(llm_input)
            elif model == "gpt-3.5":
                ans = gpt_3_5(llm_input)
            elif model == "davinci":
                ans = davinci(llm_input)
            elif model == "gpt4":
                ans = gpt4.predict(llm_input)
            #Store Answer 
            feedback_cur = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            feedback_cur.execute("insert into answer (question, answer) values (%(qid)s, %(answer)s)",
                            {"qid": question_id, "answer": ans}
                )
            feedback_cur.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            #Get Answer ID
            answer_id = feedback_cur.fetchone()[0]
            feedback_cur.close()
            db_cur.close()
            app.logger.info(f'User {attuid} has successfully prompted {model}')
            return {'model_response':ans, 'Status': 0, "Answer ID":answer_id, "Prompt":prompt, "Section Titles":sections, "Contexts":contexts, "file_name": file_name, "page_number": page_number}, 200
        else:
            return {"error": "User {attuid} does not have read permissions in {vector_db}", "Status": -1}, 400
    
    except Exception as error:
        db._db.rollback()
        feedback_db._db.rollback()
        app.logger.error(f'An error has occuered when user {attuid} attempted to prompt {model}. {error}')
        return {'error': f'An error has occuered when user {attuid} attempted to prompt {model}. {error}', 'Status':-1}, 400


#Add or remove user permissions 
@app.route('/vector_db/access', methods=["POST",  "DELETE"])
def permissions():
    try:
        if "attuid" not in session.keys():
            app.logger.info(f'User requesting role be added or deleted from {vector_db_name} does not have session initalized')
            #test url
            return redirect("https://askambrin.att.com/static/", code=302)

        global db
        requested_id = request.json["attuid"]
        vector_db_name = request.json["vector_db"]
        requester_id = session["attuid"]
        requester_permissions = session["vector_db"][vector_db_name]
        
        cur = db.cursor()
        #Add role to vector db
        if request.method == "POST":
            #Get role and map role to permissions
            requested_role = request.json["role"]
            requested_role = vector_db_name + "_" + requested_role
            requested_permissions, role_id = role_to_permissions(requested_role, db)
            if requested_permissions == "error":
                raise Exception(role_id)
            #Check if user that has been requested to be added already has a role in the knowledge base
            role_status = check_user_roles_in_db(requested_id, vector_db_name, db, app)
            if role_status == "User has role in this knowledge base":
                return {'response': f"{requested_id} already has a role in {vector_db_name}", "Status":0}, 200
            elif "error" in role_status:
                raise Exception(role_status)

            #Check if the user has permissions to add new user to role 
            if set(requested_permissions).issubset(set(requester_permissions)):
                #Grant user role in given vector db
                cur.execute(f"INSERT INTO user_permissions (role, attuid) VALUES ({role_id}, '{requested_id}')")
                db.commit()
                cur.close()
                app.logger.info(f'Adding {requested_id} as {requested_role} to {vector_db_name}')
                return {'response': f'{requested_id} added as {requested_role} to {vector_db_name}', 'Status':0}, 200
            else:
                cur.close()
                app.logger.info(f'Request to add {requested_id} as {requested_role} to {vector_db_name} rejected')
                return {'error':f'User {requester_id} does not have permissions to add a {requested_role} to {vector_db_name}', 'Status':-1}, 400

        #Remove role from vector db
        elif request.method == "DELETE":
            #Get user's role in knowledge base
            cur.execute(f"SELECT * FROM knowledge_base WHERE description = '{vector_db_name}' LIMIT 1;")
            kb_id = cur.fetchall()[0][1]
            cur = db.cursor()
            cur.execute(f"SELECT * FROM permissions WHERE knowledge_base = {kb_id};")
            roles = [row[2] for row in cur.fetchall()]
            query = f"SELECT * FROM user_permissions WHERE attuid = '{requested_id}' AND"
            for i, role in enumerate(roles):
                if i == 0:
                    query += f" (role = {role}"
                else:
                    query += f" OR role = {role}"
            query += ") LIMIT 1;"
            cur = db.cursor()
            cur.execute(query)
            requested_role = cur.fetchall()
            if requested_role == []:
                return {'response':f'{requested_id} does not have role in {vector_db_name}', 'Status':0}, 200
            requested_role = requested_role[0][0]
            cur = db.cursor()
            cur.execute(f"SELECT * FROM roles WHERE id = {requested_role} LIMIT 1;")
            requested_role = cur.fetchall()[0][1]
            #Check if the user has admin permissions to delete role
            if requester_permissions == ['read', 'write', 'manage']:
                #Remove user role in given vector db
                cur.execute(f"SELECT * FROM roles WHERE description = '{requested_role}' LIMIT 1;")
                db.commit()
                requested_role_id = cur.fetchall()[0][0]
                cur = db.cursor()
                cur.execute(f"DELETE FROM user_permissions WHERE role = {requested_role_id} AND attuid = '{requested_id}';")
                db.commit()
                cur.close()
                app.logger.info(f'Removed {requested_id} from {vector_db_name}')
                return {'response': f'{requested_id} removed from {vector_db_name}', 'Status':0}, 200
            else:
                cur.close()
                app.logger.info(f'Request to remove {requested_id} from {vector_db_name} rejected')
                return {'error':f'User {requester_id} does not have permissions to remove a {requested_role} from {vector_db_name}', 'Status':-1}, 400
        
        else:
            cur.close()
            app.logger.warning(f"Invalid request to add, change, or delete user role from {vector_db_name}")
            return {'error': f'Invalid request to add or delete user role from {vector_db_name}', 'Status': -1}, 400

    except Exception as error:
        db._db.rollback()
        app.logger.error(f'An error occured when adding or deleting role in {vector_db_name}. Error: {error}')
        return {'error': error, "Status":-1}, 400

#Send back Feedback
@app.route('/feedback/<answerId>', methods=['POST'])
def createFeedback(answerId):
    '''creates a an answer in the database for the question; must pass question id
        post variables: (at least one is required)
            rating 0-10; but can be any number
            comment: text with a comment
            myanswer: the answer provided by the user
            context_rating 0 or 10: rating for how well vector db returned info relvant to users question 
        returns:
            {status: 0|-errcode, response: id}  'id' is the is the id of this particular feedback
    '''
    global feedback_db
    rv={"status": 0}
    #set any unprovided value to blank '' (distinguish between 0 and '' for rating)
    values = request.json["values"]
        
    param=list(map(lambda x: values[x] if x in values else '',
                    ['rating', 'comment', 'myanswer']))
    #, 'context_rating']))
    if len(list(filter(lambda x: x, param))) > 0: # have at least one of them
        try:
            cursor = feedback_db.cursor() #note this always returns arrays and not dicts (names=None)
            #note in the db, if rating is not provided, it will be set to -1
            cursor.execute("""insert into feedback (answer, rating, comment, myanswer) values (%s, %s, %s, %s)""",
                        [answerId, param[0] if param[0] else -1] + param[1:]
                )
            cursor.execute("select lastval()") #this returns auto_increment id of the last inserted row
            feedback_db.commit()
            rv['response'] = cursor.fetchone()[0]   #this cursor returns arrays and not dicts
            cursor.close()
            app.logger.info(f"Successfully saved feedback in DB for {param}")
        except Exception as error:
            app.logger.error(f"An error has occured while saving feedback in DB for {param}")
            feedback_db._db.rollback()
            rv['error'], rv['status'] = str(error), -1
    else:
        app.logger.error('Must provide at least one of rating, comment, or myanswer')
        rv['error'], rv['status'] = 'Must provide at least one of rating, comment, or myanswer', -2
    return jsonify(rv)


#Return documents that have been ingested into knowledge base for download
@app.route('/pdf/download',methods=['POST'])
def download():
    try:
        global feedback_db
        global db
        file_name = request.json["file_name"]
        vector_db = request.json["knowledge_base"]
        attuid = session["attuid"]
        result, document = get_document_from_db(feedback_db, db, file_name, attuid, vector_db, app)
        if result == "success":
            document_name, document_data = document
            response = send_file(io.BytesIO(document_data), mimetype='application/pdf', as_attachment=True, download_name=document_name)
            return response
        else:
            raise Exception(result)
    except Exception as error:
        return jsonify({"error": str(error), "Status":-1})

    
#Return list of all documents that have been ingested into knowledge base 
@app.route('/vector_db/all',methods=['POST'])
def allFilesList():
    try:
        global feedback_db
        global db
        vector_db = request.json["knowledge_base"]
        #attuid = session["attuid"]
        result, document = get_all_documents_from_db(feedback_db, db, vector_db, app)
        if result == "success":
            return document
        else:
            raise Exception(result)
    except Exception as error:
        return jsonify({"error": str(error), "Status":-1}), 400

@app.route('/STT', methods=['POST'])
def getextension():
    try:
        print("Request Received")
        audio_file = request.files['audio']
        if(audio_file):
            res = getSTT(audio_file=audio_file)
            return jsonify(res)
        return jsonify({"text":"Not found"}), 404
    except Exception as error:
        app.logger.error(f"An error has occured while trying to transform speech to text: {str(error)}")
        return jsonify({"error": str(error), "Status":-1}), 400

'''This Following Section of APIs are used for testing and development purposes'''

#test apis for Prompting language model
#if environment != "master": 

@app.route('/embeddings', methods=["POST"])
def return_similar_embeddings():
    try:
        prompt = request.json["prompt"]
        similarity_search_text = request.json["similarity search text"]
        retrieve_count = request.json["retrieve count"]
        if similarity_search_text == "sentence":
            response = requests.get("http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"sentence", "retrieve count":retrieve_count})
            if response.status_code == 200:
                contexts = response.json()
            else:
                raise Exception("Error: could not retreive context")
        elif similarity_search_text == "paragraph":
            response = requests.get("http://localhost:8083/retrieve", params={'prompt':prompt, "text type":"paragraph", "retrieve count":retrieve_count})
            if response.status_code == 200:
                contexts = response.json()
            else:
                raise Exception("Error: could not retreive context")
        else:
            raise Exception("Error: invalid similarity seach text type provided")
        sections = [context["t"] for context in contexts]
        file_names = [context["f"] for context in contexts]
        prompt_contexts = [context["p"] for context in contexts]
        similarity_score = [context["s"] for context in contexts]
        file_name = [context["fn"] for context in contexts]
        page_number = [context["pn"] for context in contexts]
        return {"context":prompt_contexts, "File Names":file_names, "Section Titles":sections, "Similarity Score" : similarity_score, "file_name": file_name, "page_number": page_number}, 200
        
    except Exception as error:
        return {"error": str(error)}, 400


# Your task is to answer the question by using the context {prompt_context}. Question: {llm_prompt}
@app.route('/Test/LLM', methods =["POST"])
def prompt_LLM():
    try:
        prompt = request.json["prompt"]
        contexts = request.json["context"]
        if "template" not in request.json.keys():
            template = "Your task is not to define acronyms and abbreviations unless is given in the context, and also to give a direct response to what the user asks based on the given context and nothing else. Context: {prompt_context} User: {llm_prompt}? Response:"   
        else:
            template = request.json["template"]
        prompt_context = ""
        for i, context in enumerate(contexts):
            prompt_context += (f"Fact {(i+1) : } " + context + "\n")
        finalized_prompt = template.format(prompt_context=prompt_context, llm_prompt = prompt)
        #Prompt the LLM
        model = request.json["model"]
        if model == "Llama-2":
            answer = Test_LLM(finalized_prompt)
        elif model == "gpt-3.5":
            answer = gpt_3_5(finalized_prompt)
        elif model == "davinci":
            answer = davinci(finalized_prompt)
        elif model == "gpt4":
            answer = gpt4.predict(finalized_prompt)
        return {"answer":answer}, 200
    except Exception as error:
        return {"error":str(error)}, 400

    
if __name__ == '__main__':
    app.run(debug=True, threaded=True)