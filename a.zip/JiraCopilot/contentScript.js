//template
const template = {
    "description": {
        "visual": `<p><strong>Exploring BGP's Role in X-Leaf/P2 EMUX Network Routing</strong></p><p>As a network operations user responsible for the X-Leaf/P2 EMUX&nbsp; Network I want to understand the network routing and in particular the role of BGP so that I can have the required in depth knowledge of the network routing design protocols to manage the network effectively.</p><p>The network uses independent interior and exterior routing protocols to propagate the necessary routing information throughout the network.</p><p><span style="color: red;" data-mce-style="color: red;">[[&amp;Can you explain BGP Persistence and its relation to the Long-lived Graceful Restart Capability?]]</span></p><p><span style="color: red;" data-mce-style="color: red;">[[&amp;In what scenarios is BGP LLGR (Long Lived Graceful Restart) more applicable compared to traditional routing?]]</span></p><p><span style="color: red;" data-mce-style="color: red;">[[&amp;In what situations might BGP Persistence be useful, such as specific types of session failures?]]</span></p><p><span style="color: red;" data-mce-style="color: red;">[[&amp;What are the key characteristics of BGP LLGR that make it distinct from traditional routing methods?]]</span></p>`,
        "text": "*Exploring BGP's Role in X-Leaf/P2 EMUX Network Routing*\n\nAs a network operations user responsible for the X-Leaf/P2 EMUX  Network I want to understand the network routing and in particular the role of BGP so that I can have the required in depth knowledge of the network routing design protocols to manage the network effectively.\n\nThe network uses independent interior and exterior routing protocols to propagate the necessary routing information throughout the network.\n\n{color:#FF0000}[[&Can you explain BGP Persistence and its relation to the Long-lived Graceful Restart Capability?]]{color}\n\n{color:#FF0000}[[&In what scenarios is BGP LLGR (Long Lived Graceful Restart) more applicable compared to traditional routing?]]{color}\n\n{color:#FF0000}[[&In what situations might BGP Persistence be useful, such as specific types of session failures?]]{color}\n\n{color:#FF0000}[[&What are the key characteristics of BGP LLGR that make it distinct from traditional routing methods?]]{color}"
    }
};
let attArray = decodeURIComponent((document.cookie.split(';').filter(s=>s.includes('attESHr'))[0] || '').trim()).split('|');
let att_id = '';
if(attArray) {
    att_id = attArray[2].split('@')[0];
}
chrome.runtime.sendMessage({
    message: 'login',
    data: {'attuid':att_id}
}, function (responseText) {
    console.log("got answers");
    console.log(responseText);
});

let questions = []
let questionData = []
let mustacheTags = ['[[', ']]']
// create generatre button 
//<button type="button" class="aui-button aui-icon-small wiki-operation-undo" aria-disabled="false" id="ainlm-Generate" resolved=""><span>Generate </span></button>
const generate_button = document.createElement("button")
generate_button.type = "button"
// generate_button.classList.add(["aui-button","aui-icon-small", "wiki-operation-undo"])
generate_button.classList.add("aui-button", "aui-icon-small")
generate_button.ariaDisabled = 'false'
//create span
const generate_span = document.createElement("span")
generate_span.innerText = 'Generate US'
generate_button.appendChild(generate_span)
generate_button.id = "ainlm-Generate"
generate_button.onclick = async function () {
    const template = getTemplate();
    parseQuestion(template);
    if(questions.length > 0) {
        var button = document.getElementById("ainlm-Generate");
        let child = button.children;
        child[0].innerText = 'Loading...'
    }
    chrome.runtime.sendMessage({
        message: 'get_answers',
        data: questions
    }, function (responseText) {
        console.log("got answers");
        console.log(responseText);
    });
};

// create template button
const template_button = document.createElement("button")
template_button.type = "button"
// template_button.classList.add(["aui-button","aui-icon-small", "wiki-operation-undo"])
template_button.classList.add("aui-button", "aui-icon-small")
template_button.ariaDisabled = 'false'
//create span
const template_span = document.createElement("span")
template_span.innerText = 'Create Template'
template_button.appendChild(template_span)
template_button.id = "ainlm-Template"
template_button.onclick = async function () {
    generateTemplate(template);
};


chrome.runtime.onMessage.addListener(
    async function (request, sender, sendResponse) {
        if(request.message == 'answers_from_ai') {
            const data = request.data
            for (let index = 0; index < questionData.length; index++) {
                const element = questionData[index];
                if(element['question'] == data["Prompt"]) {
                    questionData[index]['answer'] = data['model_response'];
                }
            }
            if(isAllAnswer()){
                console.log('final Answer')
                console.log(questionData)
                updateDescription()
            }
        }
        console.log('got response')
        console.log(request)

    }
);

function isAllAnswer(){
    let isAnswer = true;
    for (let index = 0; index < questionData.length; index++) {
        const element = questionData[index];
        if(!element['answer']) {
            isAnswer = false;
            break;
        }
    }
    return isAnswer;
}

function updateDescription(){
    let template = getTemplate();
    console.log(template);
    const updatedTemplate = updateTemplate(template);
    console.log(updatedTemplate);
    generateTemplate(updatedTemplate);
    
}

function updateTemplate(template) {
    // get template and view for mustache
    var viewText = {}
    var viewVisual = {}
    questionData.forEach((element) => {
      const key = element.question.toString();
      viewText[key] = '{color:#0747a6}'+element['answer']+'{color}';
      viewVisual[key] = '<span style="color: #0747a6;">'+element['answer']+'</span>';
    });
    template["description"]["text"] = Mustache.render(template["description"]["text"], viewText, {}, mustacheTags);
    template["description"]["visual"] = Mustache.render(template["description"]["visual"].replace(/&amp;/g, '&'), viewVisual, {}, mustacheTags);
    return template;
  }



function generateTemplate(template) {
    console.log(JSON.stringify(template));
    const description_text = template["description"]["text"];
    const description_visual = template["description"]["visual"];
    var description_textArea = document.querySelector('#description-wiki-edit textarea');
    description_textArea.value = description_text;
    var description_iframe = document.querySelector('#description-wiki-edit iframe');
    var description = description_iframe.contentWindow.document.getElementsByTagName("body")[0];
    description.innerHTML = description_visual;
    console.log('updating button');
    var button = document.getElementById("ainlm-Generate");
    let child = button.children;
    console.log(child);
    child[0].innerText = 'Generate US'
}

function getTemplate() {
    let description_text = '';
    let description_visual = '';
    var description_textArea = document.querySelector('#description-wiki-edit textarea');
    description_text = description_textArea.value;
    var description_iframe = document.querySelector('#description-wiki-edit iframe');
    var description = description_iframe.contentWindow.document.getElementsByTagName("body")[0];
    description_visual = description.innerHTML;
    var template = {
        "description": {
            "visual": description_visual,
            "text": description_text
        }
    };
    console.log(template);

    return template;
}

function parseQuestion(t) {
    console.log(t);
    console.log(JSON.stringify(t));
    var description = t["description"]["visual"];
    var descriptionParse = Mustache.parse(description.replace(/&amp;/g, '&'), mustacheTags);
    questions = descriptionParse.filter((array) => { return (array[0] == '&') || (array[0] == 'name') }).map((array) => array[1]);
    questionData = questions.map((q) => {
        return {
            "question": q,
            "answer": ''
        }
    });
    console.log('parseQuestion');
    console.log(questionData);
    console.log(questions);
}

var observer = new MutationObserver(function (mutations) {

    mutations.forEach(function (mutation) {
        console.log("HTML change observe");
        const bars = document.querySelectorAll("div.wiki-edit-undo-redo-buttons.aui-buttons")
        console.log(bars)
        console.log(mutation);
        const temp_Button = document.getElementById("ainlm-Template")
        const ge_button = document.getElementById("ainlm-Generate")
        if (temp_Button) temp_Button.disabled = false;
        if (ge_button) ge_button.disabled = false;
        // console.log(aiButton);
        for (let i = 0; i < bars.length; i++) {
            const element = bars[i];
            if(bars.length =4) {
                try {
                    //asuming that this is new create issue box
                    let wiki = element.parentElement.parentElement.previousElementSibling
                    if(wiki.previousElementSibling.innerText == 'Description') {
                        if (element && !temp_Button) {
                            element.appendChild(template_button)
                            element.appendChild(generate_button)
                        }
                        break;
                    }
                } catch (error) {
                    console.log('error');
                }
            }
            if (element && !temp_Button) {
                element.appendChild(template_button)
                element.appendChild(generate_button)
            }

        }

    })

});

observer.observe(document, {
    characterData: true,
    childList: true,
    subtree: true
});

function makeGetRequest(request) {
    return new Promise(function (resolve, reject) {
        fetch(request).then(
            (response) => {
                var r = response;
                console.log("fetch res", r);
                var result = r.user_knowledge_bases;
                console.log('Processing Request');
                resolve(result);
            },
            (error) => {
                reject(error);
            }
        );
    });
} 