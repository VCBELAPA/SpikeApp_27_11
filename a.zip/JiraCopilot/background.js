chrome.runtime.onInstalled.addListener(function () {
    console.log("Hello from background1");
});
const JiraUrl = 'https://attjira.web.att.com/'
chrome.action.onClicked.addListener(async (tab) => {
    console.log("hss");
    if (tab.url.startsWith(JiraUrl)) {
        console.log("sending req to ira");
        //const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
        const response = await chrome.tabs.sendMessage(tab.id, {greeting: "hello"});
    }
})


chrome.runtime.onMessage.addListener(async function (request, sender, callback) {
    if(request.message == 'get_answers') {
        questions = request.data;
        questionData = questions.map((q) => {
            return {
                "question": q,
                "answer": ''
            }
        });
        console.log(sender);
        const fetchPromises = questions.map(q => 
            fetch("https://askambrin.att.com/prompt", {
                method: "POST", // *GET, POST, PUT, DELETE, etc.
                mode: "cors", // no-cors, *cors, same-origin
                cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
                credentials: "same-origin", // include, *same-origin, omit
                headers: {
                    "Content-Type": "application/json",
                    // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                //redirect: "follow", // manual, *follow, error
                //referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
                body: JSON.stringify({
                    "prompt": q,
                    "model": "Llama-2",
                    "vector_db": "P1P2"
                }), // body data type must match "Content-Type" header
            })
        )
        
        //const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
        Promise.all(fetchPromises).then(async responses => {
            responses.forEach(async data => {
                var dataJson = await data.json()
                chrome.tabs.sendMessage(sender.tab.id, {message: "answers_from_ai", data : dataJson});
                console.log(Object.keys(dataJson))
                for (let index = 0; index < questionData.length; index++) {
                    const element = questionData[index];
                    if(element['question'] == dataJson["Prompt"]) {
                        questionData[index]['answer'] = dataJson['model_response'];
                    }
                }
            })
            //var res = await chrome.tabs.sendMessage(sender.tab.id, {message: "answers_from_ai", data : questionData});
        })
    } else if(request.message == 'login') {
        fetch("https://askambrin.att.com/login", {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, *cors, same-origin
            cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
            credentials: "same-origin", // include, *same-origin, omit
            headers: {
                "Content-Type": "application/json",
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            //redirect: "follow", // manual, *follow, error
            //referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
            body: JSON.stringify(request.data), // body data type must match "Content-Type" header
        });
    }
});

async function postRequest(request) {
    if (request.action == "xhttp") {
        const response = await fetch(request.url, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, *cors, same-origin
            cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
            credentials: "same-origin", // include, *same-origin, omit
            headers: {
                "Content-Type": "application/json",
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            //redirect: "follow", // manual, *follow, error
            //referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
            body: JSON.stringify(request.data), // body data type must match "Content-Type" header
        });
        const data = await response.json();
        console.log(JSON.stringify(data));
        return data;
    }
}


