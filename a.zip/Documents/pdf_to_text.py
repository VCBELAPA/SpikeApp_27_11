import os
import PyPDF2

def pdf_to_text(pdf_path):
    with open(pdf_path, 'rb') as pdf_file:
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        text = ''
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text()
        return text

def main():
    input_folder = '/home/lab2/ainlm/Documents/SOURCE_DOCUMENTS'
    output_folder = '/home/lab2/ainlm/Documents/P1P2_Tech_Docs_Text'

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for pdf_filename in os.listdir(input_folder):
        if pdf_filename.endswith('.pdf'):
            pdf_path = os.path.join(input_folder, pdf_filename)
            text = pdf_to_text(pdf_path)

            text_filename = pdf_filename.replace('.pdf', '.txt')
            text_path = os.path.join(output_folder, text_filename)

            with open(text_path, 'w', encoding='utf-8') as text_file:
                text_file.write(text)

if __name__ == '__main__':
    main()
