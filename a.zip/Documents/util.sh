SDOC=~/ainlm/Documents/SOURCE_DOCUMENTS
RAWDOC=~/ainlm/Documents/tmpDocs
RDIR=~/ainlm/local_Llama
DB=$RDIR/DB

while [[ $# -gt 0 ]]; do
	case "$1" in
		-c | --clear | --clean)
			rm $SDOC/*
			rm -r $DB
			mkdir $DB
			;;
		-l | --load)
			#assumes the document is in $RAWDOC directory
			fname=$RAWDOC/$2
			enscript -p ${fname}.ps $fname
			ps2pdf ${fname}.ps ${fname}.pdf
			cp ${fname}.pdf $SDOC
			rm ${fname}.ps
			shift
			;;
		-i | --ingest)
			rm -r $DB
			mkdir $DB
			python $RDIR/ingest.py
			;;
		-r | --run)
			(cd $RDIR; echo False | flask --app run_Llama2 run --host 0.0.0.0 -p 8082 &)

	esac
	shift
done
